"""
FLASH BASEBALL  -  batting + baserunning game (pygame, fullscreen)

Run it:      pip install pygame
             python flash_baseball.py

START SCREEN
  Type a team name, click a home color, pick EASY / MEDIUM / HARD, pick a game length (1/3/5/9 innings),
  then click PLAY BALL (or press ENTER).
  Keyboard shortcuts: LEFT/RIGHT = color, UP/DOWN = difficulty, TAB = innings.
  Want a different title font?  Drop any .ttf file next to this script and name it  title_font.ttf

DIFFICULTY  (you can change it any time from the pause menu)
  EASY ..... slower pitches, bigger timing windows, and you CAN hit the splitter if you swing in the green
  MEDIUM ... the original game
  HARD ..... faster pitches, smaller timing windows, plus the CHANGEUP and the SLIDER (always a ball)

HOW A PLAY WORKS
  1. BATTING VIEW (behind the batter): time your swing with the meter, and read the
     SEAMS window in the corner to see which pitch is coming (rolling up = fastball,
     rolling down = curveball, barely spinning = splitter, slower rolling up = changeup, tilted = slider).
  2. PITCH LOCATION: pitches come INSIDE, MIDDLE or OUTSIDE. The ball drifts left/right and the green part of the
     meter shifts: inside pitches need an EARLIER swing, outside pitches a LATER swing.
  3. After contact the game cuts to the OVERHEAD FIELD VIEW. Fielders chase the ball (backups and cutoff men
     help out). The batter runs to first on his own; after that YOU click RUN at every base.
  4. Home runs stay in the batting view with a fireworks celebration. A PERFECT PERFECT swing
     gets a short side-view "slugger" cutscene: bat meets ball, explosion, camera follows it out.
  5. The pitcher has a brain: he picks pitches based on the count (more chase pitches with two strikes,
     fastballs when he is behind, and he mixes it up so he is not predictable).
  6. FLY BALLS: the fielder runs to where he thinks it will land. If it comes down inside his catch circle it is an out,
     otherwise it drops in for a hit. Worse contact = bigger circle (see CATCH_RADIUS). A fly out is clearly CAUGHT (white flash + "CAUGHT!" text). A ball that falls in for a hit bounces
     (dust puff) and rolls on, and the fielder has to chase it down.

STEALING
  With runners on, press S BEFORE the pitch to send them. Odds depend on the pitch:
  fastball is the worst for the runner, curveball / slider / changeup are about 50-50, splitter is a bit better.
  If you put the ball in play the steal is called off. A foul ball sends the runners back.

RARE ANIMATIONS (each has its own chance in the settings - see DIVE_CHANCE etc.)
  Diving stop ........ a fielder dives for a ground ball
  Leaping catch ...... a fielder jumps to snag a fly ball
  Broken bat ......... weak contact snaps the bat
  Fan catch .......... a (tiny) fan in the stands catches a home run
  Scoreboard hit ..... a home run over the scoreboard rocks it and makes it flicker
  Slugger cutscene ... a PERFECT PERFECT swing
  Robbed at the wall . an outfielder leaps and steals a short home run
  Bat flip ........... a really long home run gets the bat flipped
  On fire ............ a hot streak sets the batter's box ablaze
  Pause (P) > Animations lets you watch every one of them on demand.

CONTROLS
  Batting:   SPACE or click ........ swing
  Steal:     S before the pitch .... runners go on the pitch (press again to cancel)
  Running:   click RUN button ...... send the runner to the next base (or press R)
             click SLIDE button .... shown when the runner is close to the bag (or press S)
             click the runner ...... turn him around mid-run (short cooldown so you can't flip-flop)
             R while running ....... run THROUGH the next bag without stopping
  Any time:  F11 fullscreen / windowed,  ESC quit
  Pause:     P pauses / resumes (menu: Resume, Difficulty, Animations, Restart Game, Quit to Title)
  Cutscene:  SPACE or click skips the PERFECT PERFECT home run cutscene
  After a ball in play: click the NEXT PITCH button (or press SPACE) to move on
  Game over: line score + stats; click or SPACE returns to the start screen

FILE LAYOUT
  1. SETTINGS ......... every number you might want to tweak
  2. DATA CLASSES ..... Pitch, Hit, Ball, Fielder, Runner, FieldPlay
  3. DRAWING HELPERS .. backgrounds, people, buttons, title lettering (these never change the game)
  4. GAME CLASS ....... the rules (pitching, swinging, fielding AI, baserunning, scoring)
  5. MENU CLASS ....... the start screen
  6. MAIN LOOP

All times are in SECONDS. "bases" as a position means: 0=home, 1=first, 2=second, 3=third, 4=home again.
"""
import asyncio
import json
import math
import os
import random
import sys
from dataclasses import dataclass, field

import pygame

# =============================================================================
# 1. SETTINGS  -  change these to change how the game feels
# =============================================================================

FULLSCREEN = True               # start fullscreen (F11 toggles)
WINDOW_SCALE = 0.9              # window size (windowed mode) relative to the 1280x720 canvas
FPS = 60
LOGICAL_W, LOGICAL_H = 1280, 720    # the game is drawn on this canvas and scaled to fit your screen
BAT_W, BAT_H = 770, 390             # size of the batting-view picture (scaled up to fill the screen)
FADE_TIME = 0.3                     # fade-in when the view switches

# --- Start screen ------------------------------------------------------------
TITLE_TEXT = "FLASH BASEBALL"
TITLE_FONT_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "title_font.ttf")   # optional custom font
TITLE_FONT_NAMES = "impact,haettenschweiler,arialblack,franklingothicheavy,anton,bebasneue"   # tried in order if no file
DEFAULT_TEAM_NAME = "SLUGGERS"
MAX_NAME_LENGTH = 12
DEFAULT_DIFFICULTY = "Medium"
INNING_OPTIONS = [1, 3, 5, 9]    # game lengths offered on the start screen
DEFAULT_INNINGS = 3
LOGO_PX = 48                     # logos are 48x48 pixel pictures
LOGO_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "home_logo.png")   # your drawn logo is saved here
SETTINGS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "flash_baseball_settings.json")   # team name, color, difficulty, innings
PEN_COLORS = [(255, 255, 255), (20, 20, 24), (230, 50, 50), (242, 201, 76), (60, 200, 90), (70, 140, 255)]
TEAM_COLORS = [                  # (label, colour) - used for the batter's helmet and your runners' caps
    ("Navy", (44, 58, 128)), ("Red", (214, 48, 48)), ("Orange", (242, 134, 32)), ("Gold", (235, 190, 40)),
    ("Green", (34, 150, 76)), ("Teal", (24, 170, 180)), ("Purple", (136, 70, 180)), ("Black", (40, 40, 46)),
]

# --- Players -----------------------------------------------------------------
# Every batter gets a random skin tone (tan to dark). He keeps it from the batter's box all the way around the bases.
# The fielders each get one for the whole game.
SKIN_TONES = [(226, 184, 134), (210, 164, 114), (190, 142, 98), (164, 116, 78), (136, 94, 62), (106, 72, 48), (82, 55, 38)]
SKIN_DEFAULT = (224, 190, 150)
# Batter's swing (batting view): the bat takes SWING_TIME seconds to reach the ball, then follows through
LOAD_TIME = 0.30                 # the batter loads (hands go back and up) during the last part of the wind-up
SETTLE_TIME = 0.35               # how long the batter takes to ease from his held finish back to the stance for the next pitch
SWING_TIME = 0.15
FOLLOW_TIME = 0.20
BAT_DRAW_LENGTH = 100            # bat length in pixels in the batting view

# --- Gait: sway + dust under the feet --------------------------------------------
SWAY_AMOUNT = 1.6                # how far (pixels) a running player's head sways side to side
BOB_AMOUNT = 1.4                 # how far he bobs up and down with each step
STRIDE_PER_PIXEL = 0.12          # radians of the step cycle per pixel travelled (bigger = quicker steps)
DUST_RATE = 12                   # dust particles per second from a running player's feet (sliding makes more)
SLIDE_DUST_RATE = 40
MAX_DUST = 350                   # safety cap on the number of particles

# --- Difficulty --------------------------------------------------------------
# speed:   pitch speed multiplier (1.0 = original; bigger = faster pitches, shorter time to react)
# window:  multiplier on ALL the timing windows below (bigger = bigger hit zone)
# splitter_in_green: True = the splitter can be hit if your swing lands inside the green (PERFECT) window
# pitches: which pitches the pitcher can throw
# zone_offset: seconds of timing shift for an inside (earlier) / outside (later) pitch
# blurb:   two lines shown under the difficulty buttons
DIFFICULTIES = {
    "Easy":   dict(speed=0.88, window=1.30, splitter_in_green=True, zone_offset=0.035,
                   pitches=("Fastball", "Curveball", "Splitter"),
                   blurb=("Slower pitches and a bigger hit zone.", "You can even hit the splitter if you swing in the green!")),
    "Medium": dict(speed=1.00, window=1.00, splitter_in_green=False, zone_offset=0.045,
                   pitches=("Fastball", "Curveball", "Splitter"),
                   blurb=("The classic Flash Baseball experience.", "Lay off the splitter.")),
    "Hard":   dict(speed=1.08, window=0.80, splitter_in_green=False, zone_offset=0.055,
                   pitches=("Fastball", "Curveball", "Splitter", "Changeup", "Slider"),
                   blurb=("Faster pitches, a smaller hit zone, plus", "changeups and sliders. No mercy.")),
}

# --- Game length -------------------------------------------------------------
OUTS_PER_INNING = 3
BALLS_FOR_WALK = 4
STRIKES_FOR_OUT = 3
# The CPU's final score is a random number from 0 to CPU_MAX_TOTAL. Once YOU pass CPU_MAX_TOTAL runs,
# it is a random number from 0 to CPU_RATIO_ABOVE_MAX (80%) of your score instead.
# It is rolled once per game (as a 0-100% roll) and the CPU's runs are spread across the innings toward that total.
CPU_MAX_TOTAL = 15
CPU_RATIO_ABOVE_MAX = 0.80

# --- Pitches -----------------------------------------------------------------
# chance:   base relative likelihood (the pitching brain adjusts it by the count)
# seconds:  (fastest, slowest) time to reach the plate. SMALLER = FASTER.   (Medium difficulty values)
# mph:      speed shown for the (fastest, slowest) pitch
# hittable: False = you can never make contact (lay off it)   (Easy lets you hit the splitter in the green)
PITCHES = {
    "Fastball":  dict(chance=40, seconds=(0.42, 0.54), mph=(100, 90), hittable=True),
    "Curveball": dict(chance=40, seconds=(0.72, 0.92), mph=(80, 71),  hittable=True),
    "Splitter":  dict(chance=20, seconds=(0.55, 0.63), mph=(89, 84),  hittable=False),
    "Changeup":  dict(chance=18, seconds=(0.66, 0.80), mph=(88, 80),  hittable=True),    # Hard only: hot out of the hand, then it dies
    "Slider":    dict(chance=16, seconds=(0.52, 0.60), mph=(88, 82),  hittable=False),   # Hard only: always a ball, like the splitter
}
PAUSE_BEFORE_PITCH = 0.9
WIND_UP_TIME = 0.9               # the pitcher's windup: settle, leg kick, stride, then the arm whips through
PITCH_FOLLOW_TIME = 0.25         # seconds the pitcher's arm takes to carry through after the release
RELEASE_BLEND = 0.18             # first part of the pitch's flight (0-1) during which the ball travels from his hand onto its path
DUGOUT_WALK_SPEED = 85           # pixels per second: how fast a batter who made an out walks back to the dugout
# --- New in this version: batting order, pitcher fatigue, baserunning smarts, weather ----------------------------
# (name, jersey number, power, contact, speed): power > 1 = more extra-base hits / homers, contact > 1 = a bigger hit window,
# speed > 1 = he runs to first faster.  The batting order loops: 1 through 9, then back to 1.
LINEUP = [("J. Alvarez", 7, 1.00, 1.06, 1.18), ("M. Chen", 12, 0.94, 1.10, 1.12), ("D. Brooks", 24, 1.10, 1.07, 0.96),
          ("T. Okafor", 44, 1.26, 0.92, 0.84), ("R. Santos", 9, 1.18, 0.96, 0.90), ("K. Nakamura", 31, 1.00, 1.02, 1.00),
          ("L. Murphy", 18, 0.90, 1.00, 1.06), ("P. Dubois", 5, 0.86, 1.05, 1.12), ("S. Kowalski", 2, 0.82, 0.96, 0.95)]
# bat trade-offs: (power, hit window). A heavy dark bat hits it farther, a light blonde bat is easier to time.
BAT_TRAITS = {"Natural": (1.00, 1.00), "Blonde": (0.92, 1.07), "Black": (1.10, 0.95), "Cherry": (1.12, 0.93),
              "Red": (1.05, 0.98), "Two-Tone": (1.00, 1.03), "Driftwood": (0.95, 1.05), "Navy": (1.06, 0.97)}
POWER_UPGRADE = 1.1              # how strongly (power - 1) turns singles into doubles / doubles into homers (and the reverse)
ON_FIRE_STREAK = 3               # this many good swings in a row and the batter is ON FIRE...
ON_FIRE_CONTACT = 1.08           # ...which makes the hit window this much bigger until he has a bad swing
FATIGUE_START = 35               # after this many pitches the pitcher starts to tire...
FATIGUE_SPAN = 40                # ...and is completely gassed this many pitches later
FATIGUE_SLOWDOWN = 0.10          # a gassed pitcher throws this much slower
TAG_DELAY = 0.25                 # a runner tagging up waits for the catch, then takes off after this long
TAG_SPEED_MULT = 2.4             # a tagging runner sprints (RUNNER_SPEED is slow for jogging around the bases)
TAG_RISK = 0.30                  # runners go on a fly ball if they think they beat the throw by this much (or less)
FORCE_RUN_MULT = 1.35            # runners forced to run on a ground ball (double play chances) get a quick start
FIELD_ERROR_CHANCE = 0.06        # a ground ball is bobbled (once per play)
THROW_ERROR_CHANCE = 0.05        # a throw to a base is wild (once per play)
ROB_CHANCE = 0.05                # a SHORT homer (under ROB_MAX_FT) is robbed at the wall
ROB_MAX_FT = 400
ROB_FEET_Y, ROB_JUMP, ROB_END_Y = 146, 22, 92     # batting view: where the robber stands, how high he jumps, where the ball ends up
FLIP_MIN_FT = 420                # a homer this long gets a bat flip...
FLIP_CHANCE = 0.5
FLIP_START = 0.55                # seconds into the swing when the bat leaves his hands
WEATHER_WEIGHTS = [("Clear", 38), ("Night", 26), ("Rain", 16), ("Windy", 20)]
WEATHER_OPTIONS = ["Random", "Clear", "Night", "Rain", "Windy"]     # start-screen choices ("Random" = rolled with WEATHER_WEIGHTS)
WEATHER_NAMES = {"Random": "RANDOM", "Clear": "SUNNY", "Night": "NIGHT", "Rain": "RAIN", "Windy": "WINDY"}
STRETCH_INNING = 7               # the seventh-inning stretch happens after this inning (if the game is that long)

DUGOUTS = {"left": (150, 672), "right": (1130, 672)}   # the home dugout is the left one: batters who make an out walk there and disappear inside
LOC_NAMES = ["inside", "middle", "outside"]      # zone -1 / 0 / +1
ZONE_WEIGHTS = (25, 50, 25)                      # normal chance of inside / middle / outside
CHANGEUP_HOT_START = 1.9                         # bigger = the changeup looks faster out of the hand (and slower at the end)

# --- Stealing ----------------------------------------------------------------
# chance the runners get the bag when you press S before this pitch
STEAL_CHANCE = {"Fastball": 0.30, "Curveball": 0.50, "Slider": 0.50, "Changeup": 0.50, "Splitter": 0.60}

# --- Foul balls --------------------------------------------------------------
FOUL_CAUGHT_CHANCE = 0.10        # a foul pop that gets caught = an out
FOUL_TIP_CHANCE = 0.12           # with two strikes, a foul can be a foul tip into the catcher's mitt = strikeout

# --- Reading the seams (magnified ball in the top-right corner of the batting view) ---
SHOW_SEAM_WINDOW = True          # False hides the window entirely
SHOW_SEAM_LEGEND = True          # False hides the little answer key under the window
SEAM_PREVIEW_TIME = 0.15         # the window opens this long BEFORE release so you get a head start
# (spin speed in radians/second, tilt of the spin axis). Negative = seams roll UP (backspin), positive = DOWN.
SEAM_SPIN = {"Fastball": (-16.0, 0.0), "Curveball": (7.5, 0.3), "Splitter": (0.9, 0.6),
             "Changeup": (-8.0, 0.0), "Slider": (8.5, 1.5)}
SEAM_LEGEND_TEXT = {"Fastball": "seams UP = fastball", "Curveball": "seams DOWN = curve", "Splitter": "no spin = splitter",
                    "Changeup": "slower UP = change", "Slider": "tilted = slider"}

# --- Timing windows (seconds away from the perfect swing; smaller = harder) ---
# These are the MEDIUM values; the difficulty's "window" number scales all of them.
PERFECT_PERFECT_WINDOW = 0.007   # guaranteed home run (about one frame wide at 60 FPS - very tight!)
PERFECT_WINDOW = 0.03
GOOD_WINDOW = 0.08
CONTACT_WINDOW = 0.16            # inside this you make contact
FOUL_WINDOW = 0.24               # between CONTACT and this = foul, beyond = swing and miss
METER_EXTRA_TIME = 0.25

# --- What contact turns into -------------------------------------------------
# For each contact quality: (cumulative chance, result)
HIT_TABLES = {
    "perfect_perfect": [(1.00, "HR")],
    "perfect":         [(0.28, "HR"), (0.48, "2B"), (0.55, "3B"), (0.80, "1B"), (0.92, "GROUND_OUT"), (1.00, "FLY_OUT")],
    "good":            [(0.28, "1B"), (0.36, "2B"), (0.78, "GROUND_OUT"), (1.00, "FLY_OUT")],
    "weak":            [(0.18, "1B"), (0.76, "GROUND_OUT"), (1.00, "FLY_OUT")],
}
# earned:   bases that runners ALREADY on base advance by themselves on this hit
#           (the batter never runs automatically - you click Run)
# flight:   seconds the ball is in the air
# distance: (min, max) pixels from home plate where the ball lands on the field view
# arc:      how high the ball flies (0 = bouncing grounder)
HIT_INFO = {
    "1B":         dict(earned=1, flight=1.7, distance=(240, 300), arc=85),
    "2B":         dict(earned=2, flight=2.2, distance=(320, 370), arc=125),
    "3B":         dict(earned=3, flight=3.0, distance=(390, 440), arc=160),
    "HR":         dict(earned=4, flight=1.6, distance=(0, 0),     arc=0),
    "FLY_OUT":    dict(earned=0, flight=2.4, distance=(270, 380), arc=170),
    "GROUND_OUT": dict(earned=0, flight=0.9, distance=(120, 210),  arc=0),
}

# --- Fielding ----------------------------------------------------------------
BALL_SPEED = 1.2                 # balls in play travel this much faster than the HIT_INFO flight times (1.0 = original; home runs unchanged)
FIELDER_SPEED = 50              # pixels per second (smaller = slower fielders = easier extra bases)
FIELDER_REACTION = 0.7          # seconds a fielder takes to read a fly ball before he starts moving
FIELDER_MISJUDGE = 35            # a fielder runs to where he THINKS a fly ball will land: off by up to this many pixels
# CATCH CIRCLE: when a fly ball lands, it is caught if it comes down inside this many pixels of the fielder.
# Worse contact = bigger circle = more likely to be an out. Anything outside the circle falls in for a hit.
CATCH_RADIUS = {"perfect": 20, "good": 34, "weak": 50}
FIELDER_PICKUP_TIME = 0.5        # seconds a fielder takes to gather a loose ball before throwing
RELAY_TIME = 0.25                # seconds to catch a throw and throw it on (a quick relay)
THROW_SPEED = 500                # pixels per second
BAG_RADIUS = 20                  # a fielder this close to a bag, holding the ball, "is at the base"
DEAD_BALL_DELAY = 0.6            # pitcher has the ball and nobody is running -> play ends after this
CUTOFF_MIN_THROW = 330           # outfield throws longer than this go through a cutoff man (SS or 2B)
BACKUP_DISTANCE = 55             # a backup fielder stands this far behind where the ball lands

# --- Catch / landing effects (so a fly out looks different from a hit that falls in) ---
HIT_ROLL_SPEED = 215             # how fast a ball that falls in keeps rolling after it lands (pixels/second)
GROUNDER_ROLL_SPEED = 105         # same, for ground balls
ROLL_DRAG = 1.6                  # bigger = the ball stops rolling sooner
CATCH_FX_TIME = 1.2              # seconds the white "CAUGHT!" effect lasts

# --- Baserunning -------------------------------------------------------------
RUNNER_SPEED = 0.6               # bases per second
BATTER_START_DELAY = 0.75        # the batter finishes his swing, drops the bat and gets going (bigger = easier to throw him out at first)
RUNNER_START_DELAY = 0.2         # reaction time after contact before runners ALREADY on base take off
OUT_CALL_RANGE = 0.35             # force play at first: a batter this close (in bases) to the bag, with the fielder already there holding the ball, is out
SLIDE_RANGE = 0.45               # when closer than this (in bases) to the bag, the button says SLIDE
SLIDE_SPEED_MULT = 1.8           # a slide covers the last stretch this much faster...
SLIDE_RECOVERY = 0.5             # ...but you need this long to get up before you can run again
TURN_COOLDOWN = 0.35             # after sending (or turning) the runner, he can't be turned again for this long
FIELD_PLAY_TIMEOUT = 25          # safety: force the play to end after this many seconds

# --- Messages ----------------------------------------------------------------
MESSAGE_TIME = 1.6
HOME_RUN_MESSAGE_TIME = 2.0
NEXT_PITCH_DELAY = 0.6           # seconds before the NEXT PITCH button appears (only after a ball in play)
NEXT_BUTTON = (1160, 590)        # where the round NEXT PITCH button sits on the canvas
NEXT_BUTTON_RADIUS = 72

# --- Screen shake on solid contact -------------------------------------------
SHAKE_TIME = 0.3                 # seconds
SHAKE_PERFECT = 8                # pixels of shake for a PERFECT hit
SHAKE_PERFECT_PERFECT = 13       # pixels of shake for a PERFECT PERFECT hit (when there is no cutscene)

# --- PERFECT PERFECT home run cutscene (side view, Mario Super Sluggers style) --
SLUGGER_CUTSCENE = True          # False = a PERFECT PERFECT homer just uses the normal home run animation
SLUGGER_HIT_TIME = 0.8           # seconds of slow-motion wind-up before the bat meets the ball
SLUGGER_TIME = 2.8               # total cutscene length (the rest of the time the camera follows the ball)
SLUGGER_HITSTOP = 0.12           # the picture freezes this long on the connecting swing (explosion + flash play over it)

# --- Rare animations ---------------------------------------------------------
# Each chance is rolled when that kind of play happens (0 = never, 1 = every time).
DIVE_CHANCE = 0.10               # on a ground ball, the fielder dives for it
LEAP_CHANCE = 0.15               # on a fly out, the fielder leaps for the catch
BROKEN_BAT_CHANCE = 0.10         # on weak contact, the bat snaps
FAN_CATCH_CHANCE = 0.10          # on a home run into the seats (not over the scoreboard), a fan catches it
BOARD_X_MIN, BOARD_X_MAX = 292, 478   # a home run that ends up between these x positions hits the scoreboard
BOARD_HIT_CHANCE = 0.10          # a home run headed over the scoreboard only actually hits it this often
BOARD_ANIM_TIME = 3.0           # seconds the scoreboard rocks / flickers
DIVE_TIME = 0.5                  # seconds of the dive itself
DIVE_RECOVERY = 0.5              # seconds he lies there / gets up before he can throw
LEAP_TIME = 1.0                  # length of the jump (the catch happens at the top, halfway through)
LEAP_HEIGHT = 36                 # how high (pixels) the fielder rises
FIELDER_SCALE = 1.3              # size of the fielders on the field view
LEAP_GLOVE_Z = LEAP_HEIGHT + 47 * FIELDER_SCALE - 4   # glove height above the ground at the top of the jump
BROKEN_BAT_TIME = 1.4            # how long the flying bat pieces are drawn
FAN_SCALE = 0.3                 # how big the fan is (1.0 = the old giant fan)

# (name, one-line description, seconds long) - this is the list shown in the pause menu's Animations gallery
ANIMATIONS = [
    ("Slugger Cutscene", "PERFECT PERFECT swing = guaranteed home run", SLUGGER_TIME),
    ("Diving Stop", f"Ground balls: {round(DIVE_CHANCE * 100)}% chance", 2.9),
    ("Leaping Catch", f"Fly outs: {round(LEAP_CHANCE * 100)}% chance", 3.0),
    ("Broken Bat", f"Weak contact: {round(BROKEN_BAT_CHANCE * 100)}% chance", 2.4),
    ("Fan Catch", f"Home runs into the seats: {round(FAN_CATCH_CHANCE * 100)}% chance", 3.0),
    ("Scoreboard Hit", f"Home runs over the scoreboard: {round(BOARD_HIT_CHANCE * 100)}% chance", 4.4),
    ("Robbed at the Wall", f"Short homers (under {ROB_MAX_FT} ft): {round(ROB_CHANCE * 100)}% chance", 3.8),
    ("Bat Flip", f"Moonshots ({FLIP_MIN_FT}+ ft): {round(FLIP_CHANCE * 100)}% chance", 3.6),
    ("On Fire", f"{ON_FIRE_STREAK} good swings in a row = a bigger hit window", 3.4),
    ("Close Play: Safe", "A true cutscene: slow-mo dive, runner beats the tag", 4.4),
    ("Close Play: Out", "A true cutscene: slow-mo dive, runner gets tagged", 4.4),
]
ANIM_PAGE = 6                    # how many animations fit on one page of the pause menu's gallery

# --- close plays: the runner and the throw arrive at a bag together -> slow motion + the umpire's call ---------
CLOSE_BALL_RADIUS = 75           # the ball (thrown or held) is this close (pixels) to the bag...
CLOSE_RUNNER_RANGE = 0.5         # ...while the runner is within this many bases of it
CLOSE_SLOW = 0.4                 # how slow the slow motion is (1.0 = normal speed)
CLOSE_SLOW_TIME = 2.4            # seconds of slow motion at most (until the runner reaches the bag)
CLOSE_SHOW_TIME = 2.3            # how long the cutscene stays up after the runner reaches the bag (the call is made in the middle)

# --- Field geometry (canvas pixels) ------------------------------------------
HOME, B1, B2, B3 = (610, 610), (880, 470), (650, 345), (360, 470)
BASES = [HOME, B1, B2, B3, HOME]            # index = base number (4 = home again)
MOUND = (630, 478)
BASE_NAMES = ["first", "second", "third", "home"]
FIELDER_POSTS = {                           # where each fielder stands at the start of a play
    "P": MOUND, "C": (610, 640), "1B": (905, 452), "2B": (700, 352), "SS": (520, 365),
    "3B": (330, 452), "LF": (215, 272), "CF": (640, 252), "RF": (1065, 277),
}
BASE_FIELDERS = {1: "1B", 2: "2B", 3: "3B", 4: "C"}   # who receives a throw to each base

# --- Batting-view positions --------------------------------------------------
BAT_RELEASE_POINT = (387, 212)
BAT_FIELDERS = [(60, 175, 1.3), (240, 150, 1.0), (525, 150, 1.0), (705, 165, 1.3),
                (120, 138, 0.8), (392, 126, 0.8), (615, 138, 0.8)]   # (x, y, size) - just for looks

# --- Colours -----------------------------------------------------------------
WHITE, BLACK = (255, 255, 255), (0, 0, 0)
SLIDE_GREEN = (46, 190, 80)           # colour of the Slide button (Run is teal)
GOLD, RED, GREEN, TEAL = (242, 201, 76), (255, 90, 74), (93, 255, 122), (24, 190, 190)

# =============================================================================
# 2. DATA CLASSES  -  bundles of related values
# =============================================================================

@dataclass
class Pitch:
    name: str
    duration: float            # seconds from release to the plate
    mph: int
    hittable: bool
    time: float = 0.0
    swung: bool = False
    swing_time: float = 0.0
    label: str = ""            # "PERFECT", "EARLY", ... shown on the meter
    result: str = ""           # "", "miss" or "foul"
    zone: int = 0              # -1 inside, 0 middle, +1 outside
    offset: float = 0.0        # the perfect swing is at duration + offset (inside = earlier, outside = later)


@dataclass
class Hit:
    kind: str                  # "1B" "2B" "3B" "HR" "FLY_OUT" "GROUND_OUT"
    quality: str
    start_x: float             # where the ball was when you hit it (batting view)
    start_y: float
    sideways: float            # negative = pulled to left field, positive = right field
    flight: float
    arc: float
    land_x: float = 0.0        # where it lands on the FIELD view
    land_y: float = 0.0
    time: float = 0.0
    broken_bat: bool = False   # rare animation: the bat snapped on this swing
    distance: int = 0          # home run distance in feet (changes how high / far the ball flies)
    caught: bool = False       # fly balls: did it land inside the catch circle?
    read_x: float = 0.0        # where the fielder THINKS the ball will land (he runs here)
    read_y: float = 0.0
    catch_x: float = 0.0       # if caught: where the fielder is standing when it arrives
    catch_y: float = 0.0
    robbed: bool = False       # a short homer an outfielder leaps and steals at the wall
    flip: bool = False         # a long homer: the batter flips his bat


@dataclass
class Ball:
    x: float
    y: float
    z: float = 0.0             # height above the ground (drawn as an upward offset)
    mode: str = "flying"       # "flying" (off the bat) | "loose" (on the ground) | "held" | "thrown"
    holder: int = -1           # index of the fielder holding it
    hold_time: float = 0.0     # how long the holder has had it
    quick: bool = False        # True if he just caught a throw (relay) instead of picking up a loose ball
    t: float = 0.0             # animation clock for flying / thrown
    dur: float = 1.0           # duration of the current throw
    sx: float = 0.0            # throw start / end points
    sy: float = 0.0
    tx: float = 0.0
    ty: float = 0.0
    receiver: int = -1
    vx: float = 0.0            # rolling velocity after landing
    vy: float = 0.0
    bt: float = 0.0            # seconds since it landed (drives the bounce)


@dataclass
class Fielder:
    name: str
    post: tuple                # where he wants to stand
    x: float
    y: float


@dataclass
class Runner:
    """The batter after contact - the runner YOU control."""
    earned: int                # guaranteed bases
    moving: bool = True
    wait: float = 0.0          # reaction delay before the first step
    pos: float = 0.0           # 0=home, 1=first, 2=second, 3=third, 4=scored
    target: int = 1            # base he is running toward (or back toward)
    forward: bool = True
    sliding: bool = False
    run_through: bool = False  # player pressed R: don't stop at the next bag
    turn_cooldown: float = 0.0
    recovery: float = 0.0      # getting up after a slide


@dataclass
class FieldPlay:
    hit: Hit
    runner: Runner
    fielders: list
    ball: Ball
    others: list               # other runners already on base: dicts (start, end, pos)
    others_runs: int           # runs those runners will score
    new_bases: list            # where those runners end up
    index: dict                # fielder name -> index
    chaser: int                # the fielder going after the ball
    boost: float               # chaser speed multiplier (guarantees fly-ball catches)
    time: float = 0.0
    pending: tuple = None      # (outcome, base) once the play is decided
    pending_time: float = 0.0  # how long to wait before showing the result
    dead_time: float = 0.0
    dive_plan: bool = False    # rare animation: this ground ball will get a diving stop
    dive: dict = None          # the dive in progress: idx (fielder), t (seconds), dir (-1 left / +1 right)
    dived: bool = False
    leap_plan: bool = False    # rare animation: this fly out will get a leaping catch
    leap: dict = None          # the leap in progress: t (seconds)
    leaped: bool = False
    broken: dict = None        # the broken bat: t (seconds), dir (unit vector the pieces fly along)
    catch: dict = None         # a fly ball was caught: t (seconds)
    landed: dict = None        # a hit landed on the grass: t, x, y (dust puff)
    skin: tuple = None         # the batter-runner's skin tone
    gait: dict = field(default_factory=dict)      # step-cycle phase for every moving player (drives the sway)
    prev: dict = field(default_factory=dict)      # where each player was last frame
    moving: set = field(default_factory=set)      # who is moving right now
    dust: list = field(default_factory=list)      # dust / grass particles under running feet
    walk: dict = None          # after an out: the batter walking back to the dugout (sx, sy, tx, ty, t, done)
    error: bool = False        # a fielder booted the ball or threw it away
    error_done: bool = False   # (only one bobble per play)
    throw_error_done: bool = False
    fumble: dict = None        # {fielder index: seconds left} - he has lost the ball / missed the catch and can't grab it yet
    error_fx: dict = None      # the "ERROR!" label: t (seconds), x, y
    close: dict = None         # a close play at a bag: base, t, result ("safe" / "out" / None until called), tres
    close_done: bool = False   # (one close play per at-bat)


# =============================================================================
# 3. DRAWING HELPERS  -  these only draw, they never change the game
# =============================================================================

_font_cache = {}
_title_font_cache = {}

def get_font(size):
    if size not in _font_cache:
        _font_cache[size] = pygame.font.SysFont("verdana,dejavusans,arial", size, bold=True)
    return _font_cache[size]


def get_title_font(size):
    """The big lettering font: your own title_font.ttf if present, else a heavy system font, else a bold fallback."""
    if size not in _title_font_cache:
        font = None
        if os.path.exists(TITLE_FONT_FILE):
            try:
                font = pygame.font.Font(TITLE_FONT_FILE, size)
            except pygame.error:
                font = None
        if font is None:
            path = pygame.font.match_font(TITLE_FONT_NAMES)
            if path:
                font = pygame.font.Font(path, size)
                font.set_italic(True)                         # slanted for speed
            else:
                font = pygame.font.SysFont("verdana,dejavusans,arial", size, bold=True, italic=True)
        _title_font_cache[size] = font
    return _title_font_cache[size]


def draw_text(surface, text, x, y, size=16, color=WHITE, outline=True, align="center"):
    """Text with a black outline so it reads on any background. (x, y) is the baseline position."""
    font = get_font(size)
    image = font.render(text, True, color)
    rect = image.get_rect()
    setattr(rect, {"center": "midtop", "left": "topleft", "right": "topright"}[align], (x, y - size))
    if outline:
        shadow = font.render(text, True, BLACK)
        for dx, dy in ((-2, 0), (2, 0), (0, -2), (0, 2), (-2, -2), (2, 2), (-2, 2), (2, -2)):
            surface.blit(shadow, rect.move(dx, dy))
    surface.blit(image, rect)


def lerp(a, b, t):
    return a + (b - a) * t


def clamp(value, low, high):
    return max(low, min(high, value))


def point_on_path(pos):
    """Screen position for a base-path position (0..4)."""
    pos = clamp(pos, 0, 4)
    i = min(3, int(pos))
    t = pos - i
    return lerp(BASES[i][0], BASES[i + 1][0], t), lerp(BASES[i][1], BASES[i + 1][1], t)


def unit(dx, dy):
    n = math.hypot(dx, dy)
    return dx / n, dy / n


U_LEFT = unit(B3[0] - HOME[0], B3[1] - HOME[1])      # direction of the left-field foul line
U_RIGHT = unit(B1[0] - HOME[0], B1[1] - HOME[1])     # direction of the right-field foul line


def _grass_polygon():
    """The outline of the outfield lawn (the same shape the background draws)."""
    half = LOGICAL_W / 2
    arc = [math.pi * i / 40 for i in range(41)]
    grass_top = [(half + half * math.cos(a), 268 - 72 * math.sin(a)) for a in reversed(arc)]
    left_end = (0, HOME[1] + U_LEFT[1] * (HOME[0] / -U_LEFT[0]))
    right_end = (LOGICAL_W, HOME[1] + U_RIGHT[1] * ((LOGICAL_W - HOME[0]) / U_RIGHT[0]))
    return [HOME, left_end] + grass_top + [right_end]


GRASS_POLY = _grass_polygon()


def point_in_polygon(x, y, poly):
    inside, j = False, len(poly) - 1
    for i in range(len(poly)):
        xi, yi = poly[i]
        xj, yj = poly[j]
        if (yi > y) != (yj > y) and x < (xj - xi) * (y - yi) / (yj - yi) + xi:
            inside = not inside
        j = i
    return inside


def dist_to_segment(px, py, a, b):
    abx, aby = b[0] - a[0], b[1] - a[1]
    t = clamp(((px - a[0]) * abx + (py - a[1]) * aby) / (abx * abx + aby * aby), 0, 1)
    return math.hypot(px - (a[0] + abx * t), py - (a[1] + aby * t))


def terrain_at(x, y):
    """What a player is standing on in the field view: 'sand' (infield dirt: base paths, base circles, mound, home),
    'grass' (the lawn) or 'track' (the red warning track / foul ground)."""
    if math.hypot(x - HOME[0], y - HOME[1]) < 78 or math.hypot(x - MOUND[0], y - MOUND[1]) < 34:
        return "sand"
    if any(math.hypot(x - b[0], y - b[1]) < 50 for b in (B1, B2, B3)):
        return "sand"
    if any(dist_to_segment(x, y, BASES[i], BASES[i + 1]) < 37 for i in range(4)):
        return "sand"
    return "grass" if point_in_polygon(x, y, GRASS_POLY) else "track"


# shadow colour and dust for each surface. "blades" = bits of grass flung up, "puff" = a little cloud of dirt
TERRAIN = {
    "grass": dict(shadow=(35, 85, 35),  dust=[(92, 172, 70), (66, 140, 56), (122, 192, 92)], kind="blades"),
    "sand":  dict(shadow=(150, 98, 58), dust=[(226, 184, 132), (208, 160, 106), (190, 140, 90)], kind="puff"),
    "track": dict(shadow=(104, 56, 40), dust=[(178, 110, 82), (156, 92, 66), (192, 124, 92)], kind="puff"),
}


def landing_spot(kind, sideways):
    """Where a batted ball lands on the field. Early swings pull to left, late swings go to right."""
    t = (sideways + 300) / 600
    if kind not in ("GROUND_OUT", "HR") and random.random() < 0.65:      # most hits find a gap (left-center / right-center)
        gap = 0.27 if t < 0.5 else 0.73
        t += (gap - t) * 0.6
    elif kind == "GROUND_OUT" and random.random() < 0.3:                  # some grounders go through the holes
        gap = 0.3 if t < 0.5 else 0.7
        t += (gap - t) * 0.5
    ux, uy = unit(lerp(U_LEFT[0], U_RIGHT[0], t), lerp(U_LEFT[1], U_RIGHT[1], t))
    lo, hi = HIT_INFO[kind]["distance"]
    d = random.uniform(lo, hi)
    return clamp(HOME[0] + ux * d, 80, 1200), clamp(HOME[1] + uy * d, 262, 700)


def draw_person(surf, x, y, scale=1.0, body=(40, 60, 120), cap=(30, 40, 90), sliding=False, shadow=True,
                skin=SKIN_DEFAULT, shadow_color=(35, 85, 35), sway=0.0, bob=0.0):
    """A tiny baseball person. (x, y) is where his feet are. sway / bob (pixels) make a running player rock side to side
    and bounce a little; the shadow stays on the ground and takes the colour of whatever he is standing on."""
    s = scale
    if shadow:
        pygame.draw.ellipse(surf, shadow_color, (x - 11 * s, y - 3 * s, 22 * s, 8 * s))      # shadow
    if sliding:
        pygame.draw.ellipse(surf, body, (x - 15 * s, y - 11 * s, 30 * s, 11 * s))
        pygame.draw.circle(surf, skin, (x + 14 * s, y - 8 * s), 5 * s)
        pygame.draw.circle(surf, cap, (x + 14 * s, y - 9.5 * s), 5.5 * s, draw_top_left=True, draw_top_right=True)    # helmet stays on
        pygame.draw.line(surf, cap, (x + 16 * s, y - 9 * s), (x + 21 * s, y - 8 * s), max(1, int(2 * s)))             # brim, pointing where he slides
        return
    top = y - bob                                                  # the body lifts off the ground a touch with each step
    pygame.draw.ellipse(surf, body, (x - 6 * s + sway * 0.5 * s, top - 26 * s, 12 * s, 26 * s))
    pygame.draw.circle(surf, skin, (x + sway * s, top - 31 * s), 5 * s)
    pygame.draw.circle(surf, cap, (x + sway * s, top - 33 * s), 5.5 * s, draw_top_left=True, draw_top_right=True)


def build_default_logo(name, color):
    """The home team's logo until you draw one: a badge in the team colour with the team's first letter."""
    s = pygame.Surface((LOGO_PX, LOGO_PX), pygame.SRCALPHA)
    dark = tuple(int(c * 0.6) for c in color)
    pygame.draw.circle(s, color, (24, 24), 23)
    pygame.draw.circle(s, WHITE, (24, 24), 23, 3)
    pygame.draw.circle(s, dark, (24, 24), 17, 2)
    letter = (name.strip()[:1] or "H").upper()
    image = get_font(26).render(letter, True, WHITE)
    s.blit(image, image.get_rect(center=(24, 25)))
    return s


def build_cpu_logo():
    """The CPU team's logo: a dark shield with a red border."""
    s = pygame.Surface((LOGO_PX, LOGO_PX), pygame.SRCALPHA)
    shield = [(5, 5), (43, 5), (43, 26), (24, 44), (5, 26)]
    pygame.draw.polygon(s, (58, 64, 86), shield)
    pygame.draw.polygon(s, (225, 60, 60), shield, 3)
    image = get_font(13).render("CPU", True, WHITE)
    s.blit(image, image.get_rect(center=(24, 20)))
    pygame.draw.rect(s, (225, 60, 60), (14, 28, 20, 3))
    return s


def compose_logo(drawing, color):
    """Your drawing, stitched onto a patch in the team colour."""
    s = pygame.Surface((LOGO_PX, LOGO_PX), pygame.SRCALPHA)
    pygame.draw.rect(s, color, (0, 0, LOGO_PX, LOGO_PX), border_radius=9)
    s.blit(drawing, (0, 0))
    pygame.draw.rect(s, WHITE, (0, 0, LOGO_PX, LOGO_PX), 2, border_radius=9)
    return s


def draw_logo(surf, logo, x, y, size):
    surf.blit(pygame.transform.smoothscale(logo, (size, size)), (x, y))


def draw_button(surf, x, y, label, color=TEAL):
    """The Run (teal) / Slide (green) button: ellipse on the bag, an up-arrow, and a label."""
    rect = pygame.Rect(0, 0, 70, 32)
    rect.center = (x, y)
    pygame.draw.ellipse(surf, color, rect)
    pygame.draw.ellipse(surf, (225, 255, 235), rect, 2)
    pygame.draw.polygon(surf, color, [(x, y + 20), (x - 13, y + 36), (x + 13, y + 36)])
    pygame.draw.rect(surf, color, (x - 5, y + 36, 10, 12))
    draw_text(surf, label, x, y + 72, 20, color)


def draw_next_pitch_button(surf, t):
    """Big round glossy NEXT PITCH button, shown after every ball in play."""
    x, y = NEXT_BUTTON
    r = NEXT_BUTTON_RADIUS + int(3 * math.sin(t * 5))                  # gentle pulse
    pygame.draw.circle(surf, (15, 30, 40), (x, y + 5), r + 6)            # shadow
    pygame.draw.circle(surf, (195, 210, 220), (x, y), r + 4)             # silver rim
    pygame.draw.circle(surf, (22, 140, 155), (x, y), r)                  # teal body
    pygame.draw.ellipse(surf, (80, 215, 225), (x - r * 0.72, y - r * 0.95, r * 1.44, r * 0.85))   # gloss
    draw_text(surf, "NEXT", x, y - 4, 30)
    draw_text(surf, "PITCH", x, y + 30, 30)


def fill_polygon_stripes(surf, points, color_a, color_b, band=26):
    """Fill a (convex) polygon with horizontal mowing stripes."""
    ys = [p[1] for p in points]
    for y in range(int(min(ys)), int(max(ys)) + 1):
        xs = []
        for (x1, y1), (x2, y2) in zip(points, points[1:] + points[:1]):
            if y1 <= y < y2 or y2 <= y < y1:
                xs.append(x1 + (y - y1) * (x2 - x1) / (y2 - y1))
        if len(xs) >= 2:
            pygame.draw.line(surf, color_a if (y // band) % 2 else color_b, (min(xs), y), (max(xs), y))


# --- the living crowd + the dugouts --------------------------------------------------
CROWD_COLORS = [(150, 110, 100), (190, 180, 170), (120, 125, 140), (170, 70, 70), (210, 200, 120), (90, 120, 170), (205, 205, 215)]
CROWD_BASE_ENERGY = 0.18         # how lively the crowd is when nothing is happening (0 = statues)
CROWD_DECAY = 0.30               # energy drained per second after a cheer
CROWD_WAVE_EVERY = 28.0          # seconds between "stadium waves" while things are quiet
CROWD_WAVE_LENGTH = 7.0          # how long each wave lasts
CROWD_TEAM_FANS = 0.12           # fraction of the crowd wearing your team colour
CROWD_CPU_FANS = 0.08            # ...and the CPU's red


def build_field_crowd():
    """Positions + personalities for every fan in the overhead view's stands."""
    rnd, crowd, half = random.Random(11), [], LOGICAL_W / 2
    while len(crowd) < 1300:                                 # about the same fans per square inch as the batting view's stands
        x = rnd.random() * LOGICAL_W
        wall_y = 240 - 70 * math.sqrt(max(0, 1 - ((x - half) / half) ** 2))
        if wall_y - 12 > 108:
            crowd.append(make_fan(rnd, x, rnd.uniform(108, wall_y - 12), 4))
    return crowd


def build_bat_crowd():
    """Fans for the batting view's stands (smaller squares)."""
    rnd = random.Random(12)
    return [make_fan(rnd, rnd.random() * BAT_W, 31 + rnd.random() * 82, 3) for _ in range(980)]


def make_fan(rnd, x, y, size):
    roll = rnd.random()
    kind = 1 if roll < CROWD_TEAM_FANS else 2 if roll < CROWD_TEAM_FANS + CROWD_CPU_FANS else 0
    return (x, y, rnd.randrange(len(CROWD_COLORS)), rnd.randrange(len(CROWD_COLORS)), rnd.random() * 6.283,
            rnd.uniform(2.2, 4.6), size, kind)


CROWD_KEEP = {"Windy": 0.7, "Rain": 0.4}      # share of the fans who turn up in bad weather (clear and night = everybody)


def draw_crowd(surf, crowd, t, energy, team_color, width, keep=1.0):
    """Every fan bobs, sways and sometimes changes colour (a new jersey, a jacket coming off...). The bigger the energy,
    the higher they jump, and fans with energy to spare throw their arms up. Now and then a stadium wave rolls across
    and a few camera flashes pop."""
    e = clamp(CROWD_BASE_ENERGY + energy, 0, 1.4)
    amp = 0.7 + 4.2 * e
    wave_on = (t % CROWD_WAVE_EVERY) < CROWD_WAVE_LENGTH or e > 0.85
    wave_phase = t * 3.2
    fill = surf.fill
    sin = math.sin
    for x, y, c1, c2, phase, rate, size, kind in crowd:
        if keep < 1.0 and (phase * 7.31) % 1.0 >= keep:
            continue                                                                   # this fan stayed home
        local = t * rate + phase
        lift = max(0.0, sin(local)) * amp
        if wave_on:
            lift += max(0.0, sin(x / width * 9.4 - wave_phase)) * (3 + 2 * e)
        if kind == 1:
            color = team_color
        elif kind == 2:
            color = (205, 60, 60)
        else:
            color = CROWD_COLORS[c2 if int(t * 0.4 + phase * 3) % 5 == 0 else c1]      # an occasional change of colour
        px, py = x + sin(local * 0.6 + phase) * (0.7 + e), y - lift
        fill(color, (px, py, size, size))
        if lift > 2.6 + size * 0.2:                                                    # arms up!
            fill(color, (px - 1, py - 2, 1, 3))
            fill(color, (px + size, py - 2, 1, 3))
        if int(t * 12 + phase * 50) % 1100 == 0:                                       # a camera flash
            fill((255, 255, 255), (px - 2, py - 2, size + 4, size + 4))


def draw_dugout_back(surf, dx, dy):
    """The part of a dugout that never moves: concrete apron, roof, dark interior, bench, water cooler, bat rack."""
    pygame.draw.rect(surf, (112, 116, 124), (dx - 80, dy - 46, 160, 76), border_radius=7)               # concrete apron
    pygame.draw.rect(surf, (140, 144, 152), (dx - 80, dy - 46, 160, 76), 2, border_radius=7)
    pygame.draw.rect(surf, (24, 26, 34), (dx - 70, dy - 38, 140, 52), border_radius=5)                  # dark interior
    for i in range(-4, 5):                                                                              # back-wall slats
        pygame.draw.line(surf, (36, 39, 50), (dx + i * 15, dy - 36), (dx + i * 15, dy + 4), 2)
    pygame.draw.rect(surf, (66, 72, 92), (dx - 74, dy - 48, 148, 14), border_radius=4)                  # roof
    pygame.draw.rect(surf, (112, 120, 144), (dx - 74, dy - 48, 148, 14), 2, border_radius=4)
    for i in range(-7, 8):
        pygame.draw.line(surf, (50, 55, 74), (dx + i * 10, dy - 46), (dx + i * 10, dy - 36), 1)         # roof ribs
    pygame.draw.rect(surf, (150, 108, 64), (dx - 64, dy - 1, 128, 9), border_radius=2)                  # wooden bench
    pygame.draw.rect(surf, (188, 142, 90), (dx - 64, dy - 1, 128, 3), border_radius=2)
    pygame.draw.rect(surf, (96, 66, 38), (dx - 64, dy + 6, 128, 3))
    for i in range(5):                                                                                  # bat rack on the left wall
        pygame.draw.line(surf, (214, 176, 90), (dx - 66 + i * 3, dy - 14), (dx - 64 + i * 3, dy - 30), 2)
    pygame.draw.rect(surf, (80, 84, 98), (dx - 69, dy - 15, 16, 3))
    pygame.draw.rect(surf, (230, 126, 30), (dx + 52, dy - 17, 11, 15), border_radius=2)                 # water cooler
    pygame.draw.rect(surf, (240, 240, 244), (dx + 50, dy - 20, 15, 4), border_radius=2)
    pygame.draw.circle(surf, (120, 190, 235), (dx + 57, dy - 9), 2)


def draw_dugout_front(surf, dx, dy):
    """The lip and railing in FRONT of the players (so they look like they are sitting inside)."""
    pygame.draw.rect(surf, (70, 76, 96), (dx - 72, dy + 8, 144, 11), border_radius=3)
    pygame.draw.rect(surf, (120, 128, 150), (dx - 72, dy + 8, 144, 3), border_radius=3)
    pygame.draw.line(surf, (214, 219, 228), (dx - 70, dy + 3), (dx + 70, dy + 3), 2)                    # railing
    for i in range(7):
        pygame.draw.rect(surf, (214, 219, 228), (dx - 70 + i * 23, dy + 3, 3, 7))


def draw_dugout_players(surf, dx, dy, body, cap, t, energy, seed):
    """Five teammates sitting on the bench. They bob and clap quietly, and jump up with their arms in the air when the
    team's energy is high. (energy: 0 = just sitting, 1 = going wild)"""
    for i in range(5):
        x = dx - 46 + i * 21
        phase = seed + i * 1.7
        lvl = clamp(0.12 + energy * 1.25 + 0.28 * math.sin(t * 0.5 + phase * 3), 0, 1.4)    # each guy gets excited on his own
        bounce = max(0.0, math.sin(t * (4.0 + i * 0.5) + phase)) * (0.6 + 3.6 * lvl) if lvl > 0.35 else 0.0
        by = dy + 7 - bounce
        skin = SKIN_TONES[(i * 3 + seed.__int__()) % len(SKIN_TONES)]
        pygame.draw.ellipse(surf, body, (x - 6.5, by - 21, 13, 21))                                    # torso
        if lvl > 0.5:                                                                                  # cheering: both arms up
            wave = math.sin(t * 9 + phase) * 2.5
            for sign in (-1, 1):
                hand = (x + sign * (9 + wave * 0.3), by - 31 + wave * sign * 0.4)
                pygame.draw.line(surf, body, (x + sign * 5, by - 17), hand, 3)
                pygame.draw.circle(surf, skin, hand, 2)
        else:                                                                                          # sitting: arms resting, a little head bob
            pygame.draw.line(surf, body, (x - 5, by - 16), (x - 7, by - 7), 3)
            pygame.draw.line(surf, body, (x + 5, by - 16), (x + 7, by - 7), 3)
        head_y = by - 25 + math.sin(t * 1.6 + phase) * (0.5 if lvl <= 0.5 else 0.0)
        pygame.draw.circle(surf, skin, (x, head_y), 4.6)
        pygame.draw.circle(surf, cap, (x, head_y - 1.5), 5, draw_top_left=True, draw_top_right=True)
        pygame.draw.rect(surf, cap, (x - 1, head_y - 2, 7, 2))                                         # cap brim


def build_field_background():
    """The overhead stadium: skyline, stands, wall, striped grass, dirt, bases, foul lines."""
    surf = pygame.Surface((LOGICAL_W, LOGICAL_H))
    surf.fill((150, 82, 58))                                              # red-brown dirt / warning track
    half = LOGICAL_W / 2
    arc = [math.pi * i / 40 for i in range(41)]                          # angles from right edge to left edge
    wall = [(half + half * math.cos(a), 240 - 70 * math.sin(a)) for a in arc]
    grass_top = [(half + half * math.cos(a), 268 - 72 * math.sin(a)) for a in reversed(arc)]  # left to right
    for y in range(0, 270):                                               # sky
        t = y / 270
        pygame.draw.line(surf, (int(lerp(60, 140, t)), int(lerp(100, 180, t)), int(lerp(160, 215, t))), (0, y), (LOGICAL_W, y))
    for _ in range(40):                                                   # skyline
        bx, bw, bh = random.randint(0, LOGICAL_W), random.randint(30, 80), random.randint(25, 85)
        pygame.draw.rect(surf, (random.randint(95, 130),) * 3, (bx, 100 - bh, bw, bh))
    pygame.draw.polygon(surf, (84, 76, 74), [(0, 100), (LOGICAL_W, 100)] + wall)        # stands
    # (the crowd is NOT painted here any more - build_field_crowd() makes it and draw_crowd() animates it every frame)
    pygame.draw.polygon(surf, (30, 80, 52), wall + [(x, y + 26) for x, y in reversed(wall)])  # outfield wall
    # grass: the wedge between the two foul lines
    left_end = (0, HOME[1] + U_LEFT[1] * (HOME[0] / -U_LEFT[0]))
    right_end = (LOGICAL_W, HOME[1] + U_RIGHT[1] * ((LOGICAL_W - HOME[0]) / U_RIGHT[0]))
    grass = [HOME, left_end] + grass_top + [right_end]
    fill_polygon_stripes(surf, grass, (58, 134, 52), (70, 150, 62))
    # infield dirt: thick base paths + circles around each base
    dirt = (198, 140, 86)
    for i in range(4):
        pygame.draw.line(surf, dirt, BASES[i], BASES[i + 1], 74)
    for p, r in ((B1, 50), (B2, 50), (B3, 50), (HOME, 78)):
        pygame.draw.circle(surf, dirt, p, r)
    cx = sum(p[0] for p in BASES[:4]) / 4
    cy = sum(p[1] for p in BASES[:4]) / 4
    pygame.draw.polygon(surf, (74, 158, 60), [(p[0] + (cx - p[0]) * 0.4, p[1] + (cy - p[1]) * 0.4) for p in BASES[:4]])
    pygame.draw.circle(surf, dirt, MOUND, 34)                             # pitcher's mound
    pygame.draw.rect(surf, WHITE, (MOUND[0] - 9, MOUND[1] - 2, 18, 4))
    pygame.draw.line(surf, WHITE, HOME, left_end, 3)                      # foul lines
    pygame.draw.line(surf, WHITE, HOME, right_end, 3)
    pygame.draw.circle(surf, WHITE, HOME, 62, 3)                          # chalk circle around home
    for bx in (HOME[0] - 54, HOME[0] + 26):                               # batter's boxes
        pygame.draw.rect(surf, WHITE, (bx, HOME[1] - 18, 28, 46), 2)
    for p in (B1, B2, B3):                                                # bags
        pygame.draw.polygon(surf, WHITE, [(p[0], p[1] - 10), (p[0] + 12, p[1]), (p[0], p[1] + 10), (p[0] - 12, p[1])])
    pygame.draw.polygon(surf, WHITE, [(HOME[0] - 11, HOME[1] - 8), (HOME[0] + 11, HOME[1] - 8), (HOME[0] + 11, HOME[1] + 2),
                                      (HOME[0], HOME[1] + 12), (HOME[0] - 11, HOME[1] + 2)])
    for dx, dy in DUGOUTS.values():                                       # the two dugouts, down in foul territory
        draw_dugout_back(surf, dx, dy)                                    # (players + front rail are drawn live)
    return surf


def draw_bat_wall(surf):
    """The outfield wall in the batting view: the same dark green as the running view's wall. (Drawn again on top of a fan
    who catches a home run, so he is behind it.)"""
    pygame.draw.rect(surf, (30, 80, 52), (0, 112, BAT_W, 22))
    pygame.draw.line(surf, (52, 118, 78), (0, 112), (BAT_W, 112), 2)                 # the padded top edge
    pygame.draw.line(surf, (22, 60, 40), (0, 133), (BAT_W, 133), 2)


def rob_fielder(rx):
    """Which of the fielders standing around the batting view is closest to the spot where the homer is robbed."""
    return min(range(len(BAT_FIELDERS)), key=lambda i: math.hypot(BAT_FIELDERS[i][0] - rx, (BAT_FIELDERS[i][1] - ROB_FEET_Y) * 0.6))


def robber_pos(rx, u):
    """He leaves his spot and runs to the wall while the ball is in the air: (silhouette index, x, feet y)."""
    i = rob_fielder(rx)
    fx, fy, fs = BAT_FIELDERS[i]
    k = smooth(clamp(u / 0.55, 0, 1))
    return i, lerp(fx, rx, k), lerp(fy + 18 * fs, ROB_FEET_Y, k)


def build_bat_background():
    """The batting view (behind the batter): sky, crowd, grass, dirt, lines. Drawn once."""
    surf = pygame.Surface((BAT_W, BAT_H))
    for y in range(130):
        t = y / 130
        pygame.draw.line(surf, (int(lerp(42, 111, t)), int(lerp(74, 179, t)), int(lerp(122, 200, t))), (0, y), (BAT_W, y))
    pygame.draw.rect(surf, (76, 81, 89), (0, 20, BAT_W, 95))
    # (the crowd is animated live - see build_bat_crowd() and draw_crowd())
    draw_bat_wall(surf)
    for i in range(8):
        pygame.draw.rect(surf, (63, 143, 46) if i % 2 else (71, 153, 47), (0, 134 + i * 32, BAT_W, 32))
    dirt = (198, 138, 82)
    pygame.draw.ellipse(surf, dirt, (385 - 400, 300 - 115, 800, 230))
    pygame.draw.polygon(surf, (74, 154, 53), [(385, 240), (580, 300), (385, 392), (190, 300)])
    pygame.draw.ellipse(surf, dirt, (385 - 48, 212 - 12, 96, 24))
    pygame.draw.rect(surf, WHITE, (380, 210, 10, 3))
    pygame.draw.line(surf, WHITE, (385, 392), (0, 214), 4)
    pygame.draw.line(surf, WHITE, (385, 392), (BAT_W, 214), 4)
    pygame.draw.polygon(surf, WHITE, [(372, 368), (408, 368), (408, 378), (390, 388), (372, 378)])
    return surf


# --- batting-view drawing -----------------------------------------------------

def draw_bat_scoreboard(surf, game):
    """The scoreboard. When a home run hits it (game.board_time >= 0) it rocks back and forth and flickers."""
    board = pygame.Surface((190, 92), pygame.SRCALPHA)
    t = game.board_time
    angle, lit = 0.0, True
    if t >= 0:
        angle = 9 * math.exp(-2.6 * t) * math.sin(t * 22)                # damped rocking, in degrees
        lit = not (t < 2.0 and int(t * 18) % 3 == 0)                     # lights flicker for the first two seconds
    pygame.draw.rect(board, (31, 35, 39) if lit else (14, 16, 18), (0, 0, 190, 92), border_radius=6)
    pygame.draw.rect(board, (102, 102, 102), (0, 0, 190, 92), 2, border_radius=6)
    if lit:
        for i in range(OUTS_PER_INNING):
            pygame.draw.circle(board, (232, 232, 232), (20 + i * 14, 16), 5, 0 if i < game.outs else 1)
        draw_text(board, f"INN {game.inning}/{game.innings}", 95, 21, 11, (232, 232, 232), outline=False)
        draw_text(board, f"B{game.balls} S{game.strikes}", 180, 21, 11, (232, 232, 232), outline=False, align="right")
        score_text = f"{game.runs} - {game.cpu_runs}"
        score_size = 38
        while score_size > 18 and get_font(score_size).size(score_text)[0] > 112:     # leave room for the logos
            score_size -= 2
        draw_text(board, score_text, 95, 70, score_size, (232, 232, 232), outline=False)
        draw_logo(board, game.home_logo, 5, 27, 28)
        draw_logo(board, game.cpu_logo, 157, 27, 28)
        name_size = 10                                                   # shrink long team names so the whole name fits
        while name_size > 6 and get_font(name_size).size(game.team_name)[0] > 118:
            name_size -= 1
        draw_text(board, game.team_name, 8, 86, name_size, (232, 232, 232), outline=False, align="left")
        draw_text(board, "CPU", 182, 86, 10, (232, 232, 232), outline=False, align="right")
    rotated = pygame.transform.rotate(board, angle)
    surf.blit(rotated, rotated.get_rect(center=(385, 68)))
    if 0 <= t < 0.7:                                                      # a burst of sparks on impact
        for i in range(10):
            a = i * 0.63
            r0, r1 = 30 + 120 * t, 45 + 190 * t
            pygame.draw.line(surf, (255, 225, 90), (385 + r0 * math.cos(a), 68 + r0 * math.sin(a) * 0.6),
                             (385 + r1 * math.cos(a), 68 + r1 * math.sin(a) * 0.6), 2)


SPRAY_MAX_PX, SPRAY_FENCE = 440.0, 0.85       # spray chart: how far the chart reaches (field pixels) and where the wall sits (fraction)


def spray_hr_xy(sideways, feet):
    """Field position for a home run on the spray chart: along its pull/oppo angle, past the wall (longer = farther out)."""
    a_l, a_r = math.atan2(U_LEFT[0], -U_LEFT[1]), math.atan2(U_RIGHT[0], -U_RIGHT[1])
    a = a_l + clamp((sideways + 300) / 600, 0.04, 0.96) * (a_r - a_l)
    d = SPRAY_MAX_PX * clamp(SPRAY_FENCE + 0.015 + (feet - 350) / 200 * 0.11, SPRAY_FENCE + 0.01, 0.99)
    return HOME[0] + math.sin(a) * d, HOME[1] - math.cos(a) * d


def pips(value):
    """1 to 5 pips for a trait value (0.8 = weak ... 1.25 = elite)."""
    return int(clamp(round((value - 0.78) / 0.11) + 1, 1, 5))


WET = [False]                    # True while it is raining: slides and dives throw MUD instead of dust
MUD = (92, 66, 44)


def draw_close_play(surf, bag, t, result, tres):
    """The close-play effect at a bag: a pulsing ring + banner, then the umpire's call (arms out = SAFE, fist up = OUT)."""
    bx, by = bag
    ux, uy = bx + (36 if bx > 640 else -36), by + 16
    ump = (28, 28, 34)
    if result is None and t < CLOSE_SLOW_TIME + 0.4:
        pygame.draw.circle(surf, GOLD, (bx, by), int(26 + 8 * math.sin(t * 14)), 3)
        draw_text(surf, "CLOSE PLAY!", bx, by - 74, 30, GOLD)
    draw_person(surf, ux, uy, 1.3, ump, ump, shadow=False)
    if result is None:
        return
    if tres < 0.7:                                           # dust kicked up at the bag
        for i in range(9):
            a = i * 0.7 + 0.3
            r = 8 + tres * 70
            pygame.draw.circle(surf, MUD if WET[0] else (205, 175, 125), (bx + math.cos(a) * r, by - 8 + math.sin(a) * r * 0.5), max(1, int(7 - tres * 9)))
    if tres < CLOSE_SHOW_TIME:
        if result == "safe":
            pygame.draw.line(surf, ump, (ux - 4, uy - 31), (ux - 30, uy - 29), 5)
            pygame.draw.line(surf, ump, (ux + 4, uy - 31), (ux + 30, uy - 29), 5)
            draw_text(surf, "SAFE!", bx, by - 74, 40, GREEN)
        else:
            pygame.draw.line(surf, ump, (ux + 4, uy - 31), (ux + 12, uy - 56), 5)
            pygame.draw.circle(surf, (226, 190, 150), (ux + 12, uy - 58), 4)
            draw_text(surf, "OUT!", bx, by - 74, 40, RED)


def draw_close_cutscene(surf, gap, dist, result, tres, t, skin, team_color, post=None):
    """The close-play CUTSCENE (zoomed in, like the slugger one): the runner dives for the bag while the fielder reaches for him with
    the ball coming in. gap = how far (in bases) the runner still has to go, dist = how far (pixels) the ball is from the bag.
    result = None until he arrives, then "safe" / "out"; tres = seconds since he arrived; t = seconds since the cutscene began."""
    W, H = surf.get_size()
    bagx, bagy = 640, 528
    # --- the picture: sky, a dark crowd, grass, then the dirt around the bag ---
    surf.fill((70, 120, 190), (0, 0, W, 150))
    surf.fill((46, 50, 66), (0, 90, W, 120))
    rnd = random.Random(7)
    for _ in range(420):
        surf.fill(rnd.choice(((200, 70, 70), (230, 200, 80), (90, 130, 220), (230, 230, 240), (120, 120, 140))),
                  (rnd.randrange(W), rnd.randrange(96, 206), 5, 5))
    surf.fill((52, 128, 58), (0, 206, W, 150))
    for i in range(6):
        surf.fill((60, 140, 66), (0, 206 + i * 50, W, 25))
    surf.fill((150, 106, 70) if WET[0] else (186, 132, 84), (0, 356, W, H - 356))
    pygame.draw.line(surf, WHITE, (0, 356), (W, 356), 3)
    pygame.draw.ellipse(surf, (170, 118, 72), (bagx - 360, bagy - 70, 720, 210))
    ump = (26, 26, 32)
    # --- the umpire, standing behind the play (he waits, then makes the call) ---
    ux, uy, us = 900, 470, 3.2
    draw_person(surf, ux, uy, us, ump, ump, shadow=False)
    call = result is not None and tres > 0.45
    if call:
        sh = uy - 24 * us
        if result == "safe":
            pygame.draw.line(surf, ump, (ux - 5, sh), (ux - 30 * us, sh + 6), 14)
            pygame.draw.line(surf, ump, (ux + 5, sh), (ux + 30 * us, sh + 6), 14)
        else:
            pygame.draw.line(surf, ump, (ux + 5, sh), (ux + 16 * us, sh - 22 * us), 14)
            pygame.draw.circle(surf, (226, 190, 150), (ux + 16 * us, sh - 22 * us - 6), 14)
    # --- the bag ---
    pygame.draw.polygon(surf, WHITE, [(bagx - 46, bagy), (bagx, bagy - 18), (bagx + 46, bagy), (bagx, bagy + 20)])
    pygame.draw.polygon(surf, (190, 190, 200), [(bagx - 46, bagy), (bagx, bagy + 20), (bagx + 46, bagy), (bagx + 46, bagy + 8), (bagx, bagy + 28), (bagx - 46, bagy + 8)])
    # --- the runner, sliding in head-first from the left ---
    rs = 4.2
    head_x = bagx - 36 - clamp(gap, 0, 0.6) * 620
    rx, ry = head_x - 14 * rs, bagy + 22
    pygame.draw.ellipse(surf, (150, 100, 62), (rx - 70, ry - 8, 190, 26))                # his shadow on the dirt
    if WET[0]:
        pygame.draw.ellipse(surf, (96, 70, 48), (bagx - 330, bagy + 6, 520, 46))         # a wet, muddy trough where he slides
        pygame.draw.ellipse(surf, (118, 86, 58), (bagx - 250, bagy + 12, 300, 26))
    draw_person(surf, rx, ry, rs, (240, 240, 240), team_color, sliding=True, skin=skin, shadow=False)
    if WET[0]:                                                                           # his white uniform is caked in mud
        pygame.draw.ellipse(surf, MUD, (rx - 12 * rs, ry - 7 * rs, 20 * rs, 6 * rs))
        pygame.draw.ellipse(surf, (110, 80, 54), (rx + 2 * rs, ry - 9 * rs, 9 * rs, 4 * rs))
    hand = (head_x + 14, ry - 20)                                                          # his outstretched hand
    pygame.draw.line(surf, skin, (head_x - 4, ry - 22), hand, 11)
    # --- the fielder with the glove ---
    fx, fy, fs = 760, 650, 4.6
    k = clamp(dist / CLOSE_BALL_RADIUS, 0.0, 1.4)
    tag = (bagx - 30, bagy - 6)
    if result == "out":
        glove = tag
    elif result == "safe":
        glove = (lerp(tag[0] + 18, tag[0] + 60, clamp(tres / 0.3, 0, 1)), tag[1] + 6)    # too late: it comes down on his hand/bag after
    else:
        glove = (lerp(tag[0] + 30, 740, clamp(k, 0, 1)), lerp(tag[1] - 20, 400, clamp(k, 0, 1)))
    draw_person(surf, fx, fy, fs, FIELD_BODY, FIELD_CAP, shadow=False, skin=SKIN_DEFAULT)
    shoulder = (fx - 8, fy - 24 * fs)
    pygame.draw.line(surf, FIELD_BODY, shoulder, glove, 16)
    pygame.draw.circle(surf, (120, 75, 40), glove, 22)
    # --- the ball: in his glove once it is there, otherwise still coming in from the upper right ---
    if k < 0.08 or (result == "out") or (result == "safe" and tres > 0.3):
        ball = (glove[0] + 2, glove[1] - 4)
    else:
        far = (1180, 120)
        ball = (lerp(glove[0], far[0], clamp(k, 0, 1.4)), lerp(glove[1], far[1], clamp(k, 0, 1.4)) - 34 * math.sin(math.pi * clamp(k, 0, 1)))
        pygame.draw.line(surf, (255, 255, 255, 120), ball, (ball[0] + (ball[0] - glove[0]) * 0.12, ball[1] + (ball[1] - glove[1]) * 0.12 + 6), 3)
    pygame.draw.circle(surf, WHITE, ball, 13)
    pygame.draw.circle(surf, (204, 51, 51), ball, 13, 2)
    # --- impact ---
    if result == "safe" and tres < 1.1:                                                   # a big cloud of dust at the bag
        for i in range(14):
            a = i * 0.9 + 0.2
            r = 20 + tres * 160 + (i % 3) * 14
            pygame.draw.circle(surf, MUD if WET[0] else (214, 186, 140), (bagx - 10 + math.cos(a) * r * 1.4, bagy + 20 + math.sin(a) * r * 0.45 - tres * 30), max(2, int(26 - tres * 18)))
    if result == "out" and tres < 0.5:                                                    # the tag: a flash
        for i in range(10):
            a = i * 0.63
            r0, r1 = 20 + tres * 40, 60 + tres * 120
            pygame.draw.line(surf, (255, 240, 170), (tag[0] + math.cos(a) * r0, tag[1] + math.sin(a) * r0),
                             (tag[0] + math.cos(a) * r1, tag[1] + math.sin(a) * r1), 5)
    if WET[0] and result is not None and tres < 1.1:                                      # mud splatters up off the slide (out or safe)
        for i in range(12):
            a = i * 1.1 + 0.4
            r = 30 + tres * 150 + (i % 4) * 18
            pygame.draw.circle(surf, MUD, (bagx - 40 + math.cos(a) * r * 1.2, bagy + 10 - abs(math.sin(a)) * r * 0.6), max(2, int(12 - tres * 9)))
    if post:
        post(surf)                                                                        # the weather over the whole scene
    # --- cinema: bars, labels, fade-in ---
    surf.fill((0, 0, 0), (0, 0, W, 64))
    surf.fill((0, 0, 0), (0, H - 64, W, 64))
    if result is None:
        draw_text(surf, "CLOSE PLAY!", 640, 38, 36, GOLD)
        draw_text(surf, "SLOW-MO", 1190, H - 28, 16, (200, 205, 225))
    if call:
        draw_text(surf, "SAFE!" if result == "safe" else "OUT!", 640, 200, 110, GREEN if result == "safe" else RED)
    if t < 0.3:
        fade = pygame.Surface((W, H))
        fade.set_alpha(int(255 * (1 - t / 0.3)))
        surf.blit(fade, (0, 0))


def draw_batter_card(surf, game):
    """A little scorecard for the batter at the plate: name, number, today's line and his three ratings."""
    b = game.lineup[game.batter_i]
    x, y, w, h = 6, 322, 200, 62
    panel = pygame.Surface((w, h), pygame.SRCALPHA)
    pygame.draw.rect(panel, (8, 12, 28, 200), (0, 0, w, h), border_radius=8)
    pygame.draw.rect(panel, (255, 255, 255, 80), (0, 0, w, h), 1, border_radius=8)
    surf.blit(panel, (x, y))
    if not b["ab"]:
        avg = "---"
    else:
        avg = "1.000" if b["h"] >= b["ab"] else f".{int(1000 * b['h'] / b['ab']):03d}"
    draw_text(surf, f"#{b['num']}  {b['name'].upper()}", x + 8, y + 16, 11, GOLD, align="left")
    bat = CURRENT_BAT
    pygame.draw.rect(surf, bat["body"], (x + w - 50, y + 8, 40, 5), border_radius=2)
    pygame.draw.rect(surf, bat["handle"] or bat["body"], (x + w - 50, y + 8, 12, 5), border_radius=2)
    draw_text(surf, f"{b['h']}-{b['ab']}   AVG {avg}   HR {b['hr']}", x + 8, y + 31, 10, WHITE, align="left")
    for i, (label, value) in enumerate((("PWR", b["power"] * bat["power"]), ("CON", b["contact"] * bat["window"]), ("SPD", b["speed"]))):
        px = x + 8 + i * 64
        draw_text(surf, label, px, y + 50, 9, (200, 205, 225), outline=False, align="left")
        for k in range(5):
            pygame.draw.rect(surf, GOLD if k < pips(value) else (70, 76, 98), (px + 24 + k * 7, y + 43, 5, 7))


def draw_fire_aura(surf, t):
    """Flames licking up around a batter who is ON FIRE."""
    glow = pygame.Surface((150, 170), pygame.SRCALPHA)
    pygame.draw.ellipse(glow, (255, 120, 30, 50 + int(20 * math.sin(t * 9))), (0, 20, 150, 150))
    surf.blit(glow, (240, 240))
    for i in range(14):
        a = i / 14 * math.tau
        base_x = 315 + math.cos(a) * 46
        base_y = 330 + math.sin(a) * 56
        h = 16 + 12 * abs(math.sin(t * 8 + i * 1.7))
        sway = math.sin(t * 6 + i) * 3
        pygame.draw.polygon(surf, (255, 110, 20), [(base_x - 6, base_y), (base_x + sway, base_y - h), (base_x + 6, base_y)])
        pygame.draw.polygon(surf, (255, 220, 80), [(base_x - 3, base_y), (base_x + sway * 0.6, base_y - h * 0.6), (base_x + 3, base_y)])


def draw_flipped_bat(surf, t):
    """The bat after a bat flip: it sails up and away, lands, hops once and lies there. t = seconds since he let go."""
    ox, oy, vx, vy0, g, ground = 298.0, 252.0, -95.0, -235.0, 560.0, 374.0
    t_land = (-vy0 + math.sqrt(vy0 * vy0 + 2 * g * (ground - oy))) / g
    spin = 15.0
    if t < t_land:
        x, y, ang = ox + vx * t, oy + vy0 * t + 0.5 * g * t * t, 1.0 + spin * t
    else:
        s = t - t_land
        hop = max(0.0, 70 * s * 4 * (1 - s * 4)) if s < 0.25 else 0.0              # one small hop
        x = ox + vx * t_land + vx * 0.22 * min(s, 0.6)
        y = ground - hop
        ang = 1.0 + spin * t_land + spin * 0.18 * (1 - math.exp(-5 * s)) * 1.0
    half = BAT_DRAW_LENGTH / 2
    dx, dy = math.cos(ang) * half, math.sin(ang) * half * (1 if t < t_land else 0.25)
    pygame.draw.ellipse(surf, (40, 80, 36), (x - 40, ground - 4, 80, 9))
    draw_real_bat(surf, (x - dx, y - dy), (x + dx, y + dy), 11)


def draw_wall_robber(surf, x, jump, skin, base_y=None):
    """An outfielder leaping at the wall (batting view) with his glove up over it. base_y = where his feet are when not jumping."""
    s = 0.95
    base_y = ROB_FEET_Y if base_y is None else base_y
    feet = base_y - jump
    pygame.draw.ellipse(surf, (35, 85, 35), (x - 12, base_y - 3, 24, 8))
    draw_person(surf, x, feet, s, FIELD_BODY, FIELD_CAP, skin=skin, shadow=False)
    glove = (x + 2, feet - 38 * s)
    pygame.draw.line(surf, FIELD_BODY, (x + 3, feet - 22 * s), glove, 4)
    pygame.draw.circle(surf, (120, 75, 40), glove, 6)
    return glove


def draw_base_indicator(surf, x, y, bases, armed):
    """A little diamond in the corner showing who is on base (gold = occupied)."""
    pts = [(x, y + 20), (x + 20, y), (x, y - 20), (x - 20, y)]           # home, first, second, third
    pygame.draw.polygon(surf, (30, 70, 40), pts)
    pygame.draw.polygon(surf, (230, 230, 230), pts, 2)
    for i, occupied in enumerate(bases):
        bx, by = pts[i + 1]
        pygame.draw.rect(surf, GOLD if occupied else (110, 115, 125), (bx - 5, by - 5, 10, 10))
        if occupied and armed:
            pygame.draw.rect(surf, GREEN, (bx - 8, by - 8, 16, 16), 2)


BALL_GOLD = [False]               # the derby's MONEY BALL is gold (set by the derby while it is being pitched)


def draw_bat_ball(surf, x, y, radius):
    pygame.draw.ellipse(surf, (50, 100, 40), (x - radius, max(y, 200) + radius + 2 - radius * 0.4, radius * 2, radius * 0.8))
    if BALL_GOLD[0]:
        glow = pygame.Surface((int(radius * 8), int(radius * 8)), pygame.SRCALPHA)
        c = int(radius * 4)
        pygame.draw.circle(glow, (255, 210, 70, 60), (c, c), int(radius * 3.6))
        pygame.draw.circle(glow, (255, 230, 120, 90), (c, c), int(radius * 2.2))
        surf.blit(glow, (x - c, y - c))
        for k in range(4):                                        # little sparkles
            a = k * 1.571 + pygame.time.get_ticks() / 260
            pygame.draw.line(surf, (255, 245, 170), (x + math.cos(a) * radius * 1.4, y + math.sin(a) * radius * 1.4),
                             (x + math.cos(a) * radius * 2.4, y + math.sin(a) * radius * 2.4), 1)
        pygame.draw.circle(surf, (255, 205, 60), (x, y), radius)
        pygame.draw.circle(surf, (150, 95, 0), (x, y), radius, 1)
        return
    pygame.draw.circle(surf, WHITE, (x, y), radius)
    pygame.draw.circle(surf, (204, 51, 51), (x, y), radius, 1)


def smooth(u):
    u = clamp(u, 0, 1)
    return u * u * (3 - 2 * u)


def draw_limb(surf, points, width, color, outline=None):
    """A bent arm or leg: thick line segments with round joints (optionally with a darker edge)."""
    if outline:
        draw_limb(surf, points, width + 4, outline)
    for a, b in zip(points, points[1:]):
        pygame.draw.line(surf, color, a, b, width)
    for pt in points:
        pygame.draw.circle(surf, color, pt, width // 2)


def two_bone(shoulder, hand, l1, l2, left):
    """Where the elbow goes so an arm with two bones of length l1 / l2 reaches from the shoulder to the hand (bent down and out)."""
    dx, dy = hand[0] - shoulder[0], hand[1] - shoulder[1]
    raw = math.hypot(dx, dy) or 1.0
    d = clamp(raw, 10, l1 + l2 - 1)
    ux, uy = dx / raw, dy / raw
    a = (l1 * l1 - l2 * l2 + d * d) / (2 * d)
    h = math.sqrt(max(0.0, l1 * l1 - a * a))
    candidates = [(shoulder[0] + ux * a - uy * h * k, shoulder[1] + uy * a + ux * h * k) for k in (1, -1)]
    return max(candidates, key=lambda e: e[1] * 0.7 + (-e[0] if left else e[0]) * 0.3)


def path(p, keys):
    """Like keyframes(), but for a point: keys is [(p, (x, y)), ...]."""
    return (keyframes(p, [(k, v[0]) for k, v in keys]), keyframes(p, [(k, v[1]) for k, v in keys]))


# The swing, in the order a real hitter does it (all positions are batting-view pixels, angles in degrees):
#   STANCE  hands up by the rear shoulder, bat cocked back over it
#   LOAD    hands drift back and UP behind his head, bat tucks behind the helmet, front foot lifts (the stride)
#   LAUNCH  front foot plants, HIPS fire first, hands drop DOWN and in to the slot while the barrel lags behind them
#   SWING   shoulders unwind, arms extend, the barrel whips around to meet the ball out in front
#   FINISH  the bat wraps all the way around his body and ends lying across his back, hands up by his front shoulder
SWING_HANDS = [(0.0, (306, 274)), (0.30, (310, 292)), (0.65, (332, 305)), (1.0, (352, 308))]      # up/back -> drop -> extend
SWING_YAW = [(0.0, -104), (0.30, -98), (0.62, -35), (0.85, 62), (1.0, 105)]                        # barrel lags, then whips
SWING_ELEV = [(0.0, 80), (0.30, 54), (0.62, 20), (1.0, -18)]                                       # bat drops to level
FINISH_YAW = [(0.0, 105), (0.45, 235), (1.0, 420)]                                                 # around the front, over the shoulder, across the back
FINISH_ELEV = [(0.0, -18), (0.4, 38), (1.0, -22)]


def batter_pose(t, clock, load=0.0, big=False):
    """The batter's pose at swing time t (-1 = not swinging yet).
    load (0..1) is how far he has LOADED (hands back and up, bat tucked behind his head).
    Returns (hands, yaw, elevation, lean). The bat is a 3-D stick: yaw is its direction around the batter
    (0 = toward the camera, 90 deg = across the plate, 180 = toward the pitcher), elevation is how far it is raised.
    big=True (a PERFECT PERFECT homer) is a bigger, higher finish."""
    b = 1.0 if big else 0.0
    if t < 0:
        k = smooth(load)
        w = math.sin(clock * 5) * (1 - k)                                  # the waggle stops once he has loaded
        w2 = math.sin(clock * 5 + 1) * (1 - k)
        hands = (lerp(330, 306, k) + 2 * w, lerp(282, 274, k) + 2 * w2)
        return (hands, math.radians(lerp(-48, -104, k) + 7 * w), math.radians(lerp(66, 80, k) + 3 * w2), -5 * k)
    if t < SWING_TIME:
        u = t / SWING_TIME
        return (path(u, SWING_HANDS), math.radians(keyframes(u, SWING_YAW)), math.radians(keyframes(u, SWING_ELEV)),
                lerp(-5, 8, smooth(u)))
    v = smooth((t - SWING_TIME) / (FOLLOW_TIME + 0.1 * b))                 # then HOLD: v stays at 1 for as long as you like
    hands = path(v, [(0.0, (352, 308)), (0.4, (336, 268)), (1.0, (293 - 3 * b, 252 - 16 * b))])      # up past his face to the front shoulder
    return (hands, math.radians(keyframes(v, FINISH_YAW)), math.radians(keyframes(v, FINISH_ELEV) + 14 * b * v), lerp(8, 12 + 4 * b, v))


def batter_body(t, load=0.0):
    """How the body is turned. Returns (turn, hip, stride, pivot, behind):
    turn   shoulders: 0 = side-on to the pitcher, 1 = chest square to the pitcher (back to the camera)
    hip    hips: they open BEFORE the shoulders (that is where a swing's power comes from)
    stride 0 = front foot back, 0.5 = lifted in the stride, 1 = planted
    pivot  how far the back foot has pivoted up onto its toes
    behind 0..1: how much his arms are on the far side of his body (hidden by his torso and head)"""
    if t < 0:
        k = smooth(load)
        return (lerp(0.12, 0.0, k), lerp(0.10, 0.0, k), 0.55 * k, 0.0, 0.0)
    if t < SWING_TIME:
        u = t / SWING_TIME
        hip = lerp(0.0, 0.9, smooth(u / 0.72))
        turn = lerp(0.0, 0.74, smooth((u - 0.12) / 0.88))
        return (turn, hip, lerp(0.55, 1.0, smooth(u / 0.35)), smooth(u), smooth((turn - 0.35) / 0.3))
    v = smooth((t - SWING_TIME) / FOLLOW_TIME)
    return (lerp(0.74, 1.0, v), lerp(0.9, 1.0, v), 1.0, lerp(1.0, 1.4, v), 1.0)


def bat_tip(hands, yaw, elev, length=BAT_DRAW_LENGTH):
    """Screen position of the bat's tip, and bz (> 0 = the bat is on the camera's side of the batter)."""
    bx, by, bz = math.cos(elev) * math.sin(yaw), math.sin(elev), math.cos(elev) * math.cos(yaw)
    return (hands[0] + length * bx, hands[1] - length * by + 0.3 * length * bz), bz


# --- bats: real wooden-bat shape, in the finishes real MLB players use ---------------------------
# body = the wood colour, handle = (two-tone bats only) the handle's colour, tape = grip tape, knob = the knob,
# cap = the end cap, label = the maker's band on the barrel, shine = the highlight stripe.
BAT_STYLES = [
    dict(name="Natural",    body=(222, 184, 130), handle=None,          tape=(34, 34, 38),    knob=(46, 36, 30),    cap=(150, 112, 70),  label=(120, 40, 36),   shine=(250, 230, 190)),
    dict(name="Blonde",     body=(240, 216, 166), handle=None,          tape=(30, 30, 34),    knob=(60, 50, 40),    cap=(176, 144, 96),  label=(30, 30, 34),    shine=(255, 246, 216)),
    dict(name="Black",      body=(32, 32, 36),    handle=None,          tape=(205, 205, 212), knob=(205, 205, 212), cap=(70, 70, 78),    label=(214, 176, 70),  shine=(110, 110, 124)),
    dict(name="Cherry",     body=(104, 50, 30),   handle=None,          tape=(30, 30, 34),    knob=(30, 30, 34),    cap=(64, 30, 18),    label=(220, 190, 120), shine=(170, 100, 70)),
    dict(name="Red",        body=(168, 36, 36),   handle=None,          tape=(30, 30, 34),    knob=(30, 30, 34),    cap=(110, 20, 22),   label=(240, 240, 240), shine=(230, 110, 100)),
    dict(name="Two-Tone",   body=(32, 32, 36),    handle=(222, 184, 130), tape=(34, 34, 38),  knob=(34, 34, 38),    cap=(70, 70, 78),    label=(214, 176, 70),  shine=(110, 110, 124)),
    dict(name="Driftwood",  body=(150, 140, 128), handle=None,          tape=(34, 34, 38),    knob=(60, 56, 52),    cap=(104, 96, 88),   label=(40, 40, 44),    shine=(200, 192, 180)),
    dict(name="Navy",       body=(28, 44, 96),    handle=None,          tape=(235, 235, 240), knob=(235, 235, 240), cap=(18, 28, 66),    label=(214, 176, 70),  shine=(100, 124, 190)),
]
for _style in BAT_STYLES:
    _style["power"], _style["window"] = BAT_TRAITS[_style["name"]]
CURRENT_BAT = BAT_STYLES[0]      # the bat the current batter is using (a new batter picks a new one)


def set_current_bat(index):
    global CURRENT_BAT
    CURRENT_BAT = BAT_STYLES[index % len(BAT_STYLES)]


def pick_bat_style():
    """A new batter steps in with a randomly chosen bat."""
    global CURRENT_BAT
    CURRENT_BAT = random.choice(BAT_STYLES)


def _smooth(u):
    u = clamp(u, 0.0, 1.0)
    return u * u * (3 - 2 * u)


def bat_half_width(t):
    """Half-width of a bat (0..1 of its barrel radius) at position t along it: t=0 knob end, t=1 end cap.
    A flared knob, a thin handle, a long smooth taper into the barrel, and a rounded end cap."""
    if t < 0.04:
        return 0.62 * math.sqrt(clamp(t / 0.012, 0, 1))
    if t < 0.075:
        return lerp(0.62, 0.30, _smooth((t - 0.04) / 0.035))
    if t < 0.34:
        return 0.30
    if t < 0.74:
        return lerp(0.30, 1.0, _smooth((t - 0.34) / 0.40))
    if t < 0.965:
        return 1.0
    return math.sqrt(max(0.0, 1 - ((t - 0.965) / 0.035) ** 2))


def draw_real_bat(surf, a, b, width, style=None, t0=0.0, t1=1.0, jag0=False, jag1=False):
    """Draw a baseball bat whose knob is at a and whose end cap is at b. `width` = the barrel's thickness in pixels.
    t0..t1 draws only part of the bat (used for the broken pieces); jag0 / jag1 give that cut end a splintered edge."""
    style = style or CURRENT_BAT
    dx, dy = b[0] - a[0], b[1] - a[1]
    length = math.hypot(dx, dy)
    if length < 2:
        return
    ux, uy = dx / length, dy / length
    nx, ny = -uy, ux
    half = width / 2

    def band(ta, tb, jag_a=False, jag_b=False):
        ta, tb = max(ta, t0), min(tb, t1)
        if tb - ta < 0.004:
            return None
        n = max(3, int((tb - ta) / 0.012))
        ts = [lerp(ta, tb, i / n) for i in range(n + 1)]
        left = [(a[0] + ux * length * t + nx * half * bat_half_width(t), a[1] + uy * length * t + ny * half * bat_half_width(t)) for t in ts]
        right = [(a[0] + ux * length * t - nx * half * bat_half_width(t), a[1] + uy * length * t - ny * half * bat_half_width(t)) for t in ts]
        pts = left + right[::-1]
        if jag_a or jag_b:                                           # a splintered, zig-zag break
            def zigzag(p, q, sign):
                return [(lerp(p[0], q[0], k / 6) + ux * sign * length * 0.03 * (k % 2), lerp(p[1], q[1], k / 6) + uy * sign * length * 0.03 * (k % 2))
                        for k in range(7)]
            if jag_a:
                pts = zigzag(right[0], left[0], 1) + left[1:] + right[::-1][:-1]
            if jag_b:
                pts = left[:-1] + zigzag(left[-1], right[-1], -1) + right[::-1][1:]
        return pts

    handle_col = style["handle"] or style["body"]
    tape = style["tape"]
    dark = tuple(int(c * 0.55) for c in style["body"])
    cut_a = 0.02 if jag0 else 0.0                                    # keep trim inside the broken edge
    cut_b = 0.02 if jag1 else 0.0
    if style["handle"]:                                              # two-tone: handle colour up to the middle of the taper, barrel colour after
        parts = ((0.0, 0.50, handle_col, jag0, False), (0.50, 1.0, style["body"], False, jag1))
    else:
        parts = ((0.0, 1.0, style["body"], jag0, jag1),)
    for ta, tb, color, ja, jb in parts:
        pts = band(ta, tb, ja and ta <= t0 + 1e-6, jb and tb >= t1 - 1e-6)
        if pts:
            pygame.draw.polygon(surf, color, pts)
            if width >= 7:
                pygame.draw.polygon(surf, dark, pts, 1)
    for ta, tb, color in ((0.0, 0.04, style["knob"]), (0.085, 0.31, tape), (0.52, 0.575, style["label"]), (0.925, 0.965, style["cap"])):
        pts = band(max(ta, t0 + cut_a), min(tb, t1 - cut_b))
        if pts:
            pygame.draw.polygon(surf, color, pts)
    if width >= 8:                                                   # the shine along one side of the barrel
        lo, hi = max(0.42, t0 + cut_a), min(0.93, t1 - cut_b)
        if hi - lo > 0.03:
            p1 = (a[0] + ux * length * lo + nx * half * 0.45 * bat_half_width(lo), a[1] + uy * length * lo + ny * half * 0.45 * bat_half_width(lo))
            p2 = (a[0] + ux * length * hi + nx * half * 0.45 * bat_half_width(hi), a[1] + uy * length * hi + ny * half * 0.45 * bat_half_width(hi))
            pygame.draw.line(surf, style["shine"], p1, p2, max(1, int(width * 0.13)))


def draw_bat_stick(surf, hands, tip, bz):
    scale = 1 + 0.12 * bz
    draw_real_bat(surf, hands, tip, 11 * scale)                                              # a real bat shape


def draw_batter(surf, swing_clock, cap, skin=SKIN_DEFAULT, clock=0.0, load=0.0, settle=1.0, big=False, bat=True):
    """The batter seen from behind. His hips open first, then his shoulders; his arms and the bat go BEHIND his body
    (hidden by his torso and head) during the load and again at the end of the follow-through, and swing out in front of
    him through the hitting zone, with the barrel trailing his hands until the last moment."""
    hands, yaw, elev, lean = batter_pose(swing_clock, clock, load, big)
    turn, hip, stride, pivot, behind = batter_body(swing_clock, load)
    if swing_clock < 0 and settle < 1.0:                                  # the next pitch: ease from the held finish back to the stance
        h0, y0, e0, l0 = batter_pose(1e9, clock, 0.0, big)
        k = smooth(settle)
        if yaw < y0 - math.pi:
            yaw += 2 * math.pi
        hands = (lerp(h0[0], hands[0], k), lerp(h0[1], hands[1], k))
        yaw, elev, lean = lerp(y0, yaw, k), lerp(e0, elev, k), lerp(l0, lean, k)
        b0 = batter_body(1e9, 0.0)
        turn, hip, stride, pivot, behind = (lerp(b0[i], v, k) for i, v in enumerate((turn, hip, stride, pivot, behind)))
    tip, bz = bat_tip(hands, yaw, elev)
    pants, edge, jersey = (236, 236, 240), (150, 152, 165), (246, 246, 246)
    cx = 315 + lean                                                       # centre of his body
    sw, hw = lerp(15, 46, turn), lerp(22, 34, hip)                        # shoulder / hip width: they spread as he opens up
    sh_f, sh_r = (cx - sw / 2, 274), (cx + sw / 2, 274)                   # front (far) shoulder, rear (near) shoulder

    if 0 < swing_clock < SWING_TIME + FOLLOW_TIME * 0.5:                  # a white swoosh behind the bat
        trail = []
        for k in range(8):
            tk = swing_clock - k * 0.012
            if tk < 0:
                break
            h, yw, el, _ = batter_pose(tk, clock, 1.0, big)
            tp, _ = bat_tip(h, yw, el)
            trail.append(((lerp(h[0], tp[0], 0.5), lerp(h[1], tp[1], 0.5)), tp))
        if len(trail) > 1:
            overlay = pygame.Surface(surf.get_size(), pygame.SRCALPHA)
            for k in range(len(trail) - 1):
                (m0, t0), (m1, t1) = trail[k], trail[k + 1]
                pygame.draw.polygon(overlay, (255, 255, 255, max(0, 95 - k * 12)), [m0, t0, t1, m1])
            surf.blit(overlay, (0, 0))

    def draw_arm(shoulder, left):
        elbow = two_bone(shoulder, hands, 32, 32, left)
        draw_limb(surf, [shoulder, elbow], 11, jersey, edge)                                   # sleeve
        draw_limb(surf, [elbow, hands], 9, skin)                                               # forearm

    def draw_hands():
        pygame.draw.circle(surf, cap, hands, 6)                                                # batting gloves
        pygame.draw.circle(surf, BLACK, hands, 6, 1)

    arms_behind = behind > 0.5                                            # arms on the far side of his body: drawn BEFORE the torso
    if bz < 0 and bat:
        draw_bat_stick(surf, hands, tip, bz)                              # the bat is on the far side: behind the body
    if arms_behind:
        draw_arm(sh_f, True)
        draw_arm(sh_r, False)
        draw_hands()
    else:
        draw_arm(sh_f, True)                                              # the front arm is always the far one: behind his chest
    # legs: the back foot pivots up onto its toes, the front foot strides forward (lifting) and plants
    lift = 7 * max(0.0, math.sin(math.pi * clamp(stride, 0, 1)))
    rear = [(cx - hw * 0.5, 334), (lerp(290, 304, hip), 362), (lerp(290, 299, pivot / 1.4 if pivot > 1 else pivot), 386 - 5 * min(pivot, 1.4))]
    front = [(cx + hw * 0.5, 334), (lerp(346, 340, hip), 362 - lift * 0.4), (lerp(340, 348, smooth(stride)), 386 - lift)]
    for leg in (rear, front):
        draw_limb(surf, leg, 17, pants, edge)
        pygame.draw.ellipse(surf, (40, 40, 46), (leg[-1][0] - 10, leg[-1][1] - 3, 22, 9))      # shoes
    torso = [(sh_f[0] - 5, 270), (sh_r[0] + 5, 270), (cx + hw / 2, 342), (cx - hw / 2, 342)]
    pygame.draw.polygon(surf, jersey, torso)
    pygame.draw.polygon(surf, edge, torso, 2)
    for shoulder in (sh_f, sh_r):
        pygame.draw.circle(surf, jersey, shoulder, 11)
    pygame.draw.line(surf, cap, (cx - hw / 2 + 2, 339), (cx + hw / 2 - 2, 339), 5)             # belt in the team colour
    pygame.draw.rect(surf, skin, (cx - 6, 257, 12, 13))                                        # neck
    pygame.draw.circle(surf, skin, (cx, 247), 19)                                              # head
    pygame.draw.circle(surf, cap, (cx, 243), 21, draw_top_left=True, draw_top_right=True)      # helmet
    flap_x = cx - 27 if turn > 0.5 else cx + 19                                                # ear flap on the pitcher side
    pygame.draw.rect(surf, cap, (flap_x, 243, 8, 14), border_radius=3)
    if not arms_behind:
        draw_arm(sh_r, False)                                             # the rear arm is the near one: in front of his chest
    if bz >= 0 and bat:
        draw_bat_stick(surf, hands, tip, bz)                              # the bat is on the camera's side: over his shoulder / arm
    if not arms_behind:
        draw_hands()


def keyframes(p, keys):
    """Piecewise value over time: keys is [(p, value), ...] in order. Eases a little inside each segment."""
    if p <= keys[0][0]:
        return keys[0][1]
    for (p0, v0), (p1, v1) in zip(keys, keys[1:]):
        if p <= p1:
            u = (p - p0) / (p1 - p0)
            return lerp(v0, v1, lerp(u, smooth(u), 0.35))
    return keys[-1][1]


# the throwing arm (angles in radians inside the arm's swing plane, measured from "straight ahead", growing clockwise):
#   1.6 = hanging down   3.1 = pointing straight back   4.7 = straight up   5.5 = forward and up (release)   7.0 = forward and down
# "lag" is how far the forearm trails behind the upper arm (it snaps to 0 as the arm whips through)
PITCH_ARM_ANGLE = [(0.0, 1.6), (0.30, 2.7), (0.55, 3.5), (0.78, 4.5), (1.0, 5.5), (1.3, 7.0)]
PITCH_ARM_LAG = [(0.0, 1.3), (0.30, 0.3), (0.55, 0.5), (0.78, 1.3), (1.0, 0.0), (1.3, -0.1)]
# how far each half of his body has turned, in degrees: 0 = facing third base (side-on to the plate), 90 = facing home
PITCH_HIP_TURN = [(0.0, 0), (0.45, 0), (0.8, 35), (1.0, 75), (1.3, 90)]
PITCH_SHOULDER_TURN = [(0.0, 0), (0.5, 0), (0.78, 20), (1.0, 90), (1.3, 100)]
# He is drawn in 3-D and projected: x is across the screen (toward first base), z is toward the camera (toward home plate), y is up.


def _add(a, *terms):
    """a + sum(k * v for k, v in terms)  (3-D points)"""
    return (a[0] + sum(k * v[0] for k, v in terms), a[1] + sum(k * v[1] for k, v in terms), a[2] + sum(k * v[2] for k, v in terms))


def _toward_3b(turn):
    """Horizontal 'forward' direction of a body turned by `turn` radians: 0 = toward third base, pi/2 = toward home plate."""
    return (-math.cos(turn), 0.0, math.sin(turn))


def _right_of(turn):
    """His right-hand side for that turn (a right-hander: far side from the camera when he faces third base)."""
    return (-math.sin(turn), 0.0, -math.cos(turn))


def leg_knee(hip, foot, l1, l2, toward):
    """3-D knee position for a leg of two bones spanning hip -> foot; the knee bends toward the direction `toward`."""
    v = (foot[0] - hip[0], foot[1] - hip[1], foot[2] - hip[2])
    full = max(0.001, math.sqrt(v[0] ** 2 + v[1] ** 2 + v[2] ** 2))
    dist = clamp(full, 0.001, l1 + l2 - 0.01)
    u = (v[0] / full, v[1] / full, v[2] / full)
    dot = toward[0] * u[0] + toward[1] * u[1] + toward[2] * u[2]
    perp = (toward[0] - dot * u[0], toward[1] - dot * u[1], toward[2] - dot * u[2])
    n = max(0.001, math.sqrt(perp[0] ** 2 + perp[1] ** 2 + perp[2] ** 2))
    h = math.sqrt(max(0.0, l1 * l1 - (dist / 2) ** 2))
    return (hip[0] + u[0] * dist / 2 + perp[0] / n * h, hip[1] + u[1] * dist / 2 + perp[1] / n * h,
            hip[2] + u[2] * dist / 2 + perp[2] / n * h)


def pitcher_pose(progress):
    """All the joints of the pitcher (3-D), plus where each lands on the screen.
    progress: 0 = standing, hands together, facing third base ... 0.4 = knee at its highest, arm swinging back ...
              0.8 = front foot planted, arm cocked, hips opening ... 1 = release (facing home) ... 1.3 = follow-through."""
    p = clamp(progress, 0, 1.3)
    cx = 386.0
    kick = smooth(p / 0.4)
    stride = smooth((p - 0.4) / 0.4)
    fin = smooth((p - 0.45) / 0.55)                                       # how far he has uncoiled toward the plate
    follow = clamp((p - 1.0) / 0.3, 0, 1)
    hip_turn = math.radians(keyframes(p, PITCH_HIP_TURN))
    sh_turn = math.radians(keyframes(p, PITCH_SHOULDER_TURN))
    Fl, Rl, Fu, Ru = _toward_3b(hip_turn), _right_of(hip_turn), _toward_3b(sh_turn), _right_of(sh_turn)
    up, down = (0.0, 1.0, 0.0), (0.0, -1.0, 0.0)
    tilt = lerp(lerp(0.0, -0.18, kick), 0.42, fin) + 0.12 * follow         # rocks back on the kick, then drives toward the plate
    hip_c = (cx - 2 * stride, 18 - 5 * stride, 6 * stride + 3 * follow)
    hip_r, hip_l = _add(hip_c, (2.5, Rl)), _add(hip_c, (-2.5, Rl))
    lean = (math.sin(tilt), math.cos(tilt))
    sh_c = _add(hip_c, (26 * lean[0], Fu), (26 * lean[1], up))
    sh_r, sh_l = _add(sh_c, (5.5, Ru)), _add(sh_c, (-5.5, Ru))
    head = _add(sh_c, (9 * lean[0] + 1.5, Fu), (9 * lean[1], up))
    # lead leg (his left): the knee comes up toward third base, then the leg reaches out toward HOME and plants
    thigh = lerp(0.15, 2.15, kick) if p < 0.4 else lerp(2.15, 0.8, stride)
    shin = lerp(0.0, -0.45, kick) if p < 0.4 else lerp(-0.45, 0.7, stride)
    reach_dir = _toward_3b(math.radians(85) * stride)
    knee_l = _add(hip_l, (9 * math.sin(thigh), reach_dir), (9 * math.cos(thigh), down))
    foot_l = _add(knee_l, (9 * math.sin(shin), reach_dir), (9 * math.cos(shin), down))
    # back leg (his right): stays on the rubber, and the heel comes up as he finishes
    foot_r = (cx - 1 - 3 * follow, 7 * follow, -2.5)
    knee_r = leg_knee(hip_r, foot_r, 9, 9, Fl)
    # throwing arm (his right): swings back behind him, rises, cocks, then whips around toward the plate
    a_u = keyframes(p, PITCH_ARM_ANGLE)
    a_f = a_u - keyframes(p, PITCH_ARM_LAG)
    elbow = _add(sh_r, (9 * math.cos(a_u), Fu), (-9 * math.sin(a_u), up))
    hand = _add(elbow, (9 * math.cos(a_f), Fu), (-9 * math.sin(a_f), up))
    # glove arm (his left): at the chest, reaches out for balance, then tucks in
    reach = kick - 0.6 * smooth((p - 0.6) / 0.3)
    glove = _add(sh_l, (6 + 6 * reach, Fu), (-(9 - 6 * reach), up))
    glove_elbow = ((sh_l[0] + glove[0]) / 2, (sh_l[1] + glove[1]) / 2 - 3, (sh_l[2] + glove[2]) / 2)
    pose = dict(hip_c=hip_c, hip_r=hip_r, hip_l=hip_l, sh_c=sh_c, sh_r=sh_r, sh_l=sh_l, head=head, knee_l=knee_l, foot_l=foot_l,
                knee_r=knee_r, foot_r=foot_r, elbow=elbow, hand=hand, glove=glove, glove_elbow=glove_elbow,
                face=Fu, toe_l=reach_dir, toe_r=Fl)
    pose["screen_hand"] = project_pitcher(hand)
    return pose


def project_pitcher(pt):
    """3-D point -> screen position. Things nearer the camera (toward home) sit lower and a touch bigger."""
    x, y, z = pt
    s = 1 + 0.004 * z
    return (386.0 + (x - 386.0) * s, 209.0 - y * s + 0.35 * z)


def draw_bat_pitcher(surf, windup_progress, skin=SKIN_DEFAULT):
    """Draws the pitcher and returns where his throwing hand is.
    He starts side-on to the plate facing third base, kicks his knee toward third, strides toward home and turns to face the
    plate as the arm comes through. windup_progress: 0 = standing ... 1 = release ... 1.3 = follow-through."""
    pose = pitcher_pose(windup_progress)
    body, shoe = FIELD_BODY, (230, 230, 235)
    P = project_pitcher
    pygame.draw.ellipse(surf, (150, 105, 66), (386 - 20, 205, 40, 8))                              # a darker patch of mound under him
    parts = []                                                                                     # (depth, draw function): far things first

    def limb(depth, points, widths, hand_color=None, ball=None):
        def draw():
            pts = [P(q) for q in points]
            for a, b, w in zip(pts, pts[1:], widths):
                pygame.draw.line(surf, body, a, b, w)
            for q in pts[1:-1]:
                pygame.draw.circle(surf, body, q, 3)
            if hand_color:
                pygame.draw.circle(surf, hand_color, pts[-1], ball)
        parts.append((depth, draw))

    def foot(depth, ankle, toe_dir):
        def draw():
            a = P(ankle)
            b = P(_add(ankle, (5, toe_dir)))
            pygame.draw.line(surf, shoe, a, b, 3)
        parts.append((depth, draw))

    for hip, knee, ank, toe in (("hip_r", "knee_r", "foot_r", "toe_r"), ("hip_l", "knee_l", "foot_l", "toe_l")):
        pts = (pose[hip], pose[knee], pose[ank])
        depth = sum(q[2] for q in pts) / 3
        limb(depth, pts, (6, 5))
        foot(depth + 0.1, pose[ank], pose[toe])
    # torso
    def draw_torso():
        a, b = P(pose["hip_c"]), P(pose["sh_c"])
        pygame.draw.line(surf, body, a, b, 12)
        pygame.draw.circle(surf, body, a, 6)
        pygame.draw.circle(surf, body, b, 6)
    parts.append(((pose["hip_c"][2] + pose["sh_c"][2]) / 2, draw_torso))
    # head and cap (the brim points where he is facing)
    def draw_head():
        h = P(pose["head"])
        brim = P(_add(pose["head"], (9, pose["face"])))
        front = pose["face"][2] > 0.5                                    # facing the camera: show the whole face, brim toward us
        pygame.draw.circle(surf, skin, h, 6)
        pygame.draw.circle(surf, FIELD_CAP, (h[0], h[1] - 1.5), 6.5, draw_top_left=True, draw_top_right=True)
        if front:                                                        # facing us: the brim is a bar across his forehead
            pygame.draw.line(surf, FIELD_CAP, (h[0] - 6, h[1] - 1), (h[0] + 6, h[1] - 1), 2)
        else:                                                            # side-on: the brim sticks out the way he is facing
            pygame.draw.line(surf, FIELD_CAP, (h[0] + (brim[0] - h[0]) * 0.35, h[1] - 1), (brim[0], brim[1] - 2), 2)
    parts.append((pose["head"][2] + 0.5, draw_head))
    # arms
    ra = (pose["sh_r"], pose["elbow"], pose["hand"])
    la = (pose["sh_l"], pose["glove_elbow"], pose["glove"])
    limb(sum(q[2] for q in ra) / 3 + 0.2, ra, (5, 4), skin, 2.5)
    limb(sum(q[2] for q in la) / 3 + 0.2, la, (4, 4), (120, 75, 40), 4)
    for _, draw in sorted(parts, key=lambda item: item[0]):
        draw()
    return pose["screen_hand"]


def pitch_position(pitch, u):
    """Batting-view position + radius of the pitch. u = 0 at release, 1 at the plate."""
    u = min(u, 1.25)
    if pitch.name == "Changeup" and u < 1:
        u = 1 - (1 - u) ** CHANGEUP_HOT_START             # hot out of the hand, then it slows way down
    x = BAT_RELEASE_POINT[0] + u * 8 + pitch.zone * 16 * min(u, 1)       # inside = toward the batter (left)
    y = 212 + 120 * u ** 1.7
    if pitch.name == "Curveball":
        bend = math.sin(math.pi * min(u, 1))
        y -= 40 * bend
        x -= 40 * bend * (1 - u * 0.3)
    if pitch.name == "Splitter":
        y += 55 * max(0, (u - 0.65) / 0.35) ** 2
    if pitch.name == "Slider":
        x += 38 * min(max(0, (u - 0.35) / 0.65), 1.3) ** 1.6
        y += 22 * max(0, (u - 0.6) / 0.4) ** 2
    return x, y, 2 + 7 * u


def hr_k(distance):
    """0 = a short homer (350 ft), 1 = a long one (450 ft+) in the batting view."""
    return clamp((distance - 350) / 100, 0, 1) if distance else 0.5


def hr_end_y(distance):
    """Where a home run lands in the batting view: short ones barely clear the wall, long ones go up into the top deck."""
    return lerp(105, 22, hr_k(distance))


def hr_position(hit):
    """Batting-view position + radius of a home run ball. Longer homers fly higher, with a bigger arc and a smaller ball at the end."""
    u = min(1, hit.time / hit.flight)
    k = hr_k(hit.distance)
    end_y, peak, end_r = hr_end_y(hit.distance), lerp(20, 80, k), lerp(6.5, 2, k)
    if hit.robbed:
        end_y, peak, end_r = ROB_END_Y, 30, 6.5            # it only gets as high as the robber's glove
    return hit.start_x + hit.sideways * u, hit.start_y - (hit.start_y - end_y) * u - peak * math.sin(math.pi * u), 9 - (9 - end_r) * u


def draw_bat_fielders(surf, skip=None):
    """Fielders standing around the batting view. Just for looks - the real ones are in the field view. (skip = one who has gone to rob a homer)"""
    for n, (x, y, s) in enumerate(BAT_FIELDERS):
        if n == skip:
            continue
        pygame.draw.ellipse(surf, (40, 66, 58), (x - 8 * s, y - 18 * s, 16 * s, 36 * s))
        pygame.draw.circle(surf, (40, 66, 58), (x, y - 22 * s), 6 * s)


def make_seam_curve(points=90, k=0.4):
    """3-D points of a baseball seam, lying on a sphere of radius 1."""
    curve = []
    for i in range(points + 1):
        t = 2 * math.pi * i / points
        curve.append(((1 - k) * math.cos(t) + k * math.cos(3 * t),
                      (1 - k) * math.sin(t) - k * math.sin(3 * t),
                      2 * math.sqrt(k * (1 - k)) * math.sin(2 * t)))
    return curve


SEAM_POINTS = make_seam_curve()


def draw_seam_window(surf, game):
    """A magnified ball whose red seams give away the pitch:
         seams rolling UP fast ..... fastball (backspin)
         seams rolling UP slower ... changeup (Hard)
         seams rolling DOWN ........ curveball (topspin)
         tilted / sideways ......... slider (Hard)
         barely spinning ........... splitter"""
    pitch = game.pitch
    if not SHOW_SEAM_WINDOW or not pitch:
        return
    if game.state == "PITCH":
        t = SEAM_PREVIEW_TIME + pitch.time
    elif game.state == "WIND_UP" and game.state_time > WIND_UP_TIME - SEAM_PREVIEW_TIME:
        t = game.state_time - (WIND_UP_TIME - SEAM_PREVIEW_TIME)
    else:
        return
    rate, tilt = SEAM_SPIN[pitch.name]
    cx, cy, radius = 700, 64, 38
    pygame.draw.circle(surf, (20, 24, 30), (cx, cy), radius + 7)
    pygame.draw.circle(surf, (245, 242, 232), (cx, cy), radius)
    spin, cos_t, sin_t = rate * t + 0.6, math.cos(tilt), math.sin(tilt)
    last = None
    for x, y, z in SEAM_POINTS:
        y2 = y * math.cos(spin) - z * math.sin(spin)         # spin the ball about its horizontal axis
        z2 = y * math.sin(spin) + z * math.cos(spin)
        x3, y3 = x * cos_t - y2 * sin_t, x * sin_t + y2 * cos_t     # tilt the spin axis
        if z2 > 0:                                           # only the half facing you is visible
            point = (cx + x3 * radius, cy - y3 * radius)
            if last:
                pygame.draw.line(surf, (200, 40, 40), last, point, 3)
            last = point
        else:
            last = None
    pygame.draw.circle(surf, (120, 120, 120), (cx, cy), radius, 2)
    if SHOW_SEAM_LEGEND:
        for i, name in enumerate(game.diff["pitches"]):
            draw_text(surf, SEAM_LEGEND_TEXT[name], cx, 126 + i * 11, 9, (235, 235, 235), outline=False)


# --- the PERFECT PERFECT home run cutscene (side view) --------------------------
# Everything here is drawn in "world" pixels; the camera offset is subtracted when drawing.

BATTER_FEET = (420, 600)         # world position of the side-view batter's feet (the ground is y=600)
BAT_LENGTH = 190
TORSO_LEN = 74


def track(frames, t):
    """Smoothly interpolate keyframes [(time, value), ...] with a Catmull-Rom spline: it passes through every key but
    never comes to a stop between them, so the motion flows. Values can be numbers or tuples."""
    if t <= frames[0][0]:
        return frames[0][1]
    if t >= frames[-1][0]:
        return frames[-1][1]
    i = 0
    while not frames[i][0] <= t <= frames[i + 1][0]:
        i += 1
    (t0, v0), (t1, v1) = frames[i], frames[i + 1]
    vm = frames[i - 1][1] if i > 0 else v0
    vp = frames[i + 2][1] if i + 2 < len(frames) else v1
    u = (t - t0) / (t1 - t0)

    def spline(a, b, c, d):
        return 0.5 * (2 * b + (-a + c) * u + (2 * a - 5 * b + 4 * c - d) * u * u + (-a + 3 * b - 3 * c + d) * u ** 3)
    if isinstance(v0, tuple):
        return tuple(spline(vm[k], v0[k], v1[k], vp[k]) for k in range(len(v0)))
    return spline(vm, v0, v1, vp)


# The side-view swing, as keyframes (seconds; the bat meets the ball at 0.8):
#   0.0 stance -> 0.3 LOAD (weight back, hands back and up) -> 0.5 cock -> 0.45-0.6 front foot STRIDES forward
#   -> 0.65 barrel drops -> 0.76 WHIP (hips and shoulders open up) -> 0.8 CONTACT -> follow-through wraps the bat
#   around behind him -> 1.25 he HOLDS the finish.
SLUGGER_HIP_X = [(0, 0), (0.3, -14), (0.5, -10), (0.65, 2), (0.8, 16), (1.0, 24), (1.25, 26)]          # hips slide back, then drive forward
SLUGGER_HIP_H = [(0, 96), (0.3, 88), (0.5, 90), (0.65, 92), (0.8, 90), (1.0, 96), (1.25, 100)]          # hip height: sinks into the load, rises through the finish
SLUGGER_LEAN = [(0, 0.12), (0.3, -0.08), (0.5, -0.12), (0.65, 0.02), (0.8, 0.30), (1.0, 0.0), (1.15, -0.28), (1.25, -0.36)]   # torso: coils back, drives forward, arches back
SLUGGER_HANDS = [(0, (16, 16)), (0.3, (-12, -6)), (0.5, (-16, 2)), (0.65, (-4, 18)), (0.7, (8, 24)), (0.76, (36, 26)),
                 (0.8, (56, 22)), (0.86, (50, 10)), (0.95, (34, -14)), (1.05, (14, -34)), (1.15, (-4, -44)), (1.25, (-14, -48))]   # hands relative to the shoulders
SLUGGER_YAW = [(0, 15), (0.3, -5), (0.5, 5), (0.65, 30), (0.72, 75), (0.76, 125), (0.8, 180), (0.86, 225), (0.95, 265),
               (1.05, 305), (1.15, 335), (1.25, 355)]       # bat direction around the batter: 0 = back, 90 = toward the camera, 180 = at the pitcher
SLUGGER_ELEV = [(0, 62), (0.3, 72), (0.5, 58), (0.65, 25), (0.72, 8), (0.76, 0), (0.8, -8), (0.86, -2), (0.95, 12),
                (1.05, 30), (1.15, 48), (1.25, 56)]         # how far the bat is raised (degrees)
SLUGGER_REAR_FOOT = [(0, (-34, 0)), (0.7, (-34, 0)), (0.8, (-32, -1)), (1.0, (-22, -7)), (1.25, (-18, -9))]    # back heel lifts and pivots
SLUGGER_FRONT_FOOT = [(0, (40, 0)), (0.3, (40, 0)), (0.45, (46, -24)), (0.6, (70, -6)), (0.66, (70, 0)), (1.25, (70, 0))]   # the stride


def slugger_pose(t):
    """Every joint of the side-view batter at cutscene time t, in world pixels.
    Before contact the keyframes are stretched to fit SLUGGER_HIT_TIME; after contact they run in real seconds."""
    tt = t * 0.8 / SLUGGER_HIT_TIME if t < SLUGGER_HIT_TIME else 0.8 + (t - SLUGGER_HIT_TIME)
    ox, oy = BATTER_FEET
    hip = (ox + track(SLUGGER_HIP_X, tt), oy - track(SLUGGER_HIP_H, tt))
    lean = track(SLUGGER_LEAN, tt)
    shoulder = (hip[0] + TORSO_LEN * math.sin(lean), hip[1] - TORSO_LEN * math.cos(lean))
    head = (shoulder[0] + 6 + 16 * lean, shoulder[1] - 30)
    offset = track(SLUGGER_HANDS, tt)
    hands = (shoulder[0] + offset[0], shoulder[1] + offset[1])
    yaw, elev = math.radians(track(SLUGGER_YAW, tt)), math.radians(track(SLUGGER_ELEV, tt))
    bx, by, bz = -math.cos(yaw) * math.cos(elev), math.sin(elev), math.sin(yaw) * math.cos(elev)
    tip = (hands[0] + BAT_LENGTH * bx, hands[1] - BAT_LENGTH * by + 0.25 * BAT_LENGTH * bz)
    rear, front = track(SLUGGER_REAR_FOOT, tt), track(SLUGGER_FRONT_FOOT, tt)
    return dict(hip=hip, shoulder=shoulder, head=head, hands=hands, tip=tip, bz=bz, lean=lean,
                rear_foot=(ox + rear[0], oy + min(0, rear[1])), front_foot=(ox + front[0], oy + min(0, front[1])))


CONTACT_POINT = slugger_pose(SLUGGER_HIT_TIME)["tip"]        # where the barrel is at the moment of contact: the ball arrives here


def build_slugger_assets():
    """Pre-draw the scrolling backdrop pieces (sky, skyline, stands, grass) so the cutscene is cheap to draw."""
    w = LOGICAL_W
    sky = pygame.Surface((w, LOGICAL_H))
    for y in range(LOGICAL_H):
        k = clamp(y / 560, 0, 1) ** 1.4
        pygame.draw.line(sky, (int(lerp(25, 255, k)), int(lerp(35, 165, k)), int(lerp(105, 110, k))), (0, y), (w, y))
    pygame.draw.circle(sky, (255, 225, 160), (980, 430), 80)
    skyline = pygame.Surface((w, 220), pygame.SRCALPHA)
    x = 0
    while x < w:
        bw, bh = random.randint(40, 110), random.randint(50, 200)
        pygame.draw.rect(skyline, (70, 55, 100), (x, 220 - bh, bw, bh))
        x += bw + random.randint(0, 12)
    stands = pygame.Surface((w, 260))
    stands.fill((70, 62, 78))
    for _ in range(1800):
        stands.fill(random.choice([(170, 120, 110), (210, 200, 190), (130, 135, 160), (190, 80, 80)]),
                    (random.randint(0, w), random.randint(30, 250), 5, 5))
    pygame.draw.rect(stands, (40, 38, 50), (0, 0, w, 28))
    grass = pygame.Surface((w, 240))
    grass.fill((50, 125, 48))
    for sx in range(0, w, 160):
        pygame.draw.rect(grass, (58, 140, 55), (sx, 0, 80, 240))
    return dict(sky=sky, skyline=skyline, stands=stands, grass=grass)


def slugger_ball_world(t, k=0.5):
    """World position of the ball: the slow-motion pitch, then the rocket after contact."""
    s = t - SLUGGER_HIT_TIME
    if s < 0:
        u = t / SLUGGER_HIT_TIME
        return lerp(1300, CONTACT_POINT[0], u), lerp(CONTACT_POINT[1] - 40, CONTACT_POINT[1], u * u)
    # k = 0 for a 400 ft shot, 1 for 550 ft: longer ones fly faster and higher
    return CONTACT_POINT[0] + lerp(850, 1500, k) * s, CONTACT_POINT[1] - (lerp(430, 720, k) * s - 150 * s * s)


def ik_joint(a, b, l1, l2, toward):
    """The knee / elbow position for a limb with bones l1 and l2 reaching from a to b, bent toward the direction `toward`."""
    dx, dy = b[0] - a[0], b[1] - a[1]
    raw = math.hypot(dx, dy) or 1.0
    d = clamp(raw, 6, l1 + l2 - 1)
    ux, uy = dx / raw, dy / raw
    along = (l1 * l1 - l2 * l2 + d * d) / (2 * d)
    h = math.sqrt(max(0.0, l1 * l1 - along * along))
    candidates = [(a[0] + ux * along - uy * h * k, a[1] + uy * along + ux * h * k) for k in (1, -1)]
    return max(candidates, key=lambda e: (e[0] - a[0]) * toward[0] + (e[1] - a[1]) * toward[1])


def draw_taper_bat(surf, hands, tip, bz):
    """A big bat in the cutscene. bz > 0 means it is on the camera's side of the batter (so it looks a bit bigger)."""
    draw_real_bat(surf, hands, tip, 19 * (1 + 0.15 * bz))


def draw_side_batter(surf, cam, t, cap, skin=SKIN_DEFAULT):
    """The slugger in the side-view cutscene, posed from slugger_pose(t): knees and elbows bent, weight shifting back
    in the load, a stride, a whip of the hips and shoulders, and a held follow-through."""
    p = slugger_pose(t)
    to_screen = lambda pt: (pt[0] - cam[0], pt[1] - cam[1])
    hip, shoulder, head, hands, tip = (to_screen(p[k]) for k in ("hip", "shoulder", "head", "hands", "tip"))
    rear_foot, front_foot = to_screen(p["rear_foot"]), to_screen(p["front_foot"])
    bz, lean = p["bz"], p["lean"]
    uniform, shade, edge = (240, 240, 240), (212, 212, 224), (170, 172, 185)

    if SLUGGER_HIT_TIME * 0.65 < t < SLUGGER_HIT_TIME + 0.4:                       # swoosh behind the bat
        trail = []
        for k in range(12):
            q = slugger_pose(t - k * 0.01)
            h, tp = to_screen(q["hands"]), to_screen(q["tip"])
            trail.append(((lerp(h[0], tp[0], 0.45), lerp(h[1], tp[1], 0.45)), tp))
        overlay = pygame.Surface(surf.get_size(), pygame.SRCALPHA)
        for k in range(len(trail) - 1):
            (m0, t0), (m1, t1) = trail[k], trail[k + 1]
            pygame.draw.polygon(overlay, (255, 255, 255, max(0, 150 - k * 13)), [m0, t0, t1, m1])
        surf.blit(overlay, (0, 0))

    if bz < 0:
        draw_taper_bat(surf, hands, tip, bz)                                      # bat on the far side: behind his body
    rear_hip, front_hip = (hip[0] - 8, hip[1]), (hip[0] + 8, hip[1])
    for hip_pt, foot, color in ((rear_hip, rear_foot, shade), (front_hip, front_foot, uniform)):
        knee = ik_joint(hip_pt, foot, 58, 58, (1, 0))                              # knees bend toward the pitcher
        draw_limb(surf, [hip_pt, knee, foot], 26, color, edge)
        pygame.draw.ellipse(surf, (40, 40, 46), (foot[0] - 14, foot[1] - 8, 44, 15))   # shoe
    draw_limb(surf, [hip, shoulder], 52, (248, 248, 248), edge)                    # torso
    nx, ny = math.cos(lean), math.sin(lean)
    pygame.draw.line(surf, cap, (hip[0] - nx * 24, hip[1] - ny * 24), (hip[0] + nx * 24, hip[1] + ny * 24), 6)    # belt
    draw_limb(surf, [shoulder, head], 14, skin)                                    # neck
    pygame.draw.circle(surf, skin, head, 25)
    pygame.draw.circle(surf, cap, (head[0], head[1] - 5), 27, draw_top_left=True, draw_top_right=True)         # helmet
    pygame.draw.rect(surf, cap, (head[0], head[1] - 8, 40, 9))                     # brim
    if bz >= 0:
        draw_taper_bat(surf, hands, tip, bz)                                       # bat on the camera's side: in front
    for dx, color, grip in ((-8, shade, (-4, 4)), (6, uniform, (0, 0))):           # far arm, then near arm
        shoulder_pt = (shoulder[0] + dx, shoulder[1] + 2)
        hand_pt = (hands[0] + grip[0], hands[1] + grip[1])
        elbow = ik_joint(shoulder_pt, hand_pt, 38, 38, (0.3, 1))                   # elbows hang down and out
        draw_limb(surf, [shoulder_pt, elbow], 15, color, edge)
        draw_limb(surf, [elbow, hand_pt], 12, skin)
    pygame.draw.circle(surf, cap, hands, 9)                                        # batting gloves
    pygame.draw.circle(surf, BLACK, hands, 9, 1)


def draw_explosion(surf, cx, cy, s):
    """Starburst + shockwave at the moment of contact. s = seconds since contact."""
    if not 0 <= s < 0.5:
        return
    fade = 1 - s / 0.5
    outer = 60 + 420 * s ** 0.6
    points = []
    for i in range(24):
        r = outer if i % 2 == 0 else outer * 0.45
        a = i * math.pi / 12 + 0.2
        points.append((cx + r * math.cos(a), cy + r * math.sin(a)))
    pygame.draw.polygon(surf, (255, 120, 30), points)
    pygame.draw.polygon(surf, (255, 235, 90), [(cx + (x - cx) * 0.62, cy + (y - cy) * 0.62) for x, y in points])
    pygame.draw.circle(surf, WHITE, (cx, cy), int(40 * fade) + 4)
    pygame.draw.circle(surf, WHITE, (cx, cy), int(60 + 620 * s), max(1, int(10 * fade)))


# --- rare animations (these only draw; the Game decides when they happen) --------

FIELD_BODY, FIELD_CAP = (40, 60, 120), (30, 40, 90)     # the CPU fielders' colours (same as draw_person's defaults)


def draw_loose_ball(surf, x, y):
    pygame.draw.circle(surf, WHITE, (x, y), 6)
    pygame.draw.circle(surf, (204, 51, 51), (x, y), 6, 1)


def dive_glove(x, y, scale, direction):
    """Where the glove is once a diving fielder is stretched out on the ground."""
    return x + 32 * direction * scale, y - 13 * scale


def draw_dive(surf, x, y, scale, body, cap, t, direction=1, skin=SKIN_DEFAULT, shadow_color=(35, 85, 35), dust_color=(214, 176, 126)):
    """A fielder flying through the air and sliding on his belly. t = seconds since the dive began."""
    s, d = scale, direction
    p = clamp(t / DIVE_TIME, 0, 1)
    lift = math.sin(math.pi * p) * 18 * s                          # up off the ground, then back down
    cy = y - 8 * s - lift
    pygame.draw.ellipse(surf, shadow_color, (x - 16 * s, y - 3 * s, 32 * s, 8 * s))                       # shadow
    pygame.draw.line(surf, body, (x - 12 * d * s, cy), (x - 30 * d * s, cy + 3 * s), max(1, int(6 * s)))  # legs
    pygame.draw.ellipse(surf, body, (x - 16 * s, cy - 6 * s, 32 * s, 12 * s))                             # torso
    pygame.draw.line(surf, body, (x + 10 * d * s, cy - 2 * s), (x + 30 * d * s, cy - 5 * s), max(1, int(4 * s)))   # arm
    pygame.draw.circle(surf, skin, (x + 19 * d * s, cy - 3 * s), 5 * s)                        # head
    pygame.draw.circle(surf, cap, (x + 19 * d * s, cy - 5 * s), 5.5 * s, draw_top_left=True, draw_top_right=True)
    pygame.draw.circle(surf, (120, 75, 40), (x + 32 * d * s, cy - 5 * s), 5 * s)                          # glove
    if WET[0]:
        dust_color = MUD                                           # rain: he skids through mud
        pygame.draw.ellipse(surf, MUD, (x - 14 * s, cy - 2 * s, 20 * s, 6 * s))
    age = t - DIVE_TIME * 0.5                                      # a cloud of dust kicks up as he lands
    if age > 0:
        for i in range(10 if WET[0] else 7):
            a = i / 6
            r = (3 + 7 * a) * s * max(0.0, 1 - age / 0.9)
            if r >= 1:
                pygame.draw.circle(surf, dust_color, (x - d * s * age * (30 + 60 * a), y - 2 * s - age * 40 * a * s), r)


def leap_lift(t):
    return LEAP_HEIGHT * math.sin(math.pi * clamp(t / LEAP_TIME, 0, 1))


def leap_glove(x, y, scale, t):
    """Where the glove is during a leaping catch (t = seconds since the jump began)."""
    return x + 3 * scale, y - leap_lift(t) - 47 * scale


def draw_leap(surf, x, y, scale, body, cap, t, skin=SKIN_DEFAULT, shadow_color=(35, 85, 35)):
    """A fielder jumping with his glove stretched high. The shadow stays on the ground."""
    s = scale
    lift = leap_lift(t)
    shrink = 1 - 0.25 * lift / LEAP_HEIGHT
    pygame.draw.ellipse(surf, shadow_color, (x - 11 * s * shrink, y - 3 * s, 22 * s * shrink, 8 * s * shrink))
    draw_person(surf, x, y - lift, s, body, cap, shadow=False, skin=skin)
    gx, gy = leap_glove(x, y, s, t)
    pygame.draw.line(surf, body, (x + 3 * s, y - lift - 22 * s), (gx, gy + 5 * s), max(1, int(4 * s)))   # raised arm
    pygame.draw.circle(surf, (120, 75, 40), (gx, gy), 5 * s)


def draw_bat_stub(surf, x, y):
    """The handle of a snapped bat, still in the batter's hands (a jagged break at the top)."""
    start = (x + 5, y - 17)
    ux, uy = unit(10, -19)
    draw_real_bat(surf, start, (start[0] + ux * 50, start[1] + uy * 50), 8, t1=0.45, jag1=True)


def draw_broken_bat(surf, x, y, t, direction):
    """The barrel of the bat spinning away plus a spray of splinters. t = seconds since contact."""
    if not 0 <= t < BROKEN_BAT_TIME:
        return
    ux, uy = direction
    cy = y - 30
    if t < 0.25:                                                   # impact ring
        pygame.draw.circle(surf, WHITE, (x, cy), int(10 + 70 * t / 0.25), 3)
    k = clamp(t / BROKEN_BAT_TIME, 0, 1)
    dist = 240 * (1 - (1 - k) ** 2)
    ground_x, ground_y = x + ux * dist, y + uy * dist * 0.8
    bx, by = ground_x, cy + uy * dist * 0.8 - 50 * math.sin(math.pi * k)
    angle = t * 15
    dx, dy = math.cos(angle) * 34, math.sin(angle) * 34
    pygame.draw.ellipse(surf, (35, 85, 35), (ground_x - 20, ground_y - 5, 40, 10))
    full, mid_t = 113, 0.72                                           # the barrel is the outer part of a 113 px bat, spinning
    ux2, uy2 = math.cos(angle), math.sin(angle)
    start = (bx - ux2 * full * mid_t, by - uy2 * full * mid_t)
    draw_real_bat(surf, start, (start[0] + ux2 * full, start[1] + uy2 * full), 11, t0=0.45, jag0=True)
    if t < 1.0:
        for i in range(10):                                        # wood splinters
            a = i * 0.63 + 0.3
            speed = 80 + 18 * (i % 4)
            px = x + math.cos(a) * speed * t
            py = cy + math.sin(a) * speed * t * 0.7 + 160 * t * t
            la = a + t * 9
            pygame.draw.line(surf, tuple(min(255, c + 40) for c in CURRENT_BAT['handle'] or CURRENT_BAT['body']), (px, py), (px + 9 * math.cos(la), py + 9 * math.sin(la)), 3)


def draw_fan(surf, gx, gy, p, clock, has_ball=False, k=FAN_SCALE):
    """A fan in the stands - one of the little square fans of the crowd, but this one leaps up with a tiny glove to catch a home run.
       (gx, gy) is where his glove ends up. p = 0..1 how far he has leapt; clock = running time (he bobs happily once he has the ball)."""
    side = 4 + (1 if p > 0.6 else 0)                                                # crowd-sized square; a touch bigger as he jumps up
    rise = (1 - p) * 7                                                # he jumps up out of his seat as p goes 0 -> 1
    bob = math.sin(clock * 14) * 1.5 if has_ball else 0.0
    gloves_y = gy + rise
    body_x, body_y = gx - side / 2 + 2, gloves_y + side * 0.9 + bob
    jersey = (205, 60, 60)
    pygame.draw.rect(surf, (52, 56, 66), (body_x - 1, body_y + side, side + 2, 1))                # his seat
    pygame.draw.rect(surf, jersey, (body_x, body_y, side, side))
    pygame.draw.rect(surf, (40, 60, 120), (body_x, body_y, side, max(2, side // 3)))                  # his cap
    pygame.draw.line(surf, jersey, (body_x + side - 1, body_y + 1), (gx, gloves_y + 2), 1)   # the arm reaching up
    pygame.draw.line(surf, jersey, (body_x, body_y + 2), (body_x - 3, body_y - 2 - (3 if has_ball else 0)), 1)    # the other arm
    g = 3
    pygame.draw.rect(surf, (120, 75, 40), (gx - g / 2, gloves_y - g / 2, g, g), border_radius=1)     # the glove
    pygame.draw.rect(surf, (80, 46, 22), (gx - g / 2, gloves_y - g / 2, g, g), 1, border_radius=1)
    if has_ball:
        pygame.draw.rect(surf, WHITE, (gx - 1, gloves_y - 2, 3, 3))                                   # ...with the ball in it


# --- start-screen drawing ------------------------------------------------------

def build_title(text, max_width=1100, size=130):
    """Pre-render the fancy title: arched, slanted letters with a gradient fill, white outline and a deep 3-D shadow.
    Returns the finished picture plus a silhouette mask (used for the moving shine)."""
    while True:
        font = get_title_font(size)
        spacing = size * 0.04
        widths = [font.size(ch)[0] for ch in text]
        total = sum(widths) + spacing * (len(text) - 1)
        if total <= max_width or size <= 40:
            break
        size -= 6
    pad = 30
    w, h = int(total) + pad * 2, int(font.get_height() + size * 0.2) + pad * 2
    mask = pygame.Surface((w, h), pygame.SRCALPHA)                       # white letters, no colour
    x, mid = pad, pad + total / 2
    for ch, cw in zip(text, widths):
        cx = x + cw / 2
        u = clamp((cx - mid) / (total / 2), -1, 1)                       # -1 at the far left letter, +1 at the far right
        if ch != " ":
            glyph = pygame.transform.rotate(font.render(ch, True, WHITE), -u * 5)      # letters lean along an arch
            cy = pad + font.get_height() / 2 + size * 0.12 * u * u
            mask.blit(glyph, glyph.get_rect(center=(cx, cy)))
        x += cw + spacing
    top, bottom = pad, pad + font.get_height()
    gradient = pygame.Surface((w, h), pygame.SRCALPHA)                   # yellow at the top, orange at the bottom
    for y in range(h):
        t = clamp((y - top) / (bottom - top), 0, 1)
        pygame.draw.line(gradient, (255, int(lerp(248, 110, t)), int(lerp(120, 20, t)), 255), (0, y), (w, y))
    gradient.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)     # keep the gradient only inside the letters
    navy = mask.copy()
    navy.fill((18, 28, 90, 255), special_flags=pygame.BLEND_RGBA_MIN)
    out = pygame.Surface((w, h), pygame.SRCALPHA)
    for d in range(16, 0, -1):                                           # deep extrusion down and to the right
        out.blit(navy, (d, d))
    for k in range(16):                                                  # white sticker outline
        a = k * math.pi / 8
        out.blit(mask, (int(round(5 * math.cos(a))), int(round(5 * math.sin(a)))))
    out.blit(gradient, (0, 0))
    return dict(image=out, mask=mask, f_w=widths[0])


def draw_title(surf, title, cx, cy, t):
    """Blit the title and sweep a bright diagonal 'flash' across the letters every few seconds."""
    image = title["image"]
    rect = image.get_rect(center=(cx, cy))
    surf.blit(image, rect)
    w, h = image.get_size()
    period = 3.4
    progress = (t % period) / period * 1.7 - 0.35
    if not -0.2 < progress < 1.2:
        return
    x0 = progress * (w + h) - h
    shine = pygame.Surface((w, h), pygame.SRCALPHA)
    pygame.draw.polygon(shine, (255, 255, 255, 215), [(x0, 0), (x0 + 70, 0), (x0 + 70 - h * 0.5, h), (x0 - h * 0.5, h)])
    shine.blit(title["mask"], (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
    surf.blit(shine, rect)


BOLT = [(0.05, -0.5), (0.32, -0.5), (0.12, -0.12), (0.3, -0.12), (-0.2, 0.5), (-0.05, 0.0), (-0.25, 0.0)]


NIGHT_LIGHTS = [(0.07, 0.09), (0.21, 0.05), (0.79, 0.05), (0.93, 0.09)]     # stadium light banks (fractions of the screen)


def build_night_overlay(w, h):
    """Everything for the NIGHT GAME look, drawn once per screen size: dark edges, a warm pool of light on the field,
    soft beams from the light banks, and the glare of the lights themselves."""
    cx, cy = w * 0.5, h * 0.64
    dark = pygame.Surface((w, h), pygame.SRCALPHA)                       # blue-black, thickest at the edges
    steps = 40
    for i in range(steps + 1):
        t = i / steps                                                    # 0 = outside ... 1 = middle of the pool
        ew, eh = w * lerp(1.9, 0.5, t), h * lerp(1.7, 0.45, t)
        pygame.draw.ellipse(dark, (4, 8, 30, int(lerp(170, 30, t ** 0.8))), (cx - ew / 2, cy - eh / 2, ew, eh))
    glow = pygame.Surface((w, h))                                        # added on top: the field is lit warm white
    for i in range(31):
        t = i / 30
        ew, eh = w * lerp(1.15, 0.3, t), h * lerp(0.95, 0.25, t)
        c = int(lerp(0, 1, t ** 1.4) * 40)
        pygame.draw.ellipse(glow, (c, int(c * 0.9), int(c * 0.5)), (cx - ew / 2, cy - eh / 2, ew, eh))
    beams = pygame.Surface((w, h), pygame.SRCALPHA)                      # faint shafts of light falling from the towers
    lights = [(w * fx, h * fy) for fx, fy in NIGHT_LIGHTS]
    for lx, ly in lights:
        side = 1 if lx < cx else -1
        pygame.draw.polygon(beams, (255, 245, 205, 13), [(lx - 8, ly), (lx + 8, ly), (cx + side * w * 0.05 + w * 0.3, cy + h * 0.3),
                                                         (cx + side * w * 0.05 - w * 0.3, cy + h * 0.3)])
    radius = int(min(w, h) * 0.13)
    flares = []
    for level in (0.75, 0.88, 1.0):                                      # three brightnesses so the lights can shimmer
        f = pygame.Surface((radius * 2, radius * 2))
        for r in range(radius, 0, -2):
            k = (1 - r / radius) ** 2.2 * level
            pygame.draw.circle(f, (int(255 * k), int(248 * k), int(205 * k)), (radius, radius), r)
        pygame.draw.line(f, (int(150 * level),) * 3, (radius * 0.3, radius), (radius * 1.7, radius), 2)      # a little lens-star
        pygame.draw.line(f, (int(150 * level),) * 3, (radius, radius * 0.3), (radius, radius * 1.7), 2)
        pygame.draw.circle(f, (255, 255, 240), (radius, radius), max(2, radius // 8))
        flares.append(f)
    return dict(dark=dark, glow=glow, beams=beams, lights=lights, flares=flares, radius=radius)


def draw_bolt(surf, cx, cy, height, flip, t):
    """A flickering lightning bolt."""
    sign = -1 if flip else 1
    points = [(cx + sign * x * height, cy + y * height) for x, y in BOLT]
    glow = 0.5 + 0.5 * math.sin(t * 8 + (3 if flip else 0))
    pygame.draw.polygon(surf, (255, int(lerp(190, 240, glow)), int(lerp(40, 110, glow))), points)
    pygame.draw.polygon(surf, WHITE, points, 4)


def build_menu_background():
    """Night game: sky, stadium light beams, packed stands, striped grass, light towers."""
    surf = pygame.Surface((LOGICAL_W, LOGICAL_H))
    for y in range(LOGICAL_H):
        t = y / LOGICAL_H
        pygame.draw.line(surf, (int(lerp(10, 58, t)), int(lerp(14, 38, t)), int(lerp(46, 105, t))), (0, y), (LOGICAL_W, y))
    beams = pygame.Surface((LOGICAL_W, LOGICAL_H), pygame.SRCALPHA)
    for lx in (110, 1170):
        pygame.draw.polygon(beams, (255, 250, 205, 26), [(lx, 80), (lx - 330, 720), (lx + 330, 720)])
    surf.blit(beams, (0, 0))
    pygame.draw.rect(surf, (30, 28, 50), (0, 170, LOGICAL_W, 150))                       # stands
    for _ in range(2600):
        surf.fill(random.choice([(120, 90, 85), (150, 145, 140), (95, 100, 125), (135, 60, 60), (60, 60, 80)]),
                  (random.randint(0, LOGICAL_W), random.randint(174, 316), 4, 4))
    pygame.draw.rect(surf, (20, 70, 50), (0, 318, LOGICAL_W, 24))                        # outfield wall
    pygame.draw.rect(surf, GOLD, (0, 318, LOGICAL_W, 4))
    fill_polygon_stripes(surf, [(0, 342), (LOGICAL_W, 342), (LOGICAL_W, LOGICAL_H), (0, LOGICAL_H)], (28, 84, 44), (34, 96, 50))
    for lx in (110, 1170):                                                               # light towers
        pygame.draw.rect(surf, (55, 55, 70), (lx - 6, 120, 12, 210))
        pygame.draw.rect(surf, (40, 40, 52), (lx - 48, 62, 96, 66), border_radius=6)
        for row in range(3):
            for col in range(4):
                pygame.draw.circle(surf, (255, 252, 225), (lx - 33 + col * 22, 78 + row * 20), 7)
    return surf


# =============================================================================
# 4. THE GAME  -  all the rules live here
# =============================================================================

class Game:
    def __init__(self):
        self.bat_background = build_bat_background()
        self.field_background = build_field_background()
        self.field_crowd = build_field_crowd()
        self.bat_crowd = build_bat_crowd()
        self.slugger = build_slugger_assets()
        self.bat_surface = pygame.Surface((BAT_W, BAT_H))
        self.preview_scene = pygame.Surface((LOGICAL_W, LOGICAL_H))      # used by the Animations gallery
        self.preview_bat = pygame.Surface((BAT_W, BAT_H))
        self.mouse = (-1, -1)
        self.configure(DEFAULT_TEAM_NAME, TEAM_COLORS[0][1], DEFAULT_DIFFICULTY, DEFAULT_INNINGS)

    def configure(self, team_name, team_color, difficulty, innings, logo=None, bat_choice=None, weather_choice=None):
        """Apply the start-screen choices and begin a fresh game. bat_choice: 0 = every hitter has his own bat, 1+ = the whole team uses that bat."""
        self.team_name, self.team_color, self.innings = team_name, team_color, innings
        if bat_choice is not None or not hasattr(self, "bat_choice"):
            self.bat_choice = bat_choice or 0
        if weather_choice is not None or not hasattr(self, "weather_choice"):
            self.weather_choice = weather_choice or "Random"             # kept when you restart from the pause menu
        self.home_logo = logo if logo is not None else build_default_logo(team_name, team_color)
        self.cpu_logo = build_cpu_logo()
        self.set_difficulty(difficulty)
        self.reset()

    def set_difficulty(self, difficulty):
        """Switch difficulty (also used mid-game from the pause menu)."""
        self.difficulty = difficulty
        self.diff = DIFFICULTIES[difficulty]
        scale = self.diff["window"]                       # every timing window grows / shrinks together
        self.win_pp = PERFECT_PERFECT_WINDOW * scale
        self.win_perfect = PERFECT_WINDOW * scale
        self.win_good = GOOD_WINDOW * scale
        self.win_contact = CONTACT_WINDOW * scale
        self.win_foul = FOUL_WINDOW * scale

    def reset(self):
        self.inning, self.outs = 1, 0
        self.balls = self.strikes = 0
        self.runs = self.cpu_runs = 0
        self.crowd_energy = self.cpu_cheer = 0.0     # how fired up your crowd / the CPU's dugout is (decays over time)
        self.cpu_roll = random.random()      # 0-1: how much of its allowed maximum the CPU will score this game
        self.my_line, self.cpu_line, self.inning_start_runs = [], [], 0      # line score
        self.stats = dict(hits=0, hr=0, k=0, bb=0, perfect=0, steals=0, steal_att=0, errors=0, dp=0, sf=0, robbed=0, long_hr=0, best_streak=0)
        self.pitch_count, self.weak_vs = 0, {}               # the pitcher tires; he also attacks the pitches you keep missing
        self.streak, self.fire_flash = 0, 0.0                # good swings in a row (ON FIRE at ON_FIRE_STREAK)
        self.spray = []                                      # where every ball in play went: (x, y, kind) for the game-over spray chart
        self.spray_bg = None
        self.lineup = [dict(name=n, num=num, power=p, contact=c, speed=sp, skin=random.choice(SKIN_TONES),
                            bat=(random.randrange(len(BAT_STYLES)) if self.bat_choice == 0 else self.bat_choice - 1), ab=0, h=0, hr=0)
                       for n, num, p, c, sp in LINEUP]
        self.batter_i = 0
        roll, acc, self.weather = random.uniform(0, sum(w for _, w in WEATHER_WEIGHTS)), 0, None
        for name, weight in WEATHER_WEIGHTS:
            acc += weight
            if roll <= acc:
                self.weather = name
                break
        if self.weather_choice in ("Clear", "Night", "Rain", "Windy"):   # chosen on the start screen (anything else = the random roll)
            self.weather = self.weather_choice
        mph = random.randint(8, 18) if self.weather == "Windy" else random.randint(0, 5)
        way = random.choice(("OUT", "IN", "CROSS")) if self.weather == "Windy" else "CALM"
        self.wind = dict(mph=mph, way=way, cross=random.choice((-1, 1)))
        self.weather_label = {"Clear": "SUNNY DAY", "Night": "NIGHT GAME", "Rain": "RAIN",
                              "Windy": f"WIND {mph} MPH {way}"}[self.weather]
        self.rain = [(random.random(), random.random(), random.uniform(500, 800)) for _ in range(150)]
        self._overlays = {}
        self.bases = [0, 0, 0]               # [first, second, third]: 1 if a runner is on it
        self.pitch = self.hit = self.fp = None
        self.set_batter(0)                                       # the leadoff hitter (his own skin tone and bat)
        self.new_batter = False                                  # True after an at-bat ends: the next batter gets a new skin tone
        self.settle, self.finish_big = 1.0, False                # easing back from the held follow-through (1 = done)
        self.fielder_skins = {name: random.choice(SKIN_TONES) for name in FIELDER_POSTS}
        self.pitch_history = []              # the last few pitch names (the pitching brain avoids being predictable)
        self.steal_armed = False             # S pressed before the pitch
        self.swing_clock = -1
        self.confetti = []
        self.celebrating = self.wait_click = False
        self.quit_to_menu = False            # set when the player clicks away from the GAME OVER screen
        self.clock = 0.0                     # running time, used for waving fans etc.
        self.fan = None                      # (x, y) of the fan catching a home run, or None
        self.board_hit, self.board_time = False, -1.0     # a home run hit the scoreboard / seconds since it did
        self.hr_distance = 0                 # feet, for the home run message
        self.shake = self.shake_mag = 0.0    # screen shake on solid contact
        self.paused, self.pause_screen, self.pause_index = False, "main", 0
        self.anim_index, self.anim_clock = 0, 0.0
        self.view, self.fade = "bat", 0.0
        self.set_state("WAIT")

    # ---- states & views ------------------------------------------------------
    # WAIT -> WIND_UP -> PITCH -> BALL_IN_FLIGHT (home run) | FIELD_PLAY (everything else) -> MESSAGE -> WAIT ...
    def hot_check(self, good):
        """Called when a ball in play is finished: an out (or an error) ends a hot streak."""
        if not good:
            self.streak = 0

    def set_batter(self, i):
        """The next hitter in the order steps in: his skin tone and his bat come with him."""
        self.batter_i = i % len(self.lineup)
        b = self.lineup[self.batter_i]
        self.skin = b["skin"]
        set_current_bat(b["bat"])

    def credit(self, hit=False, hr=False, ab=True):
        """Today's line for the batter who just finished his at-bat."""
        b = self.lineup[self.batter_i]
        b["ab"] += 1 if ab else 0
        b["h"] += 1 if hit else 0
        b["hr"] += 1 if hr else 0

    def on_fire(self):
        return self.streak >= ON_FIRE_STREAK

    def fatigue(self):
        return clamp((self.pitch_count - FATIGUE_START) / FATIGUE_SPAN, 0.0, 1.0)

    def cheer(self, amount):
        """Fire up the crowd and your dugout."""
        self.crowd_energy = min(1.5, self.crowd_energy + amount)

    def cheer_cpu(self, amount):
        """Fire up the CPU's dugout (it just got an out or scored)."""
        self.cpu_cheer = min(1.5, self.cpu_cheer + amount)

    def blit_bat_scene(self, surf, t=None, energy=None):
        """The batting-view background with the moving crowd on top."""
        surf.blit(self.bat_background, (0, 0))
        draw_crowd(surf, self.bat_crowd, self.clock if t is None else t,
                   self.crowd_energy if energy is None else energy, self.team_color, BAT_W, CROWD_KEEP.get(self.weather, 1.0))

    def blit_field_scene(self, surf, t=None, energy=None):
        """The overhead field with the moving crowd and the two dugouts (with players) on top."""
        t = self.clock if t is None else t
        e = self.crowd_energy if energy is None else energy
        surf.blit(self.field_background, (0, 0))
        draw_crowd(surf, self.field_crowd, t, e, self.team_color, LOGICAL_W, CROWD_KEEP.get(self.weather, 1.0))
        cpu_e = self.cpu_cheer if energy is None else energy * 0.8
        (hx, hy), (cx, cy) = DUGOUTS["left"], DUGOUTS["right"]
        draw_dugout_players(surf, hx, hy, (240, 240, 240), self.team_color, t, e, 0.4)       # your guys: left dugout
        draw_dugout_players(surf, cx, cy, FIELD_BODY, FIELD_CAP, t, cpu_e, 2.9)              # the CPU's guys: right dugout
        draw_dugout_front(surf, hx, hy)
        draw_dugout_front(surf, cx, cy)

    def set_state(self, state):
        self.state, self.state_time = state, 0.0
        if state != "MESSAGE":
            self.celebrating = False                         # stop the fireworks once we leave the message
        if state == "WAIT" and self.new_batter:              # the at-bat is over: a fresh batter steps in, already in his stance
            self.new_batter = False
            self.set_batter(self.batter_i + 1)               # the next hitter in the order (his own skin tone and bat)
            self.swing_clock, self.settle = -1, 1.0          # (no follow-through held over from the last batter)
        if state in ("WAIT", "WIND_UP", "PITCH", "BALL_IN_FLIGHT", "HR_CUTSCENE", "GAME_OVER"):
            self.set_view("bat")

    def set_view(self, view):
        if view != self.view:
            self.view, self.fade = view, FADE_TIME

    def show_message(self, big, small="", duration=MESSAGE_TIME, then=None, wait=False):
        """Show a result. wait=True (used after contact) keeps it up until the player clicks NEXT PITCH."""
        self.message, self.sub_message = big, small
        self.message_duration, self.after_message, self.wait_click = duration, then, wait
        self.celebrating = False
        self.set_state("MESSAGE")

    def continue_after_message(self):
        after, self.after_message, self.wait_click = self.after_message, None, False
        self.fan = None
        if after:
            after()
        else:
            self.set_state("WAIT")

    # ---- input ---------------------------------------------------------------
    def press_swing(self):
        if self.paused:
            return
        if self.state == "GAME_OVER":
            self.quit_to_menu = True                         # back to the start screen
        elif self.state == "FIELD_PLAY":
            self.action_return()                             # SPACE while running: back to the previous base
        elif self.state == "PITCH" and not self.pitch.swung:
            self.swing()
        elif self.state == "HR_CUTSCENE" and self.state_time > 0.8:
            self.finish_slugger()                            # click / SPACE skips the cutscene
        elif self.state == "MESSAGE" and self.wait_click and self.state_time >= NEXT_PITCH_DELAY:
            self.continue_after_message()                    # SPACE = NEXT PITCH

    def press_click(self, pos):
        """Mouse click at a canvas position."""
        if self.paused:
            return self.pause_click(pos)
        if self.state == "MESSAGE" and self.wait_click:      # only the NEXT PITCH button continues
            if self.state_time >= NEXT_PITCH_DELAY and math.hypot(pos[0] - NEXT_BUTTON[0], pos[1] - NEXT_BUTTON[1]) <= NEXT_BUTTON_RADIUS:
                self.continue_after_message()
            return
        if self.state != "FIELD_PLAY":
            return self.press_swing()
        button = self.field_button()
        if button and pygame.Rect(button[1] - 40, button[2] - 22, 80, 96).collidepoint(pos):
            return self.action_slide() if button[0] == "Slide" else self.action_send()
        runner = self.fp.runner
        rx, ry = point_on_path(runner.pos)
        if math.hypot(pos[0] - rx, pos[1] - (ry - 16)) <= 30:
            self.action_turn() if runner.moving else self.action_send()

    def press_run_key(self):
        """R: send a standing runner, or tell a moving runner to run THROUGH the next bag."""
        if self.state != "FIELD_PLAY" or self.fp.pending or self.fp.close:      # (no orders once a close play has started)
            return
        runner = self.fp.runner
        if not runner.moving:
            self.action_send()
        elif runner.forward and not runner.sliding and self.can_continue_from(runner.target):
            runner.run_through = True

    def press_slide_key(self):
        """S: slide during a play, or (before the pitch, runners on) tell the runners to steal."""
        if self.state == "FIELD_PLAY":
            self.action_slide()
        elif self.state in ("WAIT", "WIND_UP") and any(self.bases):
            self.steal_armed = not self.steal_armed

    # ---- pitching ------------------------------------------------------------
    def choose_pitch(self):
        """The pitching brain: weights each pitch by the count, the runners and what he just threw."""
        names = list(self.diff["pitches"])
        weights = {n: PITCHES[n]["chance"] for n in names}
        chase = [n for n in names if not PITCHES[n]["hittable"]]         # splitter / slider: always balls
        if self.strikes == 2:                                            # put him away with something he'll chase
            for n in chase:
                weights[n] *= 2.2
            weights["Curveball"] *= 1.3
        elif self.balls == 3:                                            # can't walk him: throw a strike
            for n in chase:
                weights[n] *= 0.15
            weights["Fastball"] *= 2.0
        elif self.balls >= 2 and self.strikes == 0:
            weights["Fastball"] *= 1.4
        if self.balls == 0 and self.strikes == 0:                        # first-pitch strike
            weights["Fastball"] *= 1.3
        if any(self.bases):                                              # hold the runners with the heat
            weights["Fastball"] *= 1.3
        for n in names:                                                  # attack what you keep missing / fouling
            weights[n] *= 1 + 0.3 * min(3, self.weak_vs.get(n, 0))
        if self.pitch_history:
            last = self.pitch_history[-1]
            weights[last] *= 0.55                                        # don't be predictable
            if last == "Fastball" and "Changeup" in weights:
                weights["Changeup"] *= 1.8                               # change speeds after the heat
        return random.choices(names, weights=[weights[n] for n in names])[0]

    def choose_zone(self):
        weights = list(ZONE_WEIGHTS)
        if self.strikes == 2:
            weights = [35, 30, 35]                                       # work the edges with two strikes
        elif self.balls == 3:
            weights = [15, 70, 15]                                       # right down the middle
        weights[1] += 40 * self.fatigue()                                # a tired pitcher leaves it over the heart of the plate
        return random.choices([-1, 0, 1], weights=weights)[0]

    def start_pitch(self):
        self.finish_big = bool(self.hit and self.hit.quality == "perfect_perfect")      # which finish was he holding?
        self.settle = 0.0 if (self.swing_clock >= 0 and not self.new_batter) else 1.0   # same batter: ease back to the stance
        if self.new_batter:                                  # a new batter steps in
            self.new_batter = False
            self.set_batter(self.batter_i + 1)
        name = self.choose_pitch()
        cfg = PITCHES[name]
        t = random.random()
        speed = self.diff["speed"] * (1 - FATIGUE_SLOWDOWN * self.fatigue())     # difficulty (and a tired arm): >1 = faster pitches, <1 = slower
        self.pitch_count += 1
        zone = self.choose_zone()
        self.pitch = Pitch(name, lerp(*cfg["seconds"], t) / speed, round(lerp(*cfg["mph"], t) * speed), cfg["hittable"],
                           zone=zone, offset=zone * self.diff["zone_offset"])
        self.pitch_history = (self.pitch_history + [name])[-3:]
        self.hit = self.fp = self.fan = None
        self.board_hit, self.board_time = False, -1.0
        self.swing_clock = -1
        self.set_state("WIND_UP")

    def swing(self):
        """Judge the swing by how far it was from the perfect moment (which depends on pitch location)."""
        pitch = self.pitch
        pitch.swung, pitch.swing_time = True, pitch.time
        self.swing_clock = 0
        raw_error = pitch.time - pitch.duration                  # vs. the plate: used for which way the ball is pulled
        error = pitch.time - (pitch.duration + pitch.offset)     # vs. the perfect swing for this location
        batter = self.lineup[self.batter_i]                      # his contact rating, his bat and a hot streak all widen the windows
        size = abs(error) / (batter["contact"] * CURRENT_BAT["window"] * (ON_FIRE_CONTACT if self.on_fire() else 1.0))
        # a normally unhittable pitch (the splitter) can be hit on Easy, but only inside the green window
        can_hit = pitch.hittable or (self.diff["splitter_in_green"] and size < self.win_perfect)
        if not can_hit:
            pitch.label = "MISS"
        elif size < self.win_pp:
            pitch.label = "PERFECT PERFECT"
        elif size < self.win_perfect:
            pitch.label = "PERFECT"
        elif size < self.win_good:
            pitch.label = "GOOD"
        else:
            pitch.label = "EARLY" if error < 0 else "LATE"
        good_swing = can_hit and size < self.win_good
        if good_swing:
            self.streak += 1
            if self.streak == ON_FIRE_STREAK:
                self.fire_flash = 1.8
                self.cheer(0.8)
            self.stats["best_streak"] = max(self.stats["best_streak"], self.streak)
        else:
            self.streak = 0
        if pitch.hittable:                                       # the pitcher remembers the pitches you can't hit
            self.weak_vs[pitch.name] = max(0, self.weak_vs.get(pitch.name, 0) + (-1 if good_swing else 1))
        if can_hit and size < self.win_perfect:
            self.stats["perfect"] += 1
            self.cheer(0.9 if size < self.win_pp else 0.4)                 # the crowd loves a great swing

        if not can_hit or size > self.win_foul:
            pitch.result = "miss"
        elif size > self.win_contact:
            pitch.result = "foul"
        else:
            quality = ("perfect_perfect" if size < self.win_pp else "perfect" if size < self.win_perfect
                       else "good" if size < self.win_good else "weak")
            self.make_contact(quality, raw_error)

    def resolve_steal(self, pitch):
        """Runners go on the pitch. Returns (note, third_out)."""
        first, second, third = self.bases
        self.stats["steal_att"] += 1
        if random.random() < STEAL_CHANCE[pitch.name]:
            self.stats["steals"] += 1
            scored = 1 if third else 0
            self.runs += scored
            self.bases = [0, first, second]                  # everybody moves up one base
            return "Stolen base!" + (" Run scores!" if scored else ""), False
        if third:                                            # the lead runner is the one who gets thrown out
            third = 0
        elif second:
            second = 0
        else:
            first = 0
        self.bases = [first, second, third]
        self.outs += 1
        return "Caught stealing!", self.outs >= OUTS_PER_INNING

    def finish_pitch_without_contact(self):
        """The ball passed: strike, ball, foul, or swing-and-miss."""
        pitch = self.pitch
        armed, self.steal_armed = self.steal_armed, False
        note = ""
        if armed and pitch.result != "foul" and any(self.bases):      # on a foul the runners go back
            note, third_out = self.resolve_steal(pitch)
            if third_out:
                self.end_at_bat()
                return self.show_message("CAUGHT STEALING", "Side retired", then=self.end_inning)
        info = f"{pitch.name} {pitch.mph} MPH"
        if note:
            info += f"  |  {note}"
        if pitch.result == "foul":
            if random.random() < FOUL_CAUGHT_CHANCE:                  # a foul pop that gets caught
                return self.record_out("FOUL OUT", "Caught in foul territory")
            if self.strikes == STRIKES_FOR_OUT - 1 and random.random() < FOUL_TIP_CHANCE:
                return self.record_out("STRIKEOUT (FOUL TIP)", info)
            self.strikes = min(self.strikes + 1, STRIKES_FOR_OUT - 1)
            self.show_message("FOUL BALL", info)
        elif pitch.result == "miss" or pitch.hittable:       # swung and missed, or took a strike
            self.strikes += 1
            if self.strikes >= STRIKES_FOR_OUT:
                self.record_out("STRIKEOUT" if pitch.result else "STRIKEOUT LOOKING", info)
            else:
                self.show_message("SWING & MISS" if pitch.result else "STRIKE", info)
        else:                                                # took a splitter / slider -> ball
            self.balls += 1
            if self.balls >= BALLS_FOR_WALK:
                self.walk(note)
            else:
                self.show_message("BALL", info)

    # ---- contact -------------------------------------------------------------
    def make_contact(self, quality, raw_error):
        self.steal_armed = False                             # the steal is called off when the ball is put in play
        roll = random.random()
        kind = next(result for chance, result in HIT_TABLES[quality] if roll < chance)
        power = self.lineup[self.batter_i]["power"] * CURRENT_BAT["power"]       # a slugger's singles become doubles, a slap hitter's homers become doubles
        up, down, r = clamp((power - 1) * POWER_UPGRADE, 0, 0.45), clamp((1 - power) * POWER_UPGRADE, 0, 0.45), random.random()
        if kind in ("1B", "2B") and r < up:
            kind = "HR" if (kind == "2B" and quality == "perfect") else "2B" if kind == "1B" else kind
        elif kind in ("HR", "2B") and quality != "perfect_perfect" and r > 1 - down:
            kind = {"HR": "2B", "2B": "1B"}[kind]
        info = HIT_INFO[kind]
        x, y, _ = pitch_position(self.pitch, self.pitch.time / self.pitch.duration)
        sideways = clamp(raw_error * 1500 + (random.random() - 0.5) * 120, -300, 300)   # early = left, late = right
        if kind == "HR":
            sideways = clamp(sideways + random.uniform(-110, 110), -300, 300)          # homers spray around the stands
        self.hit = Hit(kind, quality, x, y, sideways, info["flight"] if kind == "HR" else info["flight"] / BALL_SPEED, info["arc"])
        self.hit.broken_bat = quality == "weak" and random.random() < BROKEN_BAT_CHANCE     # rare animation roll
        self.fan = None
        self.board_hit = False
        if quality == "perfect":                             # screen shake on the big ones
            self.shake, self.shake_mag = SHAKE_TIME, SHAKE_PERFECT
        elif quality == "perfect_perfect":
            self.shake, self.shake_mag = SHAKE_TIME, SHAKE_PERFECT_PERFECT
        self.hr_distance = 0
        if kind == "HR" and quality == "perfect_perfect" and SLUGGER_CUTSCENE:
            self.hr_distance = random.randint(400, 550)
            self.hit.distance = self.hr_distance
            self.set_state("HR_CUTSCENE")                    # the special side-view cutscene
        elif kind == "HR":
            self.hr_distance = random.randint(350, 449) if quality == "perfect" else random.randint(400, 550)
            self.hit.distance = self.hr_distance
            end_x = x + sideways
            if BOARD_X_MIN <= end_x <= BOARD_X_MAX:          # headed for the scoreboard...
                if random.random() < BOARD_HIT_CHANCE:       # rare animation: it smacks the scoreboard
                    self.board_hit = True
                else:                                        # ...usually it just clears it to one side
                    end_x = random.choice((BOARD_X_MIN - random.uniform(10, 70), BOARD_X_MAX + random.uniform(10, 70)))
                    self.hit.sideways = end_x - x
            if not self.board_hit and random.random() < FAN_CATCH_CHANCE:    # rare animation: a fan catches it
                self.fan = (end_x, hr_end_y(self.hr_distance))
            if not self.board_hit and not self.fan and self.hr_distance < ROB_MAX_FT and random.random() < ROB_CHANCE:
                self.hit.robbed = True                       # rare: an outfielder leaps and steals it at the wall
                self.hit.sideways = clamp(end_x, 90, 680) - x
            self.hit.flip = (not self.hit.robbed and self.hr_distance >= FLIP_MIN_FT and random.random() < FLIP_CHANCE)
            self.set_state("BALL_IN_FLIGHT")                 # stays in the batting view
        else:
            self.start_field_play()                          # cut to the overhead view

    def start_field_play(self):
        hit = self.hit
        hit.land_x, hit.land_y = landing_spot(hit.kind, hit.sideways)
        if hit.arc > 0 and self.wind["mph"]:                 # the wind carries (or knocks down) fly balls
            w = self.wind
            f = 1 + 0.012 * w["mph"] * (1 if w["way"] == "OUT" else -1 if w["way"] == "IN" else 0)
            hit.land_x = clamp(HOME[0] + (hit.land_x - HOME[0]) * f + (3 * w["mph"] * w["cross"] if w["way"] == "CROSS" else 0), 80, 1200)
            hit.land_y = clamp(HOME[1] + (hit.land_y - HOME[1]) * f, 262, 700)
        fielders = [Fielder(name, post, post[0], post[1]) for name, post in FIELDER_POSTS.items()]
        index = {f.name: i for i, f in enumerate(fielders)}
        for f in fielders:
            f.home, f.job = f.post, ""                          # where he normally stands / what he is busy doing
        # the closest fielder (not the catcher) chases the ball
        chaser = min((i for i, f in enumerate(fielders) if f.name != "C"),
                     key=lambda i: math.hypot(fielders[i].x - hit.land_x, fielders[i].y - hit.land_y))
        boost = 1.0
        if hit.arc > 0:
            # FLY BALL: the fielder reads where it will land (not perfectly), runs there, and when the ball comes down
            # it is a catch if he is inside the catch circle - otherwise it falls in for a hit.
            f = fielders[chaser]
            a, r = random.uniform(0, 2 * math.pi), FIELDER_MISJUDGE * math.sqrt(random.random())
            hit.read_x, hit.read_y = hit.land_x + r * math.cos(a), hit.land_y + r * math.sin(a)
            dx, dy = hit.read_x - f.x, hit.read_y - f.y
            dist = math.hypot(dx, dy)
            travel = min(dist, FIELDER_SPEED * max(0.0, hit.flight - FIELDER_REACTION))
            hit.catch_x = f.x + dx / dist * travel if dist else f.x
            hit.catch_y = f.y + dy / dist * travel if dist else f.y
            gap = math.hypot(hit.catch_x - hit.land_x, hit.catch_y - hit.land_y)
            hit.caught = gap <= CATCH_RADIUS.get(hit.quality, CATCH_RADIUS["good"])
            if hit.caught:
                hit.kind = "FLY_OUT"                         # inside the circle: an out, however it was hit
            elif hit.kind == "FLY_OUT":                      # outside the circle: a pop-up that drops in is a hit
                hit.kind = "1B" if math.hypot(hit.land_x - HOME[0], hit.land_y - HOME[1]) < 310 else "2B"
        info = HIT_INFO[hit.kind]

        # runners already on base advance automatically (as many bases as the hit earned, or forced on a grounder)
        if hit.kind == "GROUND_OUT":
            first, second, third = self.bases
            advance = [1 if first else 0, 1 if first and second else 0, 1 if first and second and third else 0]
        else:
            advance = [info["earned"]] * 3
        others, runs, new_bases = [], 0, [0, 0, 0]
        for i, on_base in enumerate(self.bases):
            if on_base:
                end = min(4, i + 1 + advance[i])
                forced = hit.kind == "GROUND_OUT" and end > i + 1           # a force play: he CAN be put out (double plays!)
                others.append(dict(start=i + 1, end=end, pos=float(i + 1), skin=on_base, target=end, forward=True, moving=end > i + 1,
                                   auto=not forced, out=False, scored=False, origin=i + 1,
                                   speed=FORCE_RUN_MULT if forced else 1.0))     # on_base holds his skin tone
                if end >= 4: runs += 1
                else: new_bases[end - 1] = on_base

        runner = Runner(earned=0, moving=True, wait=BATTER_START_DELAY)   # batter runs to first by himself (even on likely outs)
        self.fp = FieldPlay(hit, runner, fielders, Ball(HOME[0], HOME[1] - 10), others, runs, new_bases, index, chaser, boost)
        self.fp.skin = self.skin
        self.fp.dive_plan = hit.kind == "GROUND_OUT" and random.random() < DIVE_CHANCE      # rare animation rolls
        self.fp.leap_plan = hit.kind == "FLY_OUT" and random.random() < LEAP_CHANCE
        if hit.broken_bat:
            self.fp.broken = dict(t=0.0, dir=unit(hit.land_x - HOME[0], hit.land_y - HOME[1]))
        # better fielding: a backup runs behind the ball, and the pitcher backs up home on deep hits
        if hit.kind in ("1B", "2B", "3B") and math.hypot(hit.land_x - HOME[0], hit.land_y - HOME[1]) > 250:
            others_f = [f for i, f in enumerate(fielders) if i != chaser and f.name not in ("C", "P")]
            backup = min(others_f, key=lambda f: math.hypot(f.x - hit.land_x, f.y - hit.land_y))
            ux, uy = unit(hit.land_x - HOME[0], hit.land_y - HOME[1])
            backup.post = backup.home = (clamp(hit.land_x + ux * BACKUP_DISTANCE, 60, 1220), clamp(hit.land_y + uy * BACKUP_DISTANCE, 255, 700))
            fielders[index["P"]].post = fielders[index["P"]].home = (HOME[0], HOME[1] - 60)
        self.set_view("field")
        self.set_state("FIELD_PLAY")

    # ---- the field play: update ----------------------------------------------
    def update_field_play(self, dt):
        fp = self.fp
        fp.time += dt
        self.update_others(dt)
        self.update_walk(dt)                                 # (a batter who has just been put out walking back to the dugout)
        if fp.pending:
            if not self.others_moving():                     # (the play isn't over while a runner is still running)
                fp.pending_time -= dt
                if fp.pending_time <= 0:
                    self.finish_field_play(*fp.pending)
                    return
        else:
            self.update_runner(dt)
        self.update_ball(dt)
        self.update_cover()
        self.update_fielders(dt)
        self.update_rare(dt)
        self.update_gait(dt)
        self.age_dust(dt)
        self.check_close_play()
        self.close_track()
        if not fp.pending or self.others_moving():
            self.fielder_ai()
        if not fp.pending:
            self.check_dead_ball(dt)
            if fp.time > FIELD_PLAY_TIMEOUT:
                self.decide_standing()

    # ---- the other runners (the ones who were already on base) -------------------------------------
    def others_moving(self):
        return any(o["moving"] for o in self.fp.others if not o["out"] and not o["scored"])

    def live_bases(self):
        """The bases runners are running toward right now: the batter-runner, plus anyone sent ahead of him."""
        fp = self.fp
        bases = [fp.runner.target] if fp.runner.moving else []
        return bases + [o["target"] for o in fp.others if o["moving"] and not o["auto"] and not o["out"] and not o["scored"]]

    def other_on(self, base):
        """The other runner who is on (or heading for) this base, if any."""
        for o in self.fp.others:
            if not o["out"] and not o["scored"] and (o["target"] if o["moving"] else round(o["pos"])) == base:
                return o
        return None

    def push_lead_runners(self, base):
        """The batter-runner is leaving `base` for the next one: a runner standing on that next base must go one base ahead,
        and so on down the line. (They run on their own: you only control the batter-runner.)"""
        chain, k = [], base + 1
        while k <= 3:                                        # first find everybody in the chain (before anyone moves)...
            o = self.other_on(k)
            if not o:
                break
            chain.append((k, o))
            k += 1
        for k, o in chain:                                   # ...then send them all one base ahead
            o.update(target=k + 1, forward=True, moving=True, auto=False, origin=k, pushed_by=base)
            # (pushed_by = the base the batter-runner was leaving. If he turns back to it, this runner goes back too -
            #  even if he already reached the next bag - so nobody is left stranded an extra base ahead.)

    def update_others(self, dt):
        for o in self.fp.others:
            if o["out"] or o["scored"] or not o["moving"]:
                continue
            if o.get("delay", 0) > 0:                        # a runner tagging up waits a moment after the catch
                o["delay"] -= dt
                continue
            if o["auto"] and self.fp.time <= RUNNER_START_DELAY:
                continue
            step = RUNNER_SPEED * o.get("speed", 1.0) * dt
            if o["forward"]:
                new_pos = min(o["pos"] + step, o["target"])
                r = self.fp.runner
                if o.get("pushed_by") is not None and not self.fp.pending and r.forward:
                    # A runner pushed ahead by the batter-runner keeps PACE with him: he never gets further ahead than he
                    # started (one base per runner in the chain), so he can't race all the way home while you are still
                    # rounding a bag - and if you turn back, he hasn't gone anywhere he can't come back from.
                    lead = o["origin"] - o["pushed_by"]
                    new_pos = min(new_pos, max(o["pos"], r.pos + lead))
                o["pos"] = new_pos
            else:
                o["pos"] = max(o["pos"] - step, o["target"])
            if o["pos"] == o["target"]:
                self.other_arrives(o)

    def other_arrives(self, o):
        base = o["target"]
        o["pos"] = float(base)
        self.close_result(base, not o["auto"] and self.ball_at_base(base))
        if not o["auto"] and self.ball_at_base(base):        # the ball beat him to the bag (he reached it first, THEN he is out)
            o["moving"], o["out"] = False, True
        elif base >= 4 and o["forward"]:
            o["moving"], o["scored"] = False, True
        else:
            o["moving"], o["end"] = False, base

    def check_close_play(self):
        """A close play: a runner running to a bag is within CLOSE_RUNNER_RANGE of it while the ball (thrown to that bag, or in the
        hands of a fielder) is within CLOSE_BALL_RADIUS of it. Once per play."""
        fp, ball = self.fp, self.fp.ball
        if fp.close_done or fp.pending:
            return
        runners = []
        r = fp.runner
        if r.moving and r.forward and r.wait <= 0:
            runners.append((r.target, r.target - r.pos))
        for o in fp.others:
            if o["moving"] and o["forward"] and not o["out"] and not o["scored"] and o.get("delay", 0) <= 0:
                runners.append((o["target"], o["target"] - o["pos"]))
        if ball.mode == "thrown":
            u = clamp(ball.t / ball.dur, 0, 1)
            bx, by = lerp(ball.sx, ball.tx, u), lerp(ball.sy, ball.ty, u)
        elif ball.mode == "held":
            f = fp.fielders[ball.holder]
            bx, by = f.x, f.y
        else:
            return
        for base, gap in runners:
            if not 1 <= base <= 3 or not 0 < gap <= CLOSE_RUNNER_RANGE:
                continue
            bag = BASES[base]
            if math.hypot(bx - bag[0], by - bag[1]) > CLOSE_BALL_RADIUS:
                continue
            if ball.mode == "thrown" and math.hypot(ball.tx - bag[0], ball.ty - bag[1]) > CLOSE_BALL_RADIUS + 25:
                continue                                     # (that throw is going somewhere else)
            fp.close, fp.close_done = dict(base=base, t=0.0, result=None, tres=0.0, gap=gap, dist=0.0, dist_res=0.0, skin=SKIN_DEFAULT), True
            self.close_track()
            return

    def close_track(self):
        """Keep the cutscene's numbers up to date: how far the runner is from the bag and how far the ball is."""
        fp = self.fp
        c, ball = fp.close, fp.ball
        if not c or c["result"] is not None:
            return
        base, bag = c["base"], BASES[c["base"]]
        gaps = []
        r = fp.runner
        if r.moving and r.forward and r.target == base:
            gaps.append((r.target - r.pos, fp.skin or SKIN_DEFAULT))
        for o in fp.others:
            if o["moving"] and o["forward"] and o["target"] == base and not o["out"] and not o["scored"]:
                gaps.append((o["target"] - o["pos"], o["skin"] if isinstance(o["skin"], tuple) else SKIN_DEFAULT))
        if gaps:
            c["gap"], c["skin"] = min(gaps, key=lambda g: g[0])
        if ball.mode == "thrown":
            u = clamp(ball.t / ball.dur, 0, 1)
            bx, by = lerp(ball.sx, ball.tx, u), lerp(ball.sy, ball.ty, u)
        elif ball.mode == "held":
            f = fp.fielders[ball.holder]
            bx, by = f.x, f.y
        else:
            return
        c["dist"] = math.hypot(bx - bag[0], by - bag[1])

    def close_vals(self):
        c = self.fp.close
        if c["result"] is None:
            return c["gap"], c["dist"]
        late = c["result"] == "safe"
        return 0.0, (c["dist_res"] * (1 - clamp(c["tres"] / 0.35, 0, 1)) if late else 0.0)

    def close_cutscene_active(self):
        c = self.fp.close if self.fp else None
        if not c or self.view != "field":
            return False
        if c["result"] is None:
            return self.state == "FIELD_PLAY" and c["t"] < 5.0
        return c["tres"] < CLOSE_SHOW_TIME

    def close_result(self, base, out):
        c = self.fp.close
        if c and c["base"] == base and c["result"] is None:
            c["result"], c["tres"], c["dist_res"] = ("out" if out else "safe"), 0.0, c["dist"]

    def close_slowmo(self, dt):
        """Real-time clock for the close play; returns the speed the field play should run at (slow motion until the call)."""
        c = self.fp.close if self.fp else None
        if not c:
            return 1.0
        c["t"] += dt
        if c["result"] is not None:
            c["tres"] += dt
        slow = (c["result"] is None and c["t"] < CLOSE_SLOW_TIME) or (c["result"] is not None and c["tres"] < 1.0)
        return CLOSE_SLOW if slow else 1.0

    def start_tag_ups(self):
        """A fly ball to the outfield was caught: runners on base may TAG UP and go on the throw (a sacrifice fly if the man on
        third scores). They only go if they think they beat the throw, so a deep fly gets them moving and a shallow one doesn't."""
        fp = self.fp
        if self.outs + 1 >= OUTS_PER_INNING:
            return                                           # that was the third out: nobody runs
        fielder = fp.fielders[fp.chaser]
        if fielder.name not in ("LF", "CF", "RF"):
            return
        waiting = {round(o["pos"]): o for o in fp.others if not o["moving"] and not o["out"] and not o["scored"]}
        going = set()
        for base in (3, 2, 1):
            o = waiting.get(base)
            if not o or (base + 1 <= 3 and (base + 1) in waiting and (base + 1) not in going):
                continue                                     # nobody there, or the man ahead of him isn't going
            nx, ny = BASES[base + 1]
            throw_time = FIELDER_PICKUP_TIME + math.hypot(fielder.x - nx, fielder.y - ny) / THROW_SPEED + RELAY_TIME
            runner_time = TAG_DELAY + 1.0 / (RUNNER_SPEED * TAG_SPEED_MULT)
            if runner_time <= throw_time + TAG_RISK:
                o.update(target=base + 1, forward=True, moving=True, auto=False, origin=base, delay=TAG_DELAY, speed=TAG_SPEED_MULT,
                         pushed_by=None)
                going.add(base)

    def pick_chaser(self):
        """A loose ball: whoever is CLOSEST to it goes after it (not just the man who first went for it)."""
        fp, ball = self.fp, self.fp.ball
        dist = lambda i: math.hypot(fp.fielders[i].x - ball.x, fp.fielders[i].y - ball.y)
        nearest = min((i for i, f in enumerate(fp.fielders) if f.name != "C"), key=dist)
        if nearest != fp.chaser and dist(nearest) < dist(fp.chaser) - 20:
            fp.chaser = nearest
            fp.fielders[nearest].job = ""

    def update_cover(self):
        """Fielders who are not busy (going after the ball, holding it, or catching a throw) COVER BAGS:
        1B takes first (unless the ball was hit to him: then the pitcher does), 2B or SS second, 3B third, the catcher home.
        Anybody left over goes back to his normal spot."""
        fp, ball = self.fp, self.fp.ball
        chasing = fp.chaser if ball.mode in ("flying", "loose") else -1
        free = {}
        for i, f in enumerate(fp.fielders):
            busy = (i == chasing or f.job or (ball.mode == "held" and i == ball.holder)
                    or (ball.mode == "thrown" and i == ball.receiver))
            if not busy:
                free[f.name] = i
        priority = {1: ("1B", "P", "2B"), 2: ("2B", "SS", "CF"), 3: ("3B", "SS", "P"), 4: ("C", "P")}
        taken = set()
        for base in (1, 2, 3, 4):
            for name in priority[base]:
                i = free.get(name)
                if i is not None and i not in taken:
                    taken.add(i)
                    fp.fielders[i].post = BASES[base]
                    break
        for name, i in free.items():
            f = fp.fielders[i]
            if i not in taken and f.post in BASES:
                f.post = f.home

    def decide(self, outcome, base, delay):
        """The play is decided; wait `delay` seconds so the player can see it, then show the result."""
        self.fp.pending, self.fp.pending_time = (outcome, base), delay
        self.fp.runner.moving = False
        if outcome in ("out", "flyout", "norun"):
            self.start_dugout_walk()                         # he's out: he turns around right now and heads for the dugout

    def decide_standing(self):
        """Play over with the runner standing still: safe on his bag, or out if he never left home."""
        base = round(self.fp.runner.pos)
        self.decide("safe" if base > 0 else "norun", base, 0)

    def update_runner(self, dt):
        r = self.fp.runner
        r.turn_cooldown = max(0.0, r.turn_cooldown - dt)
        r.recovery = max(0.0, r.recovery - dt)
        if not r.moving:
            return
        if r.wait > 0:                                       # reaction time at the start
            r.wait -= dt
            return
        step = RUNNER_SPEED * self.lineup[self.batter_i]["speed"] * (SLIDE_SPEED_MULT if r.sliding else 1.0) * dt
        r.pos = min(r.pos + step, r.target) if r.forward else max(r.pos - step, r.target)
        if r.pos == r.target:
            self.runner_arrives()                            # he reaches the bag first; only THEN can he be called out
        elif r.forward and r.target == 1 and r.target - r.pos <= OUT_CALL_RANGE and self.ball_at_base(1):
            self.close_result(1, True)
            self.decide("out", 1, 0.9)                       # FORCE OUT at first: the batter MUST run, so the ball beating him there is enough.
                                                             # (Anywhere else it is a TAG play: he is only out once he actually reaches the bag.)

    def runner_arrives(self):
        r = self.fp.runner
        base = r.target
        self.close_result(base, base > r.earned and self.ball_at_base(base))
        if base > r.earned and self.ball_at_base(base):      # ball beat him to the bag
            return self.decide("out", base, 0.9)
        if base >= 4:
            return self.decide("score", 4, 0.5)
        if r.forward and (base < r.earned or (r.run_through and self.can_continue_from(base) and not r.sliding)):
            r.target, r.run_through = base + 1, False
            self.push_lead_runners(base)        # keep running (earned bases / run-through)
            return
        r.moving, r.run_through = False, False               # stop on the bag
        if r.sliding:
            r.sliding, r.recovery = False, SLIDE_RECOVERY

    def update_ball(self, dt):
        fp, ball, hit = self.fp, self.fp.ball, self.fp.hit
        if ball.mode == "flying":
            ball.t += dt
            u = min(1, ball.t / hit.flight)
            end_x, end_y = (hit.catch_x, hit.catch_y) if hit.caught else (hit.land_x, hit.land_y)   # a caught ball drops into the glove
            ball.x, ball.y = lerp(HOME[0], end_x, u), lerp(HOME[1], end_y, u)
            ball.z = abs(math.sin(u * math.pi * 5)) * 12 * (1 - u) if hit.arc == 0 else hit.arc * math.sin(math.pi * u)
            if fp.leap_plan:
                ball.z += LEAP_GLOVE_Z * u ** 3              # the ball arrives at glove height for the leaping catch
            elif hit.kind == "FLY_OUT":
                ball.z += 10 * u ** 3                        # a normal catch: the ball comes down into the glove
                ball.x += 8 * u ** 3
            if u >= 1:
                ball.z = 0
                if hit.kind == "FLY_OUT":                    # caught in the air
                    ball.mode, ball.holder, ball.hold_time, ball.quick = "held", fp.chaser, 0.0, False
                    fp.catch = dict(t=0.0)
                    self.decide("flyout", 0, 0.9)
                    self.start_tag_ups()
                else:                                        # it falls in: bounce and keep rolling
                    ball.mode, ball.bt = "loose", 0.0
                    ux, uy = unit(hit.land_x - HOME[0], hit.land_y - HOME[1])
                    speed = HIT_ROLL_SPEED if hit.arc > 0 else GROUNDER_ROLL_SPEED
                    ball.vx, ball.vy = ux * speed, uy * speed
                    if hit.arc > 0:
                        fp.landed = dict(t=0.0, x=ball.x, y=ball.y)
        elif ball.mode == "loose":
            ball.bt += dt
            drag = math.exp(-ROLL_DRAG * dt)
            ball.vx *= drag
            ball.vy *= drag
            ball.x = clamp(ball.x + ball.vx * dt, 40, 1240)
            ball.y = clamp(ball.y + ball.vy * dt, 255, 700)
            ball.z = abs(math.sin(ball.bt * 9)) * 14 * math.exp(-3 * ball.bt) if hit.arc > 0 else 0
            self.pick_chaser()                               # the nearest fielder to the ball goes for it
            chaser = fp.fielders[fp.chaser]
            if math.hypot(chaser.x - ball.x, chaser.y - ball.y) < 14 and fp.fumble and fp.chaser in fp.fumble:
                pass                                         # he is still fumbling: he can't get a hand on it yet
            elif math.hypot(chaser.x - ball.x, chaser.y - ball.y) < 14:
                if (not fp.error_done and not fp.fumble and random.random() < (FIELD_ERROR_CHANCE if hit.arc == 0 else FIELD_ERROR_CHANCE * 0.6)):
                    fp.error_done = fp.error = True               # ERROR: the ball pops out of his glove and skips away
                    self.stats["errors"] += 1
                    fp.error_fx = dict(t=0.0, x=chaser.x, y=chaser.y)
                    fp.fumble = {fp.chaser: 0.9}
                    ux, uy = unit(ball.x - HOME[0], ball.y - HOME[1])
                    a = math.atan2(uy, ux) + random.uniform(-1.4, 1.4)
                    ball.vx, ball.vy, ball.bt = math.cos(a) * 150, math.sin(a) * 150, 0.0
                else:
                    ball.mode, ball.holder, ball.hold_time, ball.quick = "held", fp.chaser, 0.0, False
        elif ball.mode == "thrown":
            ball.t += dt
            u = min(1, ball.t / ball.dur)
            ball.x, ball.y = lerp(ball.sx, ball.tx, u), lerp(ball.sy, ball.ty, u)
            ball.z = 25 * math.sin(math.pi * u)
            if u >= 1 and (not fp.throw_error_done and fp.fielders[ball.receiver].name != "P"
                           and math.hypot(ball.tx - ball.sx, ball.ty - ball.sy) > 140 and random.random() < THROW_ERROR_CHANCE):
                fp.throw_error_done = fp.error = True                           # ERROR: a wild throw gets away
                self.stats["errors"] += 1
                fp.error_fx = dict(t=0.0, x=ball.sx, y=ball.sy)
                ux, uy = unit(ball.tx - ball.sx, ball.ty - ball.sy)
                ball.mode, ball.z, ball.bt = "loose", 0.0, 0.0          # sails past him / skips off his glove
                ball.vx, ball.vy = ux * 260 + random.uniform(-90, 90), uy * 260 + random.uniform(-90, 90)
                fp.fumble = {ball.receiver: 0.6}
                fp.chaser = ball.receiver
            elif u >= 1:
                ball.mode, ball.holder, ball.hold_time, ball.z, ball.quick = "held", ball.receiver, 0.0, 0.0, True
        if ball.mode == "held":
            holder = fp.fielders[ball.holder]
            ball.x, ball.y, ball.z = holder.x, holder.y, 0
            ball.hold_time += dt

    def update_fielders(self, dt):
        fp = self.fp
        for i, f in enumerate(fp.fielders):
            chasing = i == fp.chaser and fp.ball.mode in ("flying", "loose")
            if i == fp.chaser and fp.pending and fp.pending[0] == "flyout":
                continue                                       # he made the catch: stand still with the ball
            if chasing and fp.ball.mode == "loose":
                tx, ty = fp.ball.x, fp.ball.y                  # chase the rolling ball
            elif chasing:
                if fp.hit.arc > 0:
                    if fp.time < FIELDER_REACTION:
                        continue                               # reading the fly ball
                    tx, ty = fp.hit.read_x, fp.hit.read_y      # runs to where he thinks it will land
                else:
                    tx, ty = fp.hit.land_x, fp.hit.land_y
            else:
                tx, ty = f.post
            if fp.fumble and i in fp.fumble and fp.fumble[i] > 0.45:
                continue                                       # he is stumbling after the boot / the wild throw
            if (not chasing and f.name in ("LF", "CF", "RF") and fp.ball.mode in ("flying", "loose")
                    and (fp.ball.mode == "loose" or fp.hit.arc == 0)):
                bx, by = (fp.ball.x, fp.ball.y) if fp.ball.mode == "loose" else (fp.hit.land_x, fp.hit.land_y)
                of = [g for j, g in enumerate(fp.fielders) if j != fp.chaser and g.name in ("LF", "CF", "RF")]
                if min(of, key=lambda g: math.hypot(g.x - bx, g.y - by)) is f and math.hypot(f.x - bx, f.y - by) < 420:
                    ux, uy = unit(bx - HOME[0], by - HOME[1])      # the closest outfielder charges in and backs the play up
                    tx, ty = clamp(bx + ux * BACKUP_DISTANCE * 0.6, 60, 1220), clamp(by + uy * BACKUP_DISTANCE * 0.6, 255, 700)
                    chasing_backup = True
                else:
                    chasing_backup = False
            else:
                chasing_backup = False
            speed = FIELDER_SPEED * (fp.boost if chasing else 1.0 if f.post in BASES else 0.8)
            if chasing_backup:
                speed = FIELDER_SPEED * 1.2
            if fp.dive and fp.dive["idx"] == i:
                if fp.dive["t"] < DIVE_TIME:
                    speed = FIELDER_SPEED * 2.2              # the dive carries him forward fast
                elif fp.ball.mode == "held":
                    speed = 0                                # then he stays down with the ball until he gets up
            dx, dy = tx - f.x, ty - f.y
            dist = math.hypot(dx, dy)
            if dist > 1:
                step = min(dist, speed * dt)
                f.x += dx / dist * step
                f.y += dy / dist * step

    def load_amount(self):
        """0..1: how far the batter has loaded (hands back and up) as the pitch comes in."""
        if self.state == "WIND_UP":
            return smooth((self.state_time - (WIND_UP_TIME - LOAD_TIME)) / LOAD_TIME)
        return 1.0 if self.state == "PITCH" else 0.0

    # ---- gait: sway + dust under the feet ---------------------------------------
    def gait(self, key):
        """(sway, bob) in pixels for a player, 0 if he is standing still."""
        fp = self.fp
        if key not in fp.moving:
            return 0.0, 0.0
        phase = fp.gait.get(key, 0.0)
        return math.sin(phase) * SWAY_AMOUNT, abs(math.sin(phase)) * BOB_AMOUNT

    def runner_xy(self):
        """Where the batter-runner is: on the base path, or (after an out) on his walk back to the dugout."""
        fp = self.fp
        if fp.walk:
            w = fp.walk
            k = min(1.0, DUGOUT_WALK_SPEED * w["t"] / w["dist"])
            return w["sx"] + (w["tx"] - w["sx"]) * k, w["sy"] + (w["ty"] - w["sy"]) * k
        return point_on_path(fp.runner.pos)

    def start_dugout_walk(self):
        """The batter made an out: he heads for the nearer dugout (he doesn't have to get there before the next pitch)."""
        fp = self.fp
        if fp.walk:
            return                                           # (already on his way)
        fp.runner.sliding = False                            # (no more sliding on the ground once he is out)
        fp.runner.moving = False
        sx, sy = point_on_path(fp.runner.pos)
        tx, ty = DUGOUTS["left"]                             # always the home (third-base side) dugout
        fp.walk = dict(sx=sx, sy=sy, tx=tx, ty=ty, t=0.0, dist=max(1.0, math.hypot(tx - sx, ty - sy)), done=False)

    def update_walk(self, dt):
        w = self.fp.walk
        if w and not w["done"]:
            w["t"] += dt
            if DUGOUT_WALK_SPEED * w["t"] >= w["dist"]:
                w["done"] = True                             # he has stepped into the dugout

    def shadow_at(self, x, y):
        return TERRAIN[terrain_at(x, y)]["shadow"]

    def update_gait(self, dt):
        """Work out who moved this frame: advance their step cycle and kick up dust from their feet."""
        fp = self.fp
        movers = {("f", i): (f.x, f.y, False) for i, f in enumerate(fp.fielders)}
        r = fp.runner
        movers["runner"] = self.runner_xy() + (r.sliding,)
        for n, other in enumerate(fp.others):
            if other["pos"] < 4:
                movers[("o", n)] = point_on_path(other["pos"]) + (False,)
        fp.moving = set()
        for key, (x, y, sliding) in movers.items():
            prev = fp.prev.get(key)
            fp.prev[key] = (x, y)
            if prev is None or dt <= 0:
                continue
            dx, dy = x - prev[0], y - prev[1]
            d = math.hypot(dx, dy)
            if d < 0.15:
                continue
            if not sliding:
                fp.moving.add(key)
                fp.gait[key] = fp.gait.get(key, 0.0) + d * STRIDE_PER_PIXEL
            self.emit_dust(x, y, dx / d, dy / d, d / dt, sliding, dt)

    def emit_dust(self, x, y, ux, uy, speed, sliding, dt):
        """Throw a few particles back from the feet, in the colour of the ground he is on."""
        fp = self.fp
        terrain = TERRAIN[terrain_at(x, y)]
        expected = (SLIDE_DUST_RATE if sliding else DUST_RATE) * dt * clamp(speed / FIELDER_SPEED, 0.6, 1.8)
        for _ in range(int(expected) + (1 if random.random() < expected % 1 else 0)):
            if len(fp.dust) >= MAX_DUST:
                return
            back = random.uniform(12, 42) * (1.6 if sliding else 1.0)
            fp.dust.append(dict(x=x + random.uniform(-5, 5), y=y + random.uniform(-1, 2), z=random.uniform(0, 2),
                                vx=-ux * back + random.uniform(-14, 14), vy=-uy * back * 0.6 + random.uniform(-8, 8),
                                vz=random.uniform(30, 80) if terrain["kind"] == "blades" else random.uniform(10, 36),
                                life=0.0, max=random.uniform(0.35, 0.65), size=random.uniform(2.0, 3.6),
                                color=random.choice(terrain["dust"]), kind=terrain["kind"]))

    def age_dust(self, dt):
        fp = self.fp
        for p in fp.dust:
            p["life"] += dt
            p["x"] += p["vx"] * dt
            p["y"] += p["vy"] * dt
            p["z"] = max(0.0, p["z"] + p["vz"] * dt)
            if p["kind"] == "blades":
                p["vz"] -= 260 * dt                              # flung up, then falls back
            else:
                p["vx"] *= math.exp(-3 * dt)                     # a puff of dirt hangs and drifts
                p["vy"] *= math.exp(-3 * dt)
        fp.dust = [p for p in fp.dust if p["life"] < p["max"]]

    def draw_dust(self, surf):
        for p in self.fp.dust:
            age = p["life"] / p["max"]
            if p["kind"] == "blades":
                a = (p["x"], p["y"] - p["z"])
                pygame.draw.line(surf, p["color"], a, (a[0] + (2 if p["vx"] > 0 else -2), a[1] - 3), 2)
            else:
                r = p["size"] * (0.6 + 0.9 * age) * (1 - 0.55 * age)
                pygame.draw.circle(surf, p["color"], (p["x"], p["y"] - p["z"]), max(1, r))

    def update_rare(self, dt, allow_trigger=True):
        """Timers for the rare animations (broken bat, diving stop, leaping catch) and the moment each one starts."""
        fp = self.fp
        ball, hit = fp.ball, fp.hit
        if fp.catch:
            fp.catch["t"] += dt
        if fp.landed:
            fp.landed["t"] += dt
        if fp.broken:
            fp.broken["t"] += dt
        if fp.dive:
            fp.dive["t"] += dt
            if fp.dive["t"] > DIVE_TIME + DIVE_RECOVERY:
                fp.dive = None
        elif allow_trigger and fp.dive_plan and not fp.dived and ball.mode in ("flying", "loose") and fp.time > 0.3:
            f = fp.fielders[fp.chaser]
            if math.hypot(f.x - ball.x, f.y - ball.y) < 60:       # the ball is nearly in reach: dive for it
                fp.dive, fp.dived = dict(idx=fp.chaser, t=0.0, dir=1 if ball.x >= f.x else -1), True
        if fp.leap:
            fp.leap["t"] += dt
            if fp.leap["t"] > LEAP_TIME:
                fp.leap = None
        elif allow_trigger and fp.leap_plan and not fp.leaped and ball.mode == "flying" and hit.flight - ball.t < LEAP_TIME / 2:
            fp.leap, fp.leaped = dict(t=0.0), True                # jump so the catch lands at the top of the leap

    def ball_at_base(self, base):
        """True if a fielder holding the ball is standing at this bag."""
        fp = self.fp
        if fp.ball.mode != "held":
            return False
        f = fp.fielders[fp.ball.holder]
        return math.hypot(f.x - BASES[base][0], f.y - BASES[base][1]) <= BAG_RADIUS

    def fielder_ai(self):
        """The fielder holding the ball decides what to do with it.
        He throws to the LEAD runner's base (the furthest-ahead runner who is still running), to whoever is closest to that bag
        (never to an empty bag); that fielder runs to the bag with it. If the holder is the closest, he runs it himself."""
        fp, ball = self.fp, self.fp.ball
        if ball.mode != "held" or ball.hold_time < (RELAY_TIME if ball.quick else FIELDER_PICKUP_TIME):
            return
        if fp.dive and fp.dive["idx"] == ball.holder:
            return                                           # still on the ground after the dive
        holder = fp.fielders[ball.holder]
        live = self.live_bases()
        if live:
            open_bases = [b for b in live if not self.ball_at_base(b)]
            if not open_bases:
                return                                       # a fielder is already waiting with the ball at every bag
            base = max(open_bases)                           # the lead runner's base comes first
            bag = BASES[base]
            if holder.post == bag:
                return                                       # he is already carrying it to the bag

            def closeness(i):                                # distance to the bag; outfielders count as farther (they don't cover bags)
                f = fp.fielders[i]
                weight = 1.5 if f.name in ("LF", "CF", "RF") else 0.85 if f.name == BASE_FIELDERS[base] else 1.0
                return math.hypot(f.x - bag[0], f.y - bag[1]) * weight
            nearest = min(range(len(fp.fielders)), key=closeness)
            if nearest == ball.holder:
                holder.post, holder.job = bag, "busy"        # he is the closest one: run it to the bag himself
                return
            if holder.name in ("LF", "CF", "RF") and math.hypot(holder.x - bag[0], holder.y - bag[1]) > CUTOFF_MIN_THROW:
                cutoff = fp.index["SS" if holder.x < 640 else "2B"]      # long throw: hit the cutoff man halfway
                if cutoff != nearest and cutoff != ball.holder:
                    mid = ((holder.x + bag[0]) / 2, (holder.y + bag[1]) / 2)
                    return self.throw_ball(cutoff, mid)
            self.throw_ball(nearest, bag)                    # throw to the man closest to the bag; he runs the bag
        elif holder.name != "P":                             # nobody running: get the ball back to the pitcher
            self.throw_ball(fp.index["P"], FIELDER_POSTS["P"])

    def throw_ball(self, receiver, post):
        """Throw to a fielder (not to a spot). He is sent running toward `post`, and the throw leads him: the ball
        goes to where he will be when it arrives."""
        fp = self.fp
        ball, thrower = fp.ball, fp.fielders[fp.ball.holder]
        r = fp.fielders[receiver]
        for f in fp.fielders:
            f.job = ""                                       # everybody is free to be reassigned...
        r.post, r.job = post, "busy"                         # ...except the man catching this throw
        speed = FIELDER_SPEED * (1.0 if post in BASES else 0.8)     # a fielder running to a bag runs flat out
        dx, dy = post[0] - r.x, post[1] - r.y
        run = math.hypot(dx, dy)
        tx, ty = r.x, r.y
        for _ in range(3):                                   # where will he be when the ball gets there?
            dur = max(0.15, math.hypot(tx - thrower.x, ty - thrower.y) / THROW_SPEED)
            travel = min(run, speed * dur)
            tx, ty = (r.x + dx / run * travel, r.y + dy / run * travel) if run > 0 else (r.x, r.y)
        ball.mode, ball.t, ball.dur = "thrown", 0.0, max(0.15, math.hypot(tx - thrower.x, ty - thrower.y) / THROW_SPEED)
        ball.sx, ball.sy, ball.tx, ball.ty, ball.receiver = thrower.x, thrower.y, tx, ty, receiver

    def pitcher_has_ball(self):
        fp = self.fp
        return fp.ball.mode == "held" and fp.fielders[fp.ball.holder].name == "P"

    def check_dead_ball(self, dt):
        """Pitcher has the ball and the runner is standing on a bag: the play is over."""
        fp = self.fp
        if self.pitcher_has_ball() and not self.live_bases() and fp.ball.hold_time >= FIELDER_PICKUP_TIME:
            fp.dead_time += dt
            if fp.dead_time >= DEAD_BALL_DELAY:
                self.decide_standing()
        else:
            fp.dead_time = 0.0

    # ---- runner actions (what the buttons do) ----------------------------------
    def can_continue_from(self, base):
        """Can a runner on/at `base` go on to the next one? (not home, and the next bag is free)"""
        return base < 4                                      # runners ahead of him get pushed on ahead

    def can_send(self):
        fp = self.fp
        r = fp.runner
        return (self.state == "FIELD_PLAY" and not fp.pending and not r.moving and fp.hit.kind != "FLY_OUT" and 0 <= round(r.pos) <= 3
                and r.recovery <= 0 and not self.pitcher_has_ball() and self.can_continue_from(round(r.pos)))

    def action_send(self):
        if self.can_send() and not self.fp.close:
            r = self.fp.runner
            r.target, r.forward, r.moving = round(r.pos) + 1, True, True
            r.pos, r.wait, r.run_through = float(round(r.pos)), 0.0, False
            self.push_lead_runners(int(r.pos))               # the runner on the next base goes one base ahead (and so on)
            r.turn_cooldown = TURN_COOLDOWN                  # can't be turned around instantly

    def action_slide(self):
        if not self.fp.close and self.field_button() and self.field_button()[0] == "Slide":
            self.fp.runner.sliding = True

    def action_turn(self):
        """Click the runner mid-run: he reverses direction (after a short cooldown) and so do the runners who were sent ahead
        of him. Nobody can turn back while running to first."""
        fp = self.fp
        r = fp.runner
        if fp.close or fp.pending or not r.moving or r.sliding or r.turn_cooldown > 0 or r.wait > 0:      # (a close play: no turning back)
            return
        if r.forward:
            if r.target <= max(r.earned, 1):                 # can't turn back toward home or during the guaranteed part
                return
            r.target, r.forward = r.target - 1, False
            self.send_pushed_runners(r.target, back=True)    # the runners he pushed ahead go back to where they were
        else:
            r.target, r.forward = r.target + 1, True
            self.send_pushed_runners(r.target - 1, back=False)   # ...and go again if he changes his mind
        r.run_through = False
        r.turn_cooldown = TURN_COOLDOWN

    def send_pushed_runners(self, base, back):
        """The batter-runner turned around on the way out of `base`. Only the runners HE pushed off their bags when he left
        `base` are affected: back=True sends them back to the bag they came from (whether they are still running or already
        standing on the next bag), back=False sends them on again. Runners who already scored or are out stay that way."""
        for o in self.fp.others:
            if o["out"] or o["scored"] or o["auto"] or o.get("pushed_by") != base:
                continue
            goal = o["origin"] if back else o["origin"] + 1
            if o["pos"] == goal:
                o["moving"], o["target"] = False, goal
                continue
            o["target"], o["forward"], o["moving"] = goal, o["pos"] < goal, True

    def action_return(self):
        """SPACE while running: go back to the previous base (everyone sent ahead of you goes back too)."""
        if self.fp.runner.forward:
            self.action_turn()

    def field_button(self):
        """(label, x, y) of the on-screen button right now, or None."""
        if self.state != "FIELD_PLAY" or self.fp.pending or self.fp.close:
            return None                                      # (the RUN / SLIDE buttons go away once a close play starts)
        r = self.fp.runner
        if r.moving:
            if r.forward and not r.sliding and r.wait <= 0 and r.target >= r.earned and r.target - r.pos <= SLIDE_RANGE:
                return ("Slide",) + tuple(BASES[r.target])           # SLIDE shows on the bag you are approaching
            return None
        if self.can_send():
            return ("Run",) + tuple(point_on_path(r.pos))             # RUN shows under a standing runner
        return None

    # ---- ending a play -------------------------------------------------------
    def finish_field_play(self, outcome, base):
        fp = self.fp
        runs, new_bases, extra_outs = 0, [0, 0, 0], 0
        for other in fp.others:                              # the other runners: scored, forced out, or standing on a base
            if other["moving"]:
                other["pos"], other["moving"] = float(other["target"]), False
                other["scored"] = other["scored"] or other["target"] >= 4
            if other["scored"]:
                runs += 1
            elif other["out"]:
                extra_outs += 1
            else:
                new_bases[min(3, max(1, round(other["pos"]))) - 1] = other["skin"]
        self.outs += extra_outs                              # force outs on the runners ahead of him count
        sf = outcome == "flyout" and runs > 0 and self.outs + 1 < OUTS_PER_INNING            # a run scored on the fly out: sacrifice fly
        fc = (outcome not in ("out", "flyout", "norun", "score") and fp.hit.kind == "GROUND_OUT" and extra_outs > 0)   # fielder's choice
        self.end_at_bat()
        third_out = False
        if outcome in ("out", "flyout", "norun"):
            self.outs += 1
            self.start_dugout_walk()                         # he walks back to the dugout while the result is shown
            if self.outs >= OUTS_PER_INNING:                 # third out: no runs count
                runs, new_bases, third_out = 0, [0, 0, 0], True
        elif outcome == "score":
            runs += 1
            self.stats["hits"] += 1
            self.stats["hr"] += 1
        else:
            new_bases[base - 1] = fp.skin or 1                 # the batter stays on base with his own skin tone
            if not (fp.error or fc):
                self.stats["hits"] += 1
        if self.outs >= OUTS_PER_INNING and not third_out:     # the third out came from a runner ahead of him
            runs, new_bases, third_out = 0, [0, 0, 0], True
        scored_hr = outcome == "score"
        self.credit(hit=(scored_hr or not (outcome in ("out", "flyout", "norun") or fp.error or fc)), hr=scored_hr, ab=not sf)
        if sf:
            self.stats["sf"] += 1
        if extra_outs and outcome in ("out", "flyout"):
            self.stats["dp"] += 1
        good = scored_hr or not (outcome in ("out", "flyout", "norun") or fp.error or fc)
        self.spray.append((fp.hit.land_x, fp.hit.land_y, "hit" if good else "out"))
        self.hot_check(good)
        self.runs += runs
        self.bases = new_bases
        if outcome in ("out", "flyout", "norun"):
            self.cheer_cpu(0.8)                                            # the CPU's dugout celebrates your out
        else:
            self.cheer(0.6 + 0.2 * base + 0.35 * min(runs, 3))
        score_text = f"{runs} run{'s' if runs > 1 else ''} scored" if runs else ""
        if outcome == "flyout":
            big = "FLY OUT"
        elif outcome == "norun":
            big = "OUT"
        elif outcome == "out":
            big = f"OUT at {BASE_NAMES[base - 1].upper()}"
        elif outcome == "score":
            big = "INSIDE-THE-PARK HR!"
        else:
            big = {1: "SINGLE", 2: "DOUBLE", 3: "TRIPLE"}[base]
            if base == 1 and fp.hit.kind == "GROUND_OUT":
                big = "INFIELD SINGLE"
        if sf:
            big = "SAC FLY"
        if fp.error and outcome not in ("out", "flyout", "norun"):
            big = "REACHED ON ERROR" if not fc else "ERROR ON THE PLAY"
        elif fc:
            big = "FIELDER'S CHOICE"
        if extra_outs and outcome in ("out", "flyout"):
            big = "DOUBLE PLAY!" if extra_outs == 1 else "TRIPLE PLAY!"
        elif extra_outs and not fc:
            big += "  |  RUNNER OUT"
        small = "Side retired" if third_out else score_text or ("Never ran to first" if outcome == "norun" else "")
        self.show_message(big, small, then=self.end_inning if third_out else None, wait=True)

    def end_at_bat(self):
        self.balls = self.strikes = 0
        self.new_batter = True

    def record_out(self, text, note=""):
        self.outs += 1
        if text.startswith("STRIKEOUT"):
            self.stats["k"] += 1
            self.credit()
        self.end_at_bat()
        self.cheer_cpu(0.8)                                                # the CPU's dugout celebrates your out
        third_out = self.outs >= OUTS_PER_INNING
        self.show_message(text, "Side retired" if third_out else note, then=self.end_inning if third_out else None)

    def walk(self, note=""):
        first, second, third = self.bases
        if first and second and third: self.runs += 1
        if first and second: third = second                  # runners keep their skin tones as they move up
        if first: second = first
        self.bases = [self.skin, second, third]
        self.stats["bb"] += 1
        self.end_at_bat()
        self.show_message("WALK", "Take your base" + (f"  |  {note}" if note else ""))

    def finish_slugger(self):
        self.fade = FADE_TIME
        self.home_run()

    def home_run(self):
        if self.hit and self.hit.robbed:                     # rare: an outfielder steals it at the wall
            self.stats["robbed"] += 1
            self.credit()
            self.streak = 0
            self.spray.append(spray_hr_xy(self.hit.sideways, ROB_MAX_FT - 20) + ("out",))
            self.cheer_cpu(0.9)
            self.record_out("ROBBED!", "Leaps and steals a home run at the wall!")
            return
        if self.hit:
            self.credit(hit=True, hr=True)
            self.spray.append(spray_hr_xy(self.hit.sideways, self.hr_distance) + ("hr",))
            if self.hr_distance >= FLIP_MIN_FT:
                self.stats["long_hr"] = max(self.stats["long_hr"], self.hr_distance)
        runs = 1 + sum(1 for b in self.bases if b)
        self.runs += runs
        self.bases = [0, 0, 0]
        self.stats["hits"] += 1
        self.stats["hr"] += 1
        self.stats["long_hr"] = max(self.stats["long_hr"], self.hr_distance)
        self.end_at_bat()
        small = f"{runs} runs score" if runs > 1 else "Gone!"
        if self.fan:
            small += "  A fan makes the catch!"
        if self.board_hit:
            small += "  Off the scoreboard!"
            self.board_time = 0.0                            # start the rock-and-flicker animation
        big = f"HOME RUN!  {self.hr_distance} FT" if self.hr_distance else "HOME RUN!"
        self.cheer(1.3)                                                    # the whole place erupts
        self.show_message(big, small, HOME_RUN_MESSAGE_TIME, wait=True)
        self.celebrating, self.fireworks_launched = True, 0
        self.add_fireworks(385, 70)

    def cpu_cap(self):
        """The most the CPU can score: 15, or 80% of your runs once you have more than 15."""
        return CPU_MAX_TOTAL if self.runs <= CPU_MAX_TOTAL else int(self.runs * CPU_RATIO_ABOVE_MAX)

    def cpu_half_inning(self):
        """The CPU's turn at bat. Its final total is a random 0 to cap (cap = 15, or 80% of your score above 15).
        The roll is made once per game and its runs arrive a bit at a time, so the line score looks natural."""
        target = round(self.cpu_roll * self.cpu_cap())
        if self.inning >= self.innings:                      # last inning (or extra innings): reach the total
            new_total = target
        else:                                                # earlier innings: on pace, with some wobble
            pace = target * self.inning / self.innings
            new_total = round(pace + random.uniform(-1.5, 1.5))
        new_total = clamp(new_total, self.cpu_runs, max(target, self.cpu_runs))
        added = new_total - self.cpu_runs
        self.cpu_runs = new_total
        return added

    def end_inning(self):
        self.steal_armed = False
        self.my_line.append(self.runs - self.inning_start_runs)
        cpu_scored = self.cpu_half_inning()
        self.cpu_line.append(cpu_scored)
        if cpu_scored:
            self.cheer_cpu(0.9)                                            # the CPU scored: its dugout is up
        self.inning_start_runs = self.runs
        if self.inning >= self.innings and self.runs != self.cpu_runs:     # tied after the last inning = extra innings
            record_game(self)
            self.set_state("GAME_OVER")
            return
        stretch = self.inning == STRETCH_INNING and self.innings > STRETCH_INNING
        self.inning += 1
        self.outs = 0
        self.bases = [0, 0, 0]
        if stretch:
            self.cheer(1.0)
            self.cheer_cpu(0.6)
            self.show_message("SEVENTH-INNING STRETCH", "Everybody up!", 2.6)
        else:
            self.set_state("WAIT")

    # ---- home run celebration ------------------------------------------------
    def add_fireworks(self, x, y):
        colors = [GOLD, RED, GREEN, (110, 198, 255), WHITE]
        for i in range(30):
            angle, speed = random.random() * 6.28, 60 + random.random() * 140
            self.confetti.append(dict(x=x, y=y, vx=math.cos(angle) * speed, vy=math.sin(angle) * speed - 40,
                                      size=3 + random.random() * 3, life=1.4 + random.random(), color=colors[i % 5]))

    def update_celebration(self, dt):
        for p in self.confetti:
            p["x"] += p["vx"] * dt
            p["y"] += p["vy"] * dt
            p["vy"] += 260 * dt
            p["life"] -= dt
        self.confetti = [p for p in self.confetti if p["life"] > 0]
        if self.celebrating:
            if self.fireworks_launched < 6 and self.state_time > self.fireworks_launched * 0.4:
                self.add_fireworks(150 + random.random() * 470, 50 + random.random() * 80)
                self.fireworks_launched += 1
            if random.random() < 0.5:
                self.confetti.append(dict(x=random.random() * BAT_W, y=-5, vx=0, vy=60, size=4, life=3,
                                          color=random.choice([GOLD, RED, GREEN, (110, 198, 255)])))

    # ---- per-frame update ----------------------------------------------------
    def update(self, dt):
        if self.paused:                                      # the game freezes; only the gallery animations keep running
            self.anim_clock += dt
            return
        self.clock += dt
        self.crowd_energy = max(0.0, self.crowd_energy - CROWD_DECAY * dt)
        self.cpu_cheer = max(0.0, self.cpu_cheer - CROWD_DECAY * dt)
        self.state_time += dt
        self.fade = max(0.0, self.fade - dt)
        self.settle = min(1.0, self.settle + dt / SETTLE_TIME)
        self.shake = max(0.0, self.shake - dt)
        self.fire_flash = max(0.0, self.fire_flash - dt)
        if self.fp and self.fp.fumble:
            self.fp.fumble = {i: t - dt for i, t in self.fp.fumble.items() if t - dt > 0}
        if self.fp and self.fp.error_fx:
            self.fp.error_fx["t"] += dt
        if self.board_time >= 0:                             # scoreboard rock-and-flicker clock
            self.board_time += dt
            if self.board_time > BOARD_ANIM_TIME:
                self.board_time = -1.0
        if self.swing_clock >= 0:
            self.swing_clock += dt
        self.update_celebration(dt)

        if self.state == "WAIT" and self.state_time > PAUSE_BEFORE_PITCH:
            self.start_pitch()
        elif self.state == "WIND_UP" and self.state_time > WIND_UP_TIME:
            self.set_state("PITCH")
        elif self.state == "PITCH":
            self.pitch.time += dt
            if self.pitch.time >= self.pitch.duration + METER_EXTRA_TIME:
                self.finish_pitch_without_contact()
        elif self.state == "HR_CUTSCENE":
            if self.state_time >= SLUGGER_TIME:
                self.finish_slugger()
        elif self.state == "BALL_IN_FLIGHT":
            self.hit.time += dt
            if self.hit.time >= self.hit.flight:
                self.home_run()
        elif self.state == "FIELD_PLAY":
            self.update_field_play(dt * self.close_slowmo(dt))
        elif self.state == "MESSAGE" and self.state_time > self.message_duration and not self.wait_click:
            self.continue_after_message()
        if self.state == "MESSAGE" and self.fp and self.view == "field":
            self.update_rare(dt, allow_trigger=False)        # let a dive / leap / bat finish while the result is shown
            self.close_slowmo(dt)                            # (and the umpire's call stays up a moment)
            self.update_walk(dt)                             # an out: the batter strolls toward the dugout
            self.update_gait(dt)                             # (his step cycle + a little dust under his feet)
            self.age_dust(dt)

    # ---- per-frame drawing ---------------------------------------------------
    def draw(self, canvas):
        if self.state == "HR_CUTSCENE":
            self.draw_slugger_cutscene(canvas)
        elif self.fp and self.close_cutscene_active():
            gap, dist = self.close_vals()
            c = self.fp.close
            draw_close_cutscene(canvas, gap, dist, c["result"], c["tres"], c["t"], c["skin"], self.team_color, self.draw_cutscene_weather)
        elif self.view == "bat":
            self.draw_bat_view(self.bat_surface)
            bat_h = int(LOGICAL_W * BAT_H / BAT_W)
            canvas.fill((14, 17, 22))
            canvas.blit(pygame.transform.smoothscale(self.bat_surface, (LOGICAL_W, bat_h)), (0, (LOGICAL_H - bat_h) // 2))
        else:
            self.draw_field_view(canvas)
        if self.state == "MESSAGE" and self.wait_click and self.state_time >= NEXT_PITCH_DELAY:
            draw_next_pitch_button(canvas, self.state_time)
        if self.state == "GAME_OVER":
            self.draw_game_over(canvas)
        if self.fade > 0:                                    # fade in after a view change
            shade = pygame.Surface((LOGICAL_W, LOGICAL_H))
            shade.set_alpha(int(255 * self.fade / FADE_TIME))
            canvas.blit(shade, (0, 0))
        if self.shake > 0 and not self.paused and self.state != "HR_CUTSCENE":      # screen shake on PERFECT hits
            amp = self.shake_mag * self.shake / SHAKE_TIME
            snapshot = canvas.copy()
            canvas.blit(snapshot, (random.uniform(-amp, amp), random.uniform(-amp, amp)))
        if self.paused:
            self.draw_pause(canvas)

    # ---- PERFECT PERFECT home run cutscene -------------------------------------
    def draw_slugger_cutscene(self, surf):
        self.draw_slugger_scene(surf, self.state_time)

    def draw_slugger_scene(self, surf, t_real):
        """The cutscene at time t_real (also used by the Animations gallery).
        At the moment of contact there is a short HIT-STOP: the picture freezes on the connecting swing while the
        explosion and flash play over it. Then the ball takes off, the camera waits so you can see him HOLD his
        follow-through, and only then does it whip over to chase the ball."""
        hit = SLUGGER_HIT_TIME
        contacted = t_real >= hit
        fx = max(0.0, t_real - hit)                                   # real seconds since contact (effects keep playing in the hit-stop)
        t = t_real if t_real < hit else hit if t_real < hit + SLUGGER_HITSTOP else t_real - SLUGGER_HITSTOP
        s = max(0.0, t - hit)                                         # game seconds since contact (frozen during the hit-stop)
        dist_k = clamp((self.hr_distance - 400) / 150, 0, 1) if self.hr_distance else 0.5
        ball_x, ball_y = slugger_ball_world(t, dist_k)
        if s <= 0:
            cam_x = cam_y = 0.0
        else:                                                          # the camera drifts after the ball a little, then chases it
            w = max(smooth((s - 0.45) / 0.7), 0.45 * smooth(s / 0.3))
            cam_x = (ball_x - lerp(CONTACT_POINT[0], 800, smooth((s - 0.8) / 0.6))) * w
            cam_y = (ball_y - lerp(CONTACT_POINT[1], 300, smooth(s / 0.5))) * 0.55 * w
        if 0 <= fx < 0.4:                                              # screen shake on impact
            shake = 20 * (1 - fx / 0.4)
            cam_x += random.uniform(-shake, shake)
            cam_y += random.uniform(-shake, shake)

        art = self.slugger
        surf.blit(art["sky"], (0, 0))

        def scroll(image, speed, y):                           # repeating layer that scrolls at its own speed (parallax)
            x0 = -((cam_x * speed) % LOGICAL_W)
            surf.blit(image, (int(x0), int(y)))
            surf.blit(image, (int(x0 + LOGICAL_W), int(y)))

        stands_y = 340 - cam_y * 0.6
        scroll(art["skyline"], 0.35, stands_y - 200)           # skyline sits right behind the stands (same height, slower scroll)
        scroll(art["stands"], 0.5, stands_y)
        ground_y = BATTER_FEET[1] - cam_y
        pygame.draw.rect(surf, (34, 84, 48), (0, stands_y + 260, LOGICAL_W, max(0, ground_y - stands_y - 260)))
        scroll(art["grass"], 1.0, ground_y)
        pygame.draw.rect(surf, (44, 108, 44), (0, ground_y + 240, LOGICAL_W, LOGICAL_H))

        draw_side_batter(surf, (cam_x, cam_y), t, self.team_color, self.skin)
        if not contacted:                                      # the slow-motion pitch
            pygame.draw.circle(surf, WHITE, (ball_x - cam_x, ball_y - cam_y), 14)
            pygame.draw.circle(surf, (204, 51, 51), (ball_x - cam_x, ball_y - cam_y), 14, 2)
        else:
            if s > 0.1:                                        # speed lines
                for i in range(14):
                    y = (i * 97 + 41) % 640 + 40
                    x = ((i * 211 - cam_x * 1.7) % (LOGICAL_W + 400)) - 200
                    pygame.draw.line(surf, (235, 240, 255), (x, y), (x + 140 + (i % 3) * 60, y), 2)
            draw_explosion(surf, CONTACT_POINT[0] - cam_x, CONTACT_POINT[1] - cam_y, fx)
            for k in range(12, 0, -1):                         # fiery trail = where the ball was a moment ago
                px, py = slugger_ball_world(max(SLUGGER_HIT_TIME, t - k * 0.03), dist_k)
                pygame.draw.circle(surf, (255, 90 + k * 12, 30), (px - cam_x, py - cam_y), max(2, int(18 - k * 1.1)))
            radius = int(lerp(20, 7, clamp(s / 2.2, 0, 1)))    # the ball shrinks as it leaves the park
            pygame.draw.circle(surf, WHITE, (ball_x - cam_x, ball_y - cam_y), radius)
            if fx < 0.18:                                      # white flash on contact (holds through the hit-stop, then fades)
                flash = pygame.Surface((LOGICAL_W, LOGICAL_H))
                flash.fill(WHITE)
                flash.set_alpha(int(230 * (1 - fx / 0.18)))
                surf.blit(flash, (0, 0))
            if s < 1.4:
                draw_text(surf, "PERFECT PERFECT!", 640, 170, int(78 + 8 * math.sin(fx * 14)), GOLD)
            else:
                draw_text(surf, f"HOME RUN!  {self.hr_distance} FT" if self.hr_distance else "HOME RUN!", 640, 170, 84, WHITE)
        self.draw_cutscene_weather(surf)
        pygame.draw.rect(surf, BLACK, (0, 0, LOGICAL_W, 48))                  # cinematic bars
        pygame.draw.rect(surf, BLACK, (0, LOGICAL_H - 48, LOGICAL_W, 48))

    # ---- pause menu + animation gallery ----------------------------------------
    PAUSE_OPTIONS = ("Resume", "Roster", "Difficulty", "Animations", "Restart Game", "Quit to Title")
    BACK_RECT = pygame.Rect(60, 650, 200, 46)
    PREVIEW_RECT = pygame.Rect(480, 130, 740, 416)           # 16:9 window the gallery plays animations in

    def pause_rects(self):
        return [pygame.Rect(450, 250 + i * 62, 380, 52) for i in range(len(self.PAUSE_OPTIONS))]

    PREV_RECT, NEXT_RECT = pygame.Rect(290, 650, 70, 46), pygame.Rect(370, 650, 70, 46)

    def gallery_page(self):
        return self.anim_index // ANIM_PAGE

    def gallery_pages(self):
        return (len(ANIMATIONS) + ANIM_PAGE - 1) // ANIM_PAGE

    def gallery_rects(self):
        """The buttons on the current page (ANIM_PAGE animations per page)."""
        count = min(ANIM_PAGE, len(ANIMATIONS) - self.gallery_page() * ANIM_PAGE)
        return [pygame.Rect(60, 140 + i * 76, 380, 68) for i in range(count)]

    def gallery_flip(self, step):
        page = (self.gallery_page() + step) % self.gallery_pages()
        self.anim_index, self.anim_clock = page * ANIM_PAGE, 0.0

    def toggle_pause(self):
        self.paused = not self.paused
        self.pause_screen, self.pause_index, self.anim_clock = "main", 0, 0.0

    def pause_choose(self, index):
        option = self.PAUSE_OPTIONS[index]
        if option == "Resume":
            self.paused = False
        elif option == "Difficulty":                         # cycle Easy -> Medium -> Hard, takes effect on the next pitch
            names = list(DIFFICULTIES)
            self.set_difficulty(names[(names.index(self.difficulty) + 1) % len(names)])
        elif option == "Animations":
            self.pause_screen, self.anim_clock = "anims", 0.0
        elif option == "Roster":
            self.pause_screen = "roster"
        elif option == "Restart Game":
            self.configure(self.team_name, self.team_color, self.difficulty, self.innings, self.home_logo)     # a fresh game (also unpauses)
        else:
            self.paused, self.quit_to_menu = False, True

    def pause_key(self, key):
        if key == pygame.K_p:
            return self.toggle_pause()
        if self.pause_screen == "roster":
            if key in (pygame.K_BACKSPACE, pygame.K_LEFT, pygame.K_RETURN, pygame.K_SPACE):
                self.pause_screen = "main"
        elif self.pause_screen == "main":
            if key == pygame.K_UP:
                self.pause_index = (self.pause_index - 1) % len(self.PAUSE_OPTIONS)
            elif key == pygame.K_DOWN:
                self.pause_index = (self.pause_index + 1) % len(self.PAUSE_OPTIONS)
            elif key in (pygame.K_RETURN, pygame.K_SPACE):
                self.pause_choose(self.pause_index)
        else:
            if key == pygame.K_UP:
                self.anim_index, self.anim_clock = (self.anim_index - 1) % len(ANIMATIONS), 0.0
            elif key == pygame.K_DOWN:
                self.anim_index, self.anim_clock = (self.anim_index + 1) % len(ANIMATIONS), 0.0
            elif key in (pygame.K_RETURN, pygame.K_SPACE):
                self.anim_clock = 0.0                        # replay
            elif key == pygame.K_LEFT:
                self.gallery_flip(-1)
            elif key == pygame.K_RIGHT:
                self.gallery_flip(1)
            elif key == pygame.K_BACKSPACE:
                self.pause_screen = "main"

    def pause_hover(self, pos):
        self.mouse = pos
        if self.pause_screen == "main":
            for i, rect in enumerate(self.pause_rects()):
                if rect.collidepoint(pos):
                    self.pause_index = i

    def pause_click(self, pos):
        self.mouse = pos
        if self.pause_screen == "main":
            for i, rect in enumerate(self.pause_rects()):
                if rect.collidepoint(pos):
                    self.pause_index = i
                    self.pause_choose(i)
                    return
        elif self.pause_screen == "roster":
            if self.BACK_RECT.collidepoint(pos):
                self.pause_screen = "main"
        else:
            if self.BACK_RECT.collidepoint(pos):
                self.pause_screen = "main"
            elif self.PREV_RECT.collidepoint(pos):
                self.gallery_flip(-1)
            elif self.NEXT_RECT.collidepoint(pos):
                self.gallery_flip(1)
            elif self.PREVIEW_RECT.collidepoint(pos):
                self.anim_clock = 0.0
            for i, rect in enumerate(self.gallery_rects()):
                if rect.collidepoint(pos):
                    self.anim_index, self.anim_clock = self.gallery_page() * ANIM_PAGE + i, 0.0

    def draw_roster(self, surf):
        """Every player in the batting order with today's line (H-AB, AVG, HR) and his three ratings, plus team totals."""
        surf.fill((12, 16, 36))
        draw_text(surf, f"{self.team_name} ROSTER", 640, 78, 44, GOLD)
        cols = dict(num=118, name=172, ab=500, h=570, avg=665, hr=765, pwr=840, con=960, spd=1080)
        for key, label in (("num", "#"), ("name", "PLAYER"), ("ab", "AB"), ("h", "H"), ("avg", "AVG"), ("hr", "HR"),
                           ("pwr", "POWER"), ("con", "CONTACT"), ("spd", "SPEED")):
            draw_text(surf, label, cols[key], 132, 14, (200, 205, 225), outline=False, align="left")
        tot_ab = tot_h = tot_hr = 0
        for i, b in enumerate(self.lineup):
            rect = pygame.Rect(100, 144 + i * 46, 1080, 40)
            up = i == self.batter_i
            pygame.draw.rect(surf, (52, 62, 112) if up else (30, 38, 74) if i % 2 else (24, 30, 62), rect, border_radius=8)
            if up:
                pygame.draw.rect(surf, GOLD, rect, 2, border_radius=8)
            base = rect.centery + 7
            avg = "---" if not b["ab"] else "1.000" if b["h"] >= b["ab"] else f".{int(1000 * b['h'] / b['ab']):03d}"
            pygame.draw.circle(surf, b["skin"], (rect.x + 8, rect.centery), 6)
            draw_text(surf, f"{b['num']}", cols["num"], base, 17, GOLD if up else WHITE, align="left")
            draw_text(surf, b["name"].upper(), cols["name"], base, 18, WHITE, align="left")
            for key, value in (("ab", b["ab"]), ("h", b["h"]), ("avg", avg), ("hr", b["hr"])):
                draw_text(surf, str(value), cols[key], base, 18, WHITE, align="left")
            for key, value in (("pwr", b["power"]), ("con", b["contact"]), ("spd", b["speed"])):
                for k in range(5):
                    pygame.draw.rect(surf, GOLD if k < pips(value) else (70, 76, 98), (cols[key] + k * 14, rect.centery - 6, 10, 12), border_radius=2)
            if up:
                draw_text(surf, "AT BAT", rect.x - 8, base - 1, 14, GOLD, align="right")        # outside the box, on its left
            tot_ab += b["ab"]
            tot_h += b["h"]
            tot_hr += b["hr"]
        st = self.stats
        avg = "---" if not tot_ab else "1.000" if tot_h >= tot_ab else f".{int(1000 * tot_h / tot_ab):03d}"
        long_hr = f"   |   LONGEST HR {st['long_hr']} FT" if st["long_hr"] else ""
        draw_text(surf, f"TEAM   R {self.runs}   |   H-AB {tot_h}-{tot_ab}   AVG {avg}   |   HR {tot_hr}   |   BB {st['bb']}   K {st['k']}"
                        f"   |   SB {st['steals']}/{st['steal_att']}{long_hr}", 640, 590, 16, GOLD)
        self.draw_pause_button(surf, self.BACK_RECT, "BACK", False)
        draw_text(surf, "ENTER / BACKSPACE: back   P: resume", 640, 690, 13, (200, 205, 225))

    def draw_pause_button(self, surf, rect, label, selected):
        pygame.draw.rect(surf, TEAL if selected else (34, 42, 80), rect, border_radius=12)
        pygame.draw.rect(surf, WHITE if selected else (110, 120, 160), rect, 2, border_radius=12)
        draw_text(surf, label, rect.centerx, rect.centery + 8, 22)

    def draw_pause(self, surf):
        if self.pause_screen == "anims":
            return self.draw_gallery(surf)
        if self.pause_screen == "roster":
            return self.draw_roster(surf)
        shade = pygame.Surface((LOGICAL_W, LOGICAL_H), pygame.SRCALPHA)
        shade.fill((0, 0, 0, 170))
        surf.blit(shade, (0, 0))
        draw_text(surf, "PAUSED", 640, 205, 64, GOLD)
        for i, (rect, option) in enumerate(zip(self.pause_rects(), self.PAUSE_OPTIONS)):
            label = f"DIFFICULTY: {self.difficulty.upper()}" if option == "Difficulty" else option.upper()
            self.draw_pause_button(surf, rect, label, i == self.pause_index)
        draw_text(surf, "P: resume   |   UP/DOWN + ENTER: choose   |   ESC: quit the game", 640, 640, 14, (200, 205, 225))
        draw_text(surf, "Difficulty changes take effect on the next pitch", 640, 665, 13, (200, 205, 225))

    def draw_gallery(self, surf):
        """Every animation, on demand: pick one on the left and it loops in the window on the right."""
        surf.fill((12, 16, 36))
        draw_text(surf, "ANIMATIONS", 640, 92, 46, GOLD)
        first = self.gallery_page() * ANIM_PAGE
        for i, (rect, (name, _, _)) in enumerate(zip(self.gallery_rects(), ANIMATIONS[first:]), start=first):
            selected = i == self.anim_index
            pygame.draw.rect(surf, TEAL if selected else (34, 42, 80), rect, border_radius=10)
            pygame.draw.rect(surf, WHITE if selected else (110, 120, 160), rect, 2, border_radius=10)
            size = 20 if rect.height >= 56 else 17
            draw_text(surf, f"{i + 1}. {name}", rect.x + 18, rect.centery + size * 0.4, size, align="left")
        name, info, duration = ANIMATIONS[self.anim_index]
        t = min(self.anim_clock % (duration + 0.8), duration)             # plays, pauses a moment, loops
        scene = self.preview_scene
        (self.scene_slugger, self.scene_dive, self.scene_leap, self.scene_broken_bat,
         self.scene_fan, self.scene_board, self.scene_robbed, self.scene_flip, self.scene_fire,
         lambda sc, tt: self.scene_close(sc, tt, "safe"), lambda sc, tt: self.scene_close(sc, tt, "out"))[self.anim_index](scene, t)
        surf.blit(pygame.transform.smoothscale(scene, self.PREVIEW_RECT.size), self.PREVIEW_RECT.topleft)
        pygame.draw.rect(surf, WHITE, self.PREVIEW_RECT.inflate(8, 8), 3)
        cx = self.PREVIEW_RECT.centerx
        draw_text(surf, name, cx, 590, 26, GOLD)
        draw_text(surf, info, cx, 620, 16)
        self.draw_pause_button(surf, self.BACK_RECT, "BACK", False)
        self.draw_pause_button(surf, self.PREV_RECT, "<", False)
        self.draw_pause_button(surf, self.NEXT_RECT, ">", False)
        draw_text(surf, f"PAGE {self.gallery_page() + 1}/{self.gallery_pages()}", 365, 636, 20, WHITE)
        draw_text(surf, "UP/DOWN: choose   LEFT/RIGHT: page   ENTER or click window: replay   BACKSPACE: back   P: resume", cx, 690, 13, (200, 205, 225))

    # ---- the gallery scenes: each one re-creates a rare animation at time t ------
    def scene_slugger(self, scene, t):
        self.draw_slugger_scene(scene, clamp(t, 0, SLUGGER_TIME))

    def scene_dive(self, scene, t):
        WET[0] = self.weather == "Rain"
        """A ground ball up the middle: the shortstop dives, then throws to first."""
        self.blit_field_scene(scene, t * 1.0, 0.55)
        s = FIELDER_SCALE
        for name, post in FIELDER_POSTS.items():
            if name != "SS":
                draw_person(scene, post[0], post[1], s)
        end, direction = (447, 437), -1
        k = clamp((t - 0.3) / 0.65, 0, 1)
        k = k * k * (3 - 2 * k)
        fx, fy = lerp(540, end[0], k), lerp(395, end[1], k)
        dive_t = t - 0.55
        rx, ry = point_on_path(clamp((t - 0.9) * 0.7, 0, 1))
        draw_person(scene, rx, ry, 1.6, (240, 240, 240), self.team_color, skin=self.skin)
        lying = 0 <= dive_t < DIVE_TIME + DIVE_RECOVERY * 0.6
        if lying:
            draw_dive(scene, fx, fy, s, FIELD_BODY, FIELD_CAP, dive_t, direction)
        else:
            draw_person(scene, fx, fy, s)
        glove = dive_glove(end[0], end[1], s, direction)
        held = (fx + 8, fy - 18)
        if t < 1.1:                                                       # the grounder bounces into the glove
            u = t / 1.1
            draw_loose_ball(scene, lerp(HOME[0], glove[0], u), lerp(HOME[1] - 14, glove[1], u) - abs(math.sin(u * math.pi * 5)) * 12 * (1 - u))
        elif t < 1.9:
            draw_loose_ball(scene, *(dive_glove(fx, fy, s, direction) if lying else held))
        elif t < 2.4:                                                     # the throw to first
            u = (t - 1.9) / 0.5
            draw_loose_ball(scene, lerp(held[0], 913, u), lerp(held[1], 434, u) - 25 * math.sin(math.pi * u))
        else:
            draw_loose_ball(scene, 913, 434)
        if 0 <= dive_t < DIVE_TIME + DIVE_RECOVERY:
            draw_text(scene, "DIVING STOP!", fx, fy - 70, 28, GOLD)
        if t >= 2.45:
            draw_text(scene, "OUT at FIRST", 640, 140, 56)

    def scene_close(self, scene, t, result):
        """The close-play cutscene, re-created for the gallery: the runner dives, the ball comes in, the call is made."""
        WET[0] = self.weather == "Rain"
        arrive = 2.0
        gap = 0.5 * (1 - smooth(clamp(t / arrive, 0, 1)))
        ball_arrives = arrive - 0.15 if result == "out" else arrive + 0.2
        dist = CLOSE_BALL_RADIUS * 1.2 * (1 - smooth(clamp(t / ball_arrives, 0, 1)))
        done = t >= arrive
        draw_close_cutscene(scene, gap, dist, result if done else None, max(0.0, t - arrive), t, self.skin, self.team_color, self.draw_cutscene_weather)

    def scene_leap(self, scene, t):
        """A deep fly ball to center: the fielder leaps and makes the catch at the top of his jump."""
        self.blit_field_scene(scene, t * 1.0, 0.55)
        s = FIELDER_SCALE
        for name, post in FIELDER_POSTS.items():
            if name != "CF":
                draw_person(scene, post[0], post[1], s)
        draw_person(scene, HOME[0], HOME[1], 1.6, (240, 240, 240), self.team_color, skin=self.skin)
        flight, land = 1.8, (640, 250)
        k = clamp(t / 1.2, 0, 1)
        k = k * k * (3 - 2 * k)
        fx, fy = lerp(590, land[0], k), lerp(300, land[1], k)
        leap_t = t - (flight - LEAP_TIME / 2)
        jumping = 0 <= leap_t < LEAP_TIME
        if jumping:
            draw_leap(scene, fx, fy, s, FIELD_BODY, FIELD_CAP, leap_t)
            draw_text(scene, "LEAPING CATCH!", fx, fy - 105, 28, GOLD)
        else:
            draw_person(scene, fx, fy, s)
        if t < flight:
            u = t / flight
            z = 170 * math.sin(math.pi * u) + LEAP_GLOVE_Z * u ** 3
            draw_loose_ball(scene, lerp(HOME[0], land[0], u), lerp(HOME[1] - 10, land[1], u) - z - 4)
        elif jumping:
            draw_loose_ball(scene, *leap_glove(fx, fy, s, leap_t))
        else:
            draw_loose_ball(scene, fx + 8, fy - 18)
        if t >= flight + 0.6:
            draw_text(scene, "FLY OUT", 640, 140, 56)

    def scene_broken_bat(self, scene, t):
        """Weak contact: the bat snaps and the barrel spins away toward third."""
        self.blit_field_scene(scene, t * 1.0, 0.55)
        for name, post in FIELDER_POSTS.items():
            draw_person(scene, post[0], post[1], FIELDER_SCALE)
        contact = 0.5
        bt = t - contact
        draw_person(scene, HOME[0], HOME[1], 1.6, (240, 240, 240), self.team_color, skin=self.skin)
        if bt < 0:                                                        # the swing and the pitch coming in
            angle = lerp(-1.9, 0.4, clamp(t / contact, 0, 1))
            hx, hy = HOME[0] + 6, HOME[1] - 22
            draw_real_bat(scene, (hx, hy), (hx + 60 * math.cos(angle), hy + 60 * math.sin(angle)), 7)
            draw_loose_ball(scene, lerp(MOUND[0], HOME[0], t / contact), lerp(MOUND[1], HOME[1] - 20, t / contact))
        else:
            draw_bat_stub(scene, HOME[0], HOME[1])
            direction = unit(B3[0] - HOME[0], B3[1] - HOME[1])
            draw_broken_bat(scene, HOME[0], HOME[1], bt, direction)
            u = clamp(bt / 1.0, 0, 1)                                     # the weak grounder dribbles out
            draw_loose_ball(scene, lerp(HOME[0], 470, u), lerp(HOME[1] - 14, 520, u) - abs(math.sin(u * math.pi * 4)) * 10 * (1 - u))
            if bt < 1.3:
                draw_text(scene, "BROKEN BAT!", 640, 112, 40, GOLD)

    def scene_homer(self, scene, t, kind):
        """A home run in the batting view, re-created for the gallery. kind:
        "fan"   - it clears the wall and a small fan catches it
        "board" - it smacks the scoreboard, which rocks and flickers
        "rob"   - a short one: the center fielder leaps at the wall and steals it
        "flip"  - a moonshot: the batter flips his bat
        "fire"  - the batter is ON FIRE: flames in the box, then he crushes one"""
        bat = self.preview_bat
        self.blit_bat_scene(bat, t, 0.4)
        contact = 1.2 if kind == "fire" else 0.45                         # (the fire scene lets you look at the flames first)
        flight = 1.6
        sideways = {"board": -5, "fan": 150, "rob": -190, "flip": 90, "fire": -120}[kind]
        distance = {"rob": 380, "flip": 480}.get(kind, 420)
        bt = t - (contact + flight)                                       # seconds since the ball reached the wall
        saved = self.board_time
        self.board_time = bt if kind == "board" and bt >= 0 else -1.0
        draw_bat_scoreboard(bat, self)
        self.board_time = saved
        rob_rx = clamp(BAT_RELEASE_POINT[0] + 8 + sideways, 90, 680)
        draw_bat_fielders(bat, rob_fielder(rob_rx) if kind == "rob" and t >= contact else None)
        pitch = Pitch("Fastball", contact if kind != "fire" else 0.45, 95, True)
        swing = t - (contact - 0.12)
        hit = Hit("HR", "perfect", BAT_RELEASE_POINT[0] + 8, 332, sideways, flight, 0, distance=distance)
        hit.robbed = kind == "rob"
        hit.time = clamp(t - contact, 0, flight)
        u = hit.time / flight
        if kind == "fan":
            draw_fan(bat, hit.start_x + hit.sideways, hr_end_y(hit.distance), clamp((u - 0.7) / 0.3, 0, 1), t, u >= 1)
            draw_bat_wall(bat)                                            # the wall is in front of him: he is in the stands
        if t < contact:                                                   # the pitch on its way in
            pitch_t = t - (contact - 0.45)
            if pitch_t >= 0:
                x, y, r = pitch_position(pitch, pitch_t / 0.45)
                draw_bat_ball(bat, x, y, r)
        elif u < 1:
            x, y, r = hr_position(hit)
            draw_bat_ball(bat, x, y, r)
        if kind == "fire" and t < contact + 0.2:
            draw_fire_aura(bat, t)
        flipped = kind == "flip" and swing >= FLIP_START
        load = smooth(clamp((t - (contact - 0.7)) / 0.5, 0, 1)) if kind == "fire" else 1.0
        draw_batter(bat, swing if swing >= 0 else -1, self.team_color, self.skin, t, load, bat=not flipped)
        if flipped:
            draw_flipped_bat(bat, swing - FLIP_START)
        if kind == "rob":
            rx = clamp(hit.start_x + hit.sideways, 90, 680)
            jump = ROB_JUMP * math.sin(clamp((u - 0.55) / 0.45, 0, 1) * math.pi * 0.5)
            _, rpx, rpy = robber_pos(rx, u)
            glove = draw_wall_robber(bat, rpx, jump, self.fielder_skins["CF"], rpy)
            if u >= 1:
                draw_bat_ball(bat, glove[0], glove[1] - 4, 5)
        if kind == "fire" and t < contact + 0.6:
            draw_text(bat, "ON FIRE!", 385, 100 + 4 * math.sin(t * 8), 22, (255, 170, 40))
        if u >= 1:
            if kind == "rob":
                draw_text(bat, "ROBBED!", 385, 230, 40)
                draw_text(bat, "Leaps and steals a home run at the wall!", 385, 262, 16)
            else:
                big = f"HOME RUN!  {distance} FT" if kind in ("flip", "fire") else "HOME RUN!"
                small = {"board": "Off the scoreboard!", "fan": "Gone!  A fan makes the catch!",
                         "flip": "Absolutely crushed it.  Bat flip!", "fire": "He's on fire!"}[kind]
                draw_text(bat, big, 385, 230, 40)
                draw_text(bat, small, 385, 262, 16)
        bat_h = int(LOGICAL_W * BAT_H / BAT_W)
        scene.fill((14, 17, 22))
        scene.blit(pygame.transform.smoothscale(bat, (LOGICAL_W, bat_h)), (0, (LOGICAL_H - bat_h) // 2))

    def scene_fan(self, scene, t):
        self.scene_homer(scene, t, "fan")

    def scene_board(self, scene, t):
        self.scene_homer(scene, t, "board")

    def scene_robbed(self, scene, t):
        self.scene_homer(scene, t, "rob")

    def scene_flip(self, scene, t):
        self.scene_homer(scene, t, "flip")

    def scene_fire(self, scene, t):
        self.scene_homer(scene, t, "fire")

    # ---- batting view ---------------------------------------------------------
    def draw_bat_view(self, surf):
        self.blit_bat_scene(surf)
        draw_bat_scoreboard(surf, self)
        draw_base_indicator(surf, 60, 88, self.bases, self.steal_armed)
        robbing = bool(self.hit and self.hit.robbed and (self.state == "BALL_IN_FLIGHT" or self.state == "MESSAGE" and self.message == "ROBBED!"))
        if not self.is_derby:                                        # (the derby has no fielders standing around)
            draw_bat_fielders(surf, rob_fielder(clamp(self.hit.start_x + self.hit.sideways, 90, 680)) if robbing else None)
        if self.state == "WIND_UP":
            delivery = min(1, self.state_time / WIND_UP_TIME)
        elif self.state == "PITCH":
            delivery = 1 + 0.3 * smooth(self.pitch.time / PITCH_FOLLOW_TIME)      # the arm carries on through after the release
        else:
            delivery = 0 if self.state == "WAIT" else 1.3                # standing between pitches, holding the finish after the throw
        hand = draw_bat_pitcher(surf, delivery, self.fielder_skins["P"])
        if self.state == "WIND_UP":
            draw_bat_ball(surf, hand[0], hand[1], 3)
        if self.state == "PITCH":
            u = self.pitch.time / self.pitch.duration
            x, y, r = pitch_position(self.pitch, u)
            if u < RELEASE_BLEND:                                        # the ball leaves his hand and settles onto its path
                hx, hy = pitcher_pose(1.0)["screen_hand"]
                k = smooth(u / RELEASE_BLEND)
                x, y = lerp(hx, x, k), lerp(hy, y, k)
            draw_bat_ball(surf, x, y, r)
        if self.fan and self.state in ("BALL_IN_FLIGHT", "MESSAGE"):     # rare animation: a fan catches the home run
            u = min(1.0, self.hit.time / self.hit.flight)
            draw_fan(surf, self.fan[0], self.fan[1], clamp((u - 0.7) / 0.3, 0, 1), self.clock, u >= 1)
            draw_bat_wall(surf)                                              # he is up in the stands, behind the wall
        if self.state == "BALL_IN_FLIGHT":
            x, y, r = hr_position(self.hit)
            draw_bat_ball(surf, x, y, r)
        flipped = bool(self.hit and self.hit.flip and self.swing_clock >= FLIP_START and self.state in ("BALL_IN_FLIGHT", "MESSAGE"))
        if self.on_fire() and self.state in ("WAIT", "WIND_UP", "PITCH"):
            draw_fire_aura(surf, self.clock)
        draw_batter(surf, self.swing_clock, self.team_color, self.skin, self.clock, self.load_amount(), self.settle,
                    self.finish_big if self.swing_clock < 0 else bool(self.hit and self.hit.quality == "perfect_perfect"), bat=not flipped)
        if flipped:
            draw_flipped_bat(surf, self.swing_clock - FLIP_START)
        if self.hit and self.hit.robbed and (self.state == "BALL_IN_FLIGHT" or self.state == "MESSAGE" and self.message == "ROBBED!"):
            u = clamp(self.hit.time / self.hit.flight, 0, 1) if self.state == "BALL_IN_FLIGHT" else 1.0
            rx = clamp(self.hit.start_x + self.hit.sideways, 90, 680)
            _, rpx, rpy = robber_pos(rx, u)
            glove = draw_wall_robber(surf, rpx, ROB_JUMP * math.sin(clamp((u - 0.55) / 0.45, 0, 1) * math.pi * 0.5), self.fielder_skins["CF"], rpy)
            if self.state == "MESSAGE":
                draw_bat_ball(surf, glove[0], glove[1] - 4, 5)
        if self.weather in ("Night", "Rain"):
            self.draw_weather(surf)
        draw_batter_card(surf, self)
        if (self.fire_flash > 0 or self.on_fire()) and not self.is_derby:
            draw_text(surf, "ON FIRE!", 385, 100 if self.fire_flash > 0 else 112, 22 if self.fire_flash > 0 else 14, (255, 170, 40))
        if self.pitch and (self.state in ("PITCH", "BALL_IN_FLIGHT") or self.state == "MESSAGE" and self.state_time < 1.4):
            self.draw_meter(surf)
        for p in self.confetti:
            surf.fill(p["color"], (p["x"], p["y"], p["size"], p["size"]))
        draw_text(surf, "SPACE / click: swing", 8, 14, 11, WHITE, align="left")
        tired = self.fatigue()
        pc = f"  P: {self.pitch_count}" + ("  TIRED" if tired > 0.55 else "")
        draw_text(surf, self.difficulty.upper() + "  |  " + self.weather_label + pc, 8, 28, 10, RED if tired > 0.55 else GOLD, align="left")
        if any(self.bases) and self.state in ("WAIT", "WIND_UP"):
            if self.steal_armed:
                draw_text(surf, "STEAL ON!  (S to cancel)", 8, 42, 10, GREEN, align="left")
            else:
                draw_text(surf, "S: steal", 8, 42, 10, (200, 205, 225), align="left")
        draw_seam_window(surf, self)
        if self.state == "MESSAGE":
            size = 48 + math.sin(self.state_time * 10) * 5 if self.celebrating else 40
            draw_text(surf, self.message, 385, 230, int(size))
            if self.sub_message:
                draw_text(surf, self.sub_message, 385, 262, 16)

    def draw_cutscene_weather(self, surf):
        """The game's weather laid over a cutscene (night lights, rain, or wind streaks)."""
        WET[0] = self.weather == "Rain"
        self.draw_weather(surf)
        if self.weather == "Windy":
            w, h = surf.get_size()
            for i in range(16):
                y = (i * 83 + 60) % (h - 120) + 60
                x = ((i * 191 + self.clock * (420 + 40 * (i % 4))) % (w + 300)) - 150
                pygame.draw.line(surf, (225, 235, 245), (x, y), (x + 70 + (i % 3) * 30, y - 3), 2)

    def draw_weather(self, surf):
        WET[0] = self.weather == "Rain"
        w, h = surf.get_size()
        if self.weather == "Night":
            key = (w, h, "night")
            if key not in self._overlays:
                self._overlays[key] = build_night_overlay(w, h)
            ov = self._overlays[key]
            surf.blit(ov["dark"], (0, 0))                                # dark around the edges...
            surf.blit(ov["beams"], (0, 0))                               # ...light shafts from the towers...
            surf.blit(ov["glow"], (0, 0), special_flags=pygame.BLEND_RGB_ADD)    # ...and the field itself glowing under the lights
            for i, (lx, ly) in enumerate(ov["lights"]):
                shimmer = int((math.sin(self.clock * 6 + i * 2.3) + 1) * 1.49)      # 0, 1 or 2
                surf.blit(ov["flares"][shimmer], (lx - ov["radius"], ly - ov["radius"]), special_flags=pygame.BLEND_RGB_ADD)
                for b in range(3):                                       # moths circling each light
                    a = self.clock * (1.6 + b * 0.7) + i * 1.9 + b * 2.1
                    r = ov["radius"] * (0.45 + 0.25 * math.sin(a * 0.7 + b))
                    pygame.draw.circle(surf, (255, 250, 210), (lx + r * math.cos(a), ly + r * 0.7 * math.sin(a * 1.3)), 1)
        elif self.weather == "Rain":
            key = (w, h, "r")
            if key not in self._overlays:
                shade = pygame.Surface((w, h), pygame.SRCALPHA)
                shade.fill((40, 50, 70, 70))
                self._overlays[key] = shade
            surf.blit(self._overlays[key], (0, 0))
            for fx, fy, sp in self.rain:
                y = (fy * h + self.clock * sp) % h
                x = (fx * w - y * 0.18) % w
                pygame.draw.line(surf, (190, 205, 235), (x, y), (x - 3, y + 10), 1)

    def draw_meter(self, surf):
        """The timing bar: the white marker sweeps right; swing when it is over the green.
        The green sits earlier for inside pitches and later for outside pitches."""
        pitch, bar_x, bar_y, bar_w = self.pitch, 235, 138, 300
        scale = bar_w / (pitch.duration + METER_EXTRA_TIME)               # pixels per second
        center = bar_x + (pitch.duration + pitch.offset) * scale
        pygame.draw.rect(surf, (20, 20, 20), (bar_x - 4, bar_y - 4, bar_w + 8, 22))
        pygame.draw.rect(surf, (34, 34, 34), (bar_x, bar_y, bar_w, 14))
        for window, color in ((self.win_contact, (58, 74, 106)), (self.win_good, (212, 168, 42)),
                              (self.win_perfect, (53, 199, 89)), (self.win_pp, (184, 255, 203))):
            left = max(bar_x, center - window * scale)
            right = min(bar_x + bar_w, center + window * scale)
            pygame.draw.rect(surf, color, (left, bar_y, right - left, 14))
        marker_time = pitch.swing_time if pitch.swung else min(pitch.time, pitch.duration + METER_EXTRA_TIME)
        pygame.draw.rect(surf, WHITE, (bar_x + marker_time * scale - 2, bar_y - 5, 4, 24))
        draw_text(surf, f"{pitch.mph} MPH", bar_x + 30, bar_y - 8, 12)                  # above the bar so the big
        draw_text(surf, LOC_NAMES[pitch.zone + 1].upper(), bar_x + bar_w - 30, bar_y - 8, 12, (200, 205, 225))   # pitch type stays hidden until after the pitch
        if pitch.label:
            color = GREEN if pitch.label.startswith("PERFECT") else GOLD if pitch.label == "GOOD" else RED
            draw_text(surf, pitch.label, 385, bar_y + 40, 22, color)

    def draw_game_over(self, surf):
        """Final score, the line score, and the game stats (drawn full-screen on the 1280x720 canvas)."""
        shade = pygame.Surface((LOGICAL_W, LOGICAL_H), pygame.SRCALPHA)
        shade.fill((0, 0, 0, 205))
        surf.blit(shade, (0, 0))
        draw_text(surf, f"FINAL:  {self.team_name[:10]} {self.runs}  -  {self.cpu_runs} CPU", 640, 112, 34)
        result = f"{self.team_name} win!" if self.runs > self.cpu_runs else "CPU wins" if self.runs < self.cpu_runs else "Tie game"
        draw_text(surf, result, 640, 158, 30, GOLD)
        draw_logo(surf, self.home_logo, 120, 70, 72)
        draw_logo(surf, self.cpu_logo, 1088, 70, 72)
        # line score
        n = max(len(self.my_line), len(self.cpu_line), 1)
        col_w = min(56, 560 // n)
        name_w, total_w = 220, 220 + n * col_w + 70
        x0 = 640 - total_w / 2
        pygame.draw.rect(surf, (110, 120, 160), (x0 - 12, 196, total_w + 24, 146), 2, border_radius=8)
        for i in range(n):
            draw_text(surf, str(i + 1), x0 + name_w + i * col_w + col_w / 2, 236, 18, GOLD)
        draw_text(surf, "R", x0 + name_w + n * col_w + 35, 236, 18, GOLD)
        rows = ((self.team_name[:12], self.my_line, self.runs, self.home_logo), ("CPU", self.cpu_line, self.cpu_runs, self.cpu_logo))
        for row, (label, line, total, logo) in enumerate(rows):
            y = 282 + row * 44
            draw_logo(surf, logo, x0 + 6, y - 24, 30)
            draw_text(surf, label, x0 + 42, y, 16, align="left")
            for i, value in enumerate(line):
                draw_text(surf, str(value), x0 + name_w + i * col_w + col_w / 2, y, 20)
            draw_text(surf, str(total), x0 + name_w + n * col_w + 35, y, 24, GOLD)
        # stats
        st = self.stats
        left = [("Hits", st["hits"]), ("Home runs", st["hr"]), ("Perfect swings", st["perfect"])]
        right = [("Strikeouts", st["k"]), ("Walks", st["bb"]), ("Stolen bases", f"{st['steals']}/{st['steal_att']}")]
        draw_text(surf, "YOUR STATS", 715, 400, 20, GOLD)
        for i, (label, value) in enumerate(left):
            draw_text(surf, f"{label}: {value}", 470, 450 + i * 42, 19, align="left")
        for i, (label, value) in enumerate(right):
            draw_text(surf, f"{label}: {value}", 760, 450 + i * 42, 19, align="left")
        draw_text(surf, "Longest HR: " + (f"{st['long_hr']} ft" if st["long_hr"] else "-") + f"   Best hot streak: {st['best_streak']}"
                  + f"   Errors: {st['errors']}  DP: {st['dp']}  SF: {st['sf']}  Robbed: {st['robbed']}", 640, 660, 14, (210, 215, 235))
        self.draw_spray_chart(surf, 20, 392, 400, 250)
        bx = 1010
        draw_text(surf, "BOX SCORE", bx + 90, 392, 16, GOLD)
        draw_text(surf, "AB  H  HR", bx + 262, 392, 11, (200, 205, 225), align="right")
        for i, b in enumerate(self.lineup):
            y = 414 + i * 20
            draw_text(surf, f"{i + 1}. {b['name']}", bx, y + 8, 12, align="left", outline=False)
            draw_text(surf, f"{b['ab']}   {b['h']}   {b['hr']}", bx + 262, y + 8, 12, align="right", outline=False)
        draw_text(surf, "Click or press SPACE for the title screen", 640, 690, 18)

    def draw_spray_chart(self, surf, x, y, w, h):
        """Every ball you put in play on a little field: green = hit, red = out, gold = home run (past the wall)."""
        pygame.draw.rect(surf, (14, 22, 34), (x, y, w, h), border_radius=10)
        pygame.draw.rect(surf, (110, 120, 160), (x, y, w, h), 2, border_radius=10)
        hits = sum(1 for p in self.spray if p[2] == "hit")
        hrs = sum(1 for p in self.spray if p[2] == "hr")
        outs = len(self.spray) - hits - hrs
        draw_text(surf, "SPRAY CHART", x + 14, y + 16, 14, GOLD, align="left")
        draw_text(surf, f"{len(self.spray)} in play", x + w - 14, y + 16, 12, (200, 205, 225), outline=False, align="right")
        k = min((h - 58) / SPRAY_MAX_PX, (w - 30) / (SPRAY_MAX_PX * 1.8))
        ox, oy = x + w / 2, y + h - 22
        def pt(px, py):
            return ox + (px - HOME[0]) * k, oy + (py - HOME[1]) * k
        a_l, a_r = math.atan2(U_LEFT[0], -U_LEFT[1]), math.atan2(U_RIGHT[0], -U_RIGHT[1])
        def arc(frac, n=28):
            return [(ox + math.sin(a_l + (a_r - a_l) * i / n) * SPRAY_MAX_PX * frac * k,
                     oy - math.cos(a_l + (a_r - a_l) * i / n) * SPRAY_MAX_PX * frac * k) for i in range(n + 1)]
        pygame.draw.polygon(surf, (58, 62, 78), [(ox, oy)] + arc(1.0))                      # the stands
        pygame.draw.polygon(surf, (44, 120, 52), [(ox, oy)] + arc(SPRAY_FENCE))             # the grass
        pygame.draw.polygon(surf, (52, 138, 60), [(ox, oy)] + arc(0.62))                    # mown stripe
        pygame.draw.polygon(surf, (44, 120, 52), [(ox, oy)] + arc(0.5))
        pygame.draw.lines(surf, (230, 230, 120), False, arc(SPRAY_FENCE), 2)                # the wall
        pygame.draw.polygon(surf, (176, 124, 76), [pt(*BASES[0]), pt(*BASES[1]), pt(*BASES[2]), pt(*BASES[3])])
        pygame.draw.polygon(surf, (56, 140, 64), [pt(*BASES[0]), pt(*BASES[1]), pt(*BASES[2]), pt(*BASES[3])], 0) if False else None
        mid = (sum(b[0] for b in BASES[:4]) / 4, sum(b[1] for b in BASES[:4]) / 4)           # the infield grass: the dirt diamond shrunk about its
        inner = [pt(mid[0] + (b[0] - mid[0]) * 0.62, mid[1] + (b[1] - mid[1]) * 0.62) for b in BASES[:4]]   # centre, so every edge runs parallel to the dirt's
        pygame.draw.polygon(surf, (50, 130, 58), inner)
        for ang in (a_l, a_r):                                                                # foul lines
            pygame.draw.line(surf, WHITE, (ox, oy), (ox + math.sin(ang) * SPRAY_MAX_PX * k, oy - math.cos(ang) * SPRAY_MAX_PX * k), 1)
        for b in BASES[1:4]:
            bx, by = pt(*b)
            pygame.draw.rect(surf, WHITE, (bx - 3, by - 3, 6, 6))
        pygame.draw.polygon(surf, WHITE, [(ox - 3, oy), (ox + 3, oy), (ox + 3, oy + 3), (ox, oy + 6), (ox - 3, oy + 3)])
        mx, my = pt(*MOUND)
        pygame.draw.circle(surf, (190, 140, 90), (mx, my), 4)
        for px, py, kind in self.spray:
            cx, cy = pt(px, py)
            if kind == "hr":
                pygame.draw.circle(surf, GOLD, (cx, cy), 7)
                pygame.draw.circle(surf, WHITE, (cx, cy), 7, 2)
                pygame.draw.circle(surf, (120, 80, 0), (cx, cy), 2)
            elif kind == "hit":
                pygame.draw.circle(surf, GREEN, (cx, cy), 5)
                pygame.draw.circle(surf, WHITE, (cx, cy), 5, 1)
            else:
                pygame.draw.line(surf, RED, (cx - 4, cy - 4), (cx + 4, cy + 4), 3)
                pygame.draw.line(surf, RED, (cx - 4, cy + 4), (cx + 4, cy - 4), 3)
        for i, (label, color, n) in enumerate((("HITS", GREEN, hits), ("OUTS", RED, outs), ("HR", GOLD, hrs))):
            ly = y + 38 + i * 18
            pygame.draw.circle(surf, color, (x + 18, ly), 5)
            draw_text(surf, f"{label} {n}", x + 28, ly + 5, 12, WHITE, outline=False, align="left")

    # ---- overhead field view --------------------------------------------------
    def draw_field_view(self, surf):
        self.blit_field_scene(surf)
        fp = self.fp
        if fp:
            self.draw_dust(surf)                                          # dust / grass bits under running feet (behind the people)
            people = []                                                   # (y, drawing function) so lower people overlap higher ones
            button = self.field_button()
            if button:                                                    # the RUN / SLIDE circle sits on the ground, under his feet
                draw_button(surf, button[1], button[2], button[0], SLIDE_GREEN if button[0] == "Slide" else TEAL)
            for n, other in enumerate(fp.others):
                if other["pos"] < 4 and not other["scored"] and not (other["out"] and self.state == "MESSAGE"):
                    x, y = point_on_path(other["pos"])
                    sway, bob = self.gait(("o", n))
                    people.append((y, lambda x=x, y=y, sk=other["skin"], sw=sway, bo=bob: draw_person(
                        surf, x, y, 1.3, (235, 235, 235), self.team_color, skin=sk,
                        shadow_color=self.shadow_at(x, y), sway=sw, bob=bo)))
            for i, f in enumerate(fp.fielders):
                people.append((f.y, lambda i=i, f=f: self.draw_fielder(surf, i, f)))
            r = fp.runner
            rx, ry = self.runner_xy()
            if not (fp.walk and fp.walk["done"]):                         # (once he is in the dugout he is gone)
                people.append((ry, lambda: self.draw_runner(surf, rx, ry)))
            for _, draw in sorted(people, key=lambda p: p[0]):
                draw()
            self.draw_field_ball(surf)
            self.draw_rare_effects(surf)
            if r.moving and r.run_through:
                draw_text(surf, "Running through!", rx, ry - 52, 16, GREEN)
            if fp.error_fx and fp.error_fx["t"] < 1.6:
                draw_text(surf, "ERROR!", fp.error_fx["x"], fp.error_fx["y"] - 48 - 14 * fp.error_fx["t"], 24, RED)
        if self.weather in ("Night", "Rain"):
            self.draw_weather(surf)
        self.draw_field_hud(surf)

    def draw_fielder(self, surf, i, f):
        """A fielder: standing, swaying as he runs, or (rare animations) diving / leaping. His shadow and dust match the ground."""
        fp = self.fp
        ground = TERRAIN[terrain_at(f.x, f.y)]
        skin = self.fielder_skins[f.name]
        if fp.dive and fp.dive["idx"] == i and fp.dive["t"] < DIVE_TIME + DIVE_RECOVERY * 0.6:
            draw_dive(surf, f.x, f.y, FIELDER_SCALE, FIELD_BODY, FIELD_CAP, fp.dive["t"], fp.dive["dir"], skin=skin,
                      shadow_color=ground["shadow"], dust_color=ground["dust"][0])
        elif fp.leap and i == fp.chaser:
            draw_leap(surf, f.x, f.y, FIELDER_SCALE, FIELD_BODY, FIELD_CAP, fp.leap["t"], skin=skin, shadow_color=ground["shadow"])
        else:
            sway, bob = self.gait(("f", i))
            draw_person(surf, f.x, f.y, FIELDER_SCALE, skin=skin, shadow_color=ground["shadow"], sway=sway, bob=bob)

    def draw_rare_effects(self, surf):
        """Banners and the flying bat for the rare animations, plus the white CAUGHT! effect and the landing dust."""
        fp = self.fp
        if fp.broken:
            draw_broken_bat(surf, HOME[0], HOME[1], fp.broken["t"], fp.broken["dir"])
            if fp.broken["t"] < 1.3:
                draw_text(surf, "BROKEN BAT!", 640, 112, 40, GOLD)
        if fp.dive:
            f = fp.fielders[fp.dive["idx"]]
            draw_text(surf, "DIVING STOP!", f.x, f.y - 70, 28, GOLD)
        if fp.leap:
            f = fp.fielders[fp.chaser]
            draw_text(surf, "LEAPING CATCH!", f.x, f.y - 105, 28, GOLD)
        if fp.catch and fp.catch["t"] < CATCH_FX_TIME:           # every fly out: white, so it never looks like a rare (gold) animation
            t = fp.catch["t"]
            f = fp.fielders[fp.chaser]
            if fp.leap:
                gx, gy = leap_glove(f.x, f.y, FIELDER_SCALE, fp.leap["t"])
            else:
                gx, gy = f.x + 8, f.y - 18
            if t < 0.45:                                         # flash ring + sparks at the glove
                k = t / 0.45
                pygame.draw.circle(surf, WHITE, (gx, gy), int(8 + 46 * k), max(1, int(5 * (1 - k))))
                for j in range(8):
                    a = j * math.pi / 4
                    pygame.draw.line(surf, WHITE, (gx + math.cos(a) * (14 + 40 * k), gy + math.sin(a) * (14 + 40 * k)),
                                     (gx + math.cos(a) * (24 + 50 * k), gy + math.sin(a) * (24 + 50 * k)), 2)
            top = f.y - (135 if fp.leaped else 75)
            draw_text(surf, "CAUGHT!", f.x, top - 14 * min(1, t / 0.3), 30, WHITE)
        if fp.landed and fp.landed["t"] < 0.8:                   # dust where the ball hit the grass
            t, lx, ly = fp.landed["t"], fp.landed["x"], fp.landed["y"]
            dust_color = TERRAIN[terrain_at(lx, ly)]["dust"][0]          # the puff is the colour of the ground it hit
            for j in range(8):
                a = j * math.pi / 4
                r = (3 + 8 * t) * max(0.0, 1 - t / 0.8)
                if r >= 1:
                    pygame.draw.circle(surf, dust_color, (lx + math.cos(a) * 34 * t, ly - 3 + math.sin(a) * 16 * t), r)

    def draw_runner(self, surf, x, y):
        r = self.fp.runner
        ring = (255, 255, 255) if r.turn_cooldown <= 0 else (150, 150, 150)       # grey ring = can't turn around yet
        if r.moving and not r.sliding:
            pygame.draw.ellipse(surf, ring, (x - 18, y - 6, 36, 14), 2)
        sway, bob = self.gait("runner")
        draw_person(surf, x, y, 1.6, (240, 240, 240), self.team_color, sliding=r.sliding, skin=self.fp.skin or SKIN_DEFAULT,
                    shadow_color=self.shadow_at(x, y), sway=sway, bob=bob)
        if self.fp.broken and r.pos == 0:                                        # still holding the stump of the bat
            draw_bat_stub(surf, x, y)

    def draw_field_ball(self, surf):
        ball = self.fp.ball
        if ball.mode == "held":
            x, y, z = ball.x + 8, ball.y - 14, 0
            fp = self.fp
            if fp.dive and fp.dive["idx"] == ball.holder and fp.dive["t"] < DIVE_TIME + DIVE_RECOVERY * 0.6:
                gx, gy = dive_glove(ball.x, ball.y, FIELDER_SCALE, fp.dive["dir"])       # ball is in the stretched-out glove
                x, y = gx, gy + 4
            elif fp.leap and ball.holder == fp.chaser:
                gx, gy = leap_glove(ball.x, ball.y, FIELDER_SCALE, fp.leap["t"])         # ball is in the glove up high
                x, y = gx, gy + 4
            ground_y = y
        else:
            x, y, z = ball.x, ball.y, ball.z
            ground_y = y
            pygame.draw.ellipse(surf, self.shadow_at(x, ground_y), (x - 6, ground_y - 2, 12, 5))
        pygame.draw.circle(surf, WHITE, (x, y - z - 4), 6)
        pygame.draw.circle(surf, (204, 51, 51), (x, y - z - 4), 6, 1)
        fp = self.fp
        if ball.mode == "held" and fp.catch and ball.holder == fp.chaser and fp.hit.kind == "FLY_OUT":
            pygame.draw.circle(surf, WHITE, (x, y - z - 4), 10 + int(2 * math.sin(self.clock * 12)), 2)    # white halo on the caught ball

    def draw_field_hud(self, surf):
        pygame.draw.rect(surf, (31, 35, 39), (410, 8, 460, 64), border_radius=8)
        pygame.draw.rect(surf, (102, 102, 102), (410, 8, 460, 64), 2, border_radius=8)
        draw_logo(surf, self.home_logo, 418, 18, 44)
        draw_logo(surf, self.cpu_logo, 818, 18, 44)
        for i in range(OUTS_PER_INNING):
            pygame.draw.circle(surf, (232, 232, 232), (476 + i * 20, 28), 7, 0 if i < self.outs else 2)
        draw_text(surf, f"INN {self.inning}/{self.innings}", 640, 34, 16, (232, 232, 232), outline=False)
        draw_text(surf, f"B{self.balls} S{self.strikes}", 810, 34, 16, (232, 232, 232), outline=False, align="right")
        score_line = f"{self.team_name} {self.runs}  -  {self.cpu_runs} CPU"
        score_size = 24
        while score_size > 12 and get_font(score_size).size(score_line)[0] > 330:     # shrink to fit the box
            score_size -= 1
        draw_text(surf, score_line, 640, 64, score_size, (232, 232, 232), outline=False)
        draw_text(surf, "RUN button / R: next base   S: slide   click runner or SPACE: turn back", 12, 24, 15, WHITE, align="left")
        draw_text(surf, self.weather_label, 12, 46, 12, (200, 205, 225), outline=False, align="left")
        if self.state == "MESSAGE":
            draw_text(surf, self.message, 640, 140, 56)
            if self.sub_message:
                draw_text(surf, self.sub_message, 640, 180, 24)


# =============================================================================
# 5. THE START SCREEN  -  title, team name, home color, difficulty, game length
# =============================================================================

class Menu:
    def __init__(self):
        self.background = build_menu_background()
        self.title = build_title(TITLE_TEXT)
        self.name = DEFAULT_TEAM_NAME
        self.color_index = 0
        self.difficulty = DEFAULT_DIFFICULTY
        self.innings = DEFAULT_INNINGS
        self.t = 0.0
        self.flashes = []                                    # little camera flashes in the crowd
        self.mouse = (-1, -1)
        self.name_rect = pygame.Rect(320, 330, 440, 44)
        self.swatches = [(323 + i * 62, 448) for i in range(len(TEAM_COLORS))]
        self.diff_rects = {name: pygame.Rect(299 + i * 166, 514, 150, 42) for i, name in enumerate(DIFFICULTIES)}
        self.inning_rects = {n: pygame.Rect(822 + i * 56, 606, 48, 38) for i, n in enumerate(INNING_OPTIONS)}
        self.screen = "home"                                 # "home" (the exhibition setup) or "scores" (the high-score board)
        self.toast, self.toast_t = "", 0.0
        self.raw_mouse = (-1, -1)
        self.side_rects = [pygame.Rect(40, 300 + i * 78, 250, 62) for i in range(4)]
        self.back_rect = pygame.Rect(60, 560, 150, 40)
        self.clear_scores_rect = pygame.Rect(540, 642, 200, 32)
        self.clear_armed = 0.0
        self.score_diff, self.score_open = "Hard", False     # the high-score board's difficulty drop-down (opens on Hard)
        self.score_box = pygame.Rect(790, 296, 240, 36)
        self.score_items = {name: pygame.Rect(790, 336 + i * 38, 240, 36) for i, name in enumerate(DIFFICULTIES)}
        self.start_rect = pygame.Rect(400, 623, 280, 54)
        self.bat_choice = 0                                  # 0 = mixed (every hitter his own bat), else the whole team uses that bat
        self.bat_rect = pygame.Rect(850, 546, 160, 30)
        self.weather_choice = "Random"                       # Random, Clear, Night, Rain or Windy
        self.weather_rect = pygame.Rect(692, 640, 122, 34)
        # logo drawing patch
        self.patch_rect = pygame.Rect(858, 330, 144, 144)          # 3 screen pixels per logo pixel
        self.pen_pos = [(852 + i * 26, 494) for i in range(len(PEN_COLORS) + 1)]     # last one is the eraser
        self.clear_rect = pygame.Rect(885, 516, 90, 24)
        self.logo = pygame.Surface((LOGO_PX, LOGO_PX), pygame.SRCALPHA)
        self.logo_drawn, self.pen, self.drawing, self.last_pt = False, 0, False, None
        if os.path.exists(LOGO_FILE):                              # bring back the logo you drew last time
            try:
                self.logo = pygame.transform.scale(pygame.image.load(LOGO_FILE).convert_alpha(), (LOGO_PX, LOGO_PX))
                self.logo_drawn = True
            except (pygame.error, FileNotFoundError):
                self.logo = pygame.Surface((LOGO_PX, LOGO_PX), pygame.SRCALPHA)
        self.load_settings()

    def load_settings(self):
        """Bring back the team name, color, difficulty and innings from last time (anything missing or invalid is ignored)."""
        try:
            with open(SETTINGS_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
        except (OSError, ValueError):
            return
        if not isinstance(data, dict):
            return
        name = data.get("team_name")
        if isinstance(name, str) and name.strip():
            self.name = name[:MAX_NAME_LENGTH]
        labels = [label for label, _ in TEAM_COLORS]
        if data.get("team_color") in labels:
            self.color_index = labels.index(data["team_color"])
        if data.get("difficulty") in DIFFICULTIES:
            self.difficulty = data["difficulty"]
        if data.get("innings") in INNING_OPTIONS:
            self.innings = data["innings"]
        if data.get("weather") in WEATHER_OPTIONS:
            self.weather_choice = data["weather"]

    def save_settings(self):
        """Remember the start-screen choices (saved when you press PLAY BALL, just like the logo)."""
        data = {"team_name": self.name, "team_color": TEAM_COLORS[self.color_index][0],
                "difficulty": self.difficulty, "innings": self.innings, "bat_choice": self.bat_choice,
                "weather": self.weather_choice}
        try:
            with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
        except OSError:
            pass

    def stroke(self, pos):
        """Paint on the logo patch with the pen (or erase)."""
        px = self.patch_rect
        pt = (int((pos[0] - px.x) / 3), int((pos[1] - px.y) / 3))
        erase = self.pen == len(PEN_COLORS)
        color = (0, 0, 0, 0) if erase else PEN_COLORS[self.pen] + (255,)
        width = 5 if erase else 3
        if self.last_pt:
            pygame.draw.line(self.logo, color, self.last_pt, pt, width)
        pygame.draw.circle(self.logo, color, pt, width // 2)
        self.last_pt = pt
        self.logo_drawn = True

    def click_logo_tools(self, pos):
        if self.patch_rect.collidepoint(pos):
            self.drawing, self.last_pt = True, None
            self.stroke(pos)
            return
        for i, (cx, cy) in enumerate(self.pen_pos):
            if math.hypot(pos[0] - cx, pos[1] - cy) <= 13:
                self.pen = i
        if self.clear_rect.collidepoint(pos):
            self.logo.fill((0, 0, 0, 0))
            self.logo_drawn = False

    def logo_for_game(self):
        """The finished logo for the game (and saves your drawing so it is here next time)."""
        if self.logo_drawn:
            try:
                pygame.image.save(self.logo, LOGO_FILE)
            except pygame.error:
                pass
            return compose_logo(self.logo, self.team_color)
        return build_default_logo(self.team_name, self.team_color)

    def draw_logo_tools(self, surf):
        draw_text(surf, "DRAW YOUR LOGO", 930, 318, 16, GOLD)
        outer, inner = self.patch_rect.inflate(16, 16), self.patch_rect
        pygame.draw.rect(surf, WHITE, outer, border_radius=20)
        pygame.draw.rect(surf, self.team_color, inner, border_radius=14)
        if self.logo_drawn:
            surf.blit(pygame.transform.scale(self.logo, inner.size), inner.topleft)
        else:
            preview = build_default_logo(self.name, self.team_color)       # a faint preview of the default badge
            preview.set_alpha(100)
            surf.blit(pygame.transform.scale(preview, inner.size), inner.topleft)
            draw_text(surf, "click + drag to draw", 930, inner.bottom - 8, 12, WHITE)
        pygame.draw.rect(surf, (255, 255, 255), inner.inflate(-8, -8), 1, border_radius=11)       # stitching
        for i, (cx, cy) in enumerate(self.pen_pos):
            selected = i == self.pen
            if i == len(PEN_COLORS):                                          # eraser
                pygame.draw.circle(surf, (90, 92, 104), (cx, cy), 10)
                pygame.draw.line(surf, WHITE, (cx - 4, cy - 4), (cx + 4, cy + 4), 2)
                pygame.draw.line(surf, WHITE, (cx - 4, cy + 4), (cx + 4, cy - 4), 2)
            else:
                pygame.draw.circle(surf, PEN_COLORS[i], (cx, cy), 10)
                pygame.draw.circle(surf, (120, 125, 145), (cx, cy), 11, 1)
            if selected:
                pygame.draw.circle(surf, GOLD, (cx, cy), 14, 3)
        hover = self.clear_rect.collidepoint(self.mouse)
        pygame.draw.rect(surf, (60, 70, 110) if hover else (34, 42, 80), self.clear_rect, border_radius=8)
        pygame.draw.rect(surf, (110, 120, 160), self.clear_rect, 2, border_radius=8)
        draw_text(surf, "CLEAR", self.clear_rect.centerx, self.clear_rect.centery + 5, 11)

    @property
    def team_name(self):
        return self.name.strip() or "HOME"

    @property
    def team_color(self):
        return TEAM_COLORS[self.color_index][1]

    DX = 110                                                 # the setup panel sits this far to the right (the options are on the left)
    SIDE_LABELS = ("EXHIBITION", "HR DERBY", "HIGH-SCORE", "QUIT")

    def side_click(self, i):
        if i == 0:
            self.screen = "home"
        elif i == 1:
            self.toast, self.toast_t = "HR DERBY is coming soon!", 2.2
        elif i == 2:
            self.screen = "scores"
        else:
            pygame.quit()
            sys.exit()

    def handle_event(self, event, to_canvas):
        """Returns True when the player chooses to start the game."""
        if event.type in (pygame.MOUSEMOTION, pygame.MOUSEBUTTONDOWN):
            self.raw_mouse = to_canvas(event.pos)
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 and self.screen == "home":
            ir = self.title["image"].get_rect(center=(640, 150))
            if pygame.Rect(ir.x + 30, ir.y, self.title["f_w"] + 12, ir.h).collidepoint(self.raw_mouse):
                unlock_all()                                 # easter egg / dev tool: click the F in FLASH
                return False
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for i, rect in enumerate(self.side_rects):
                if rect.collidepoint(self.raw_mouse):
                    self.side_click(i)
                    return False
        if event.type == pygame.MOUSEMOTION:
            self.mouse = (self.raw_mouse[0] - self.DX, self.raw_mouse[1])
        if self.screen == "derby_pick":                      # choose one of three hitters for the derby
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                pos = (self.raw_mouse[0] - self.DX, self.raw_mouse[1])
                for rect, hitter in zip(DERBY_CARD_RECTS, self.derby_choices):
                    if rect.collidepoint(pos):
                        self.derby_hitter, self.want_derby = hitter, True
            elif event.type == pygame.KEYDOWN and event.key in (pygame.K_ESCAPE, pygame.K_BACKSPACE):
                self.screen = "home"
            elif event.type == pygame.KEYDOWN and event.key in (pygame.K_1, pygame.K_2, pygame.K_3):
                self.derby_hitter, self.want_derby = self.derby_choices[event.key - pygame.K_1], True
            return False
        if self.screen == "scores":                          # the high-score board only has its own buttons
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                pos = (self.raw_mouse[0] - self.DX, self.raw_mouse[1])
                if self.score_open:                          # an open drop-down takes the click
                    for name, rect in self.score_items.items():
                        if rect.collidepoint(pos):
                            self.score_diff, self.clear_armed = name, 0.0
                    self.score_open = False
                elif self.score_box.collidepoint(pos):
                    self.score_open = True
                elif self.clear_scores_rect.collidepoint(pos):
                    if self.clear_armed > 0:                 # (click twice to confirm; clears the board being shown)
                        data = load_scores()
                        data["scores"][self.score_diff] = {"records": {}, "totals": {}}
                        save_scores(data)
                        self.clear_armed = 0.0
                    else:
                        self.clear_armed = 2.5
            elif event.type == pygame.KEYDOWN and event.key in (pygame.K_ESCAPE, pygame.K_BACKSPACE, pygame.K_RETURN, pygame.K_SPACE):
                self.screen, self.score_open = "home", False
            return False
        if event.type == pygame.MOUSEMOTION:
            self.mouse = (self.raw_mouse[0] - self.DX, self.raw_mouse[1])
            if self.drawing and event.buttons[0]:
                self.stroke(self.mouse)
        elif event.type == pygame.MOUSEBUTTONUP:
            self.drawing, self.last_pt = False, None
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            pos = self.mouse = (self.raw_mouse[0] - self.DX, self.raw_mouse[1])
            self.click_logo_tools(pos)
            for i, (cx, cy) in enumerate(self.swatches):
                if math.hypot(pos[0] - cx, pos[1] - cy) <= 26:
                    self.color_index = i
            for name, rect in self.diff_rects.items():
                if rect.collidepoint(pos):
                    self.difficulty = name
            for n, rect in self.inning_rects.items():
                if rect.collidepoint(pos):
                    self.innings = n
            if self.weather_rect.collidepoint(pos):
                self.cycle_weather()
            if self.start_rect.collidepoint(pos):
                return True
        elif event.type == pygame.KEYDOWN:
            names = list(DIFFICULTIES)
            if event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                return True
            elif event.key == pygame.K_BACKSPACE:
                self.name = self.name[:-1]
            elif event.key == pygame.K_LEFT:
                self.color_index = (self.color_index - 1) % len(TEAM_COLORS)
            elif event.key == pygame.K_RIGHT:
                self.color_index = (self.color_index + 1) % len(TEAM_COLORS)
            elif event.key == pygame.K_UP:
                self.difficulty = names[(names.index(self.difficulty) - 1) % len(names)]
            elif event.key == pygame.K_DOWN:
                self.difficulty = names[(names.index(self.difficulty) + 1) % len(names)]
            elif event.key == pygame.K_TAB and event.mod & pygame.KMOD_SHIFT:
                self.cycle_weather()
            elif event.key == pygame.K_TAB:
                self.innings = INNING_OPTIONS[(INNING_OPTIONS.index(self.innings) + 1) % len(INNING_OPTIONS)]
            elif event.unicode and len(self.name) < MAX_NAME_LENGTH and (event.unicode.isalnum() or event.unicode in " -'.!&"):
                self.name += event.unicode.upper()
        return False

    def cycle_weather(self):
        self.weather_choice = WEATHER_OPTIONS[(WEATHER_OPTIONS.index(self.weather_choice) + 1) % len(WEATHER_OPTIONS)]

    def update(self, dt):
        self.t += dt
        self.toast_t = max(0.0, self.toast_t - dt)
        self.clear_armed = max(0.0, self.clear_armed - dt)
        if random.random() < dt * 8:
            self.flashes.append(dict(x=random.uniform(20, LOGICAL_W - 20), y=random.uniform(176, 300), life=0.4, max=0.4))
        for f in self.flashes:
            f["life"] -= dt
        self.flashes = [f for f in self.flashes if f["life"] > 0]

    def draw(self, surf):
        surf.blit(self.background, (0, 0))
        for f in self.flashes:                               # camera flashes popping in the stands
            b = f["life"] / f["max"]
            color, r = (int(255 * b),) * 3, int(3 + 7 * b)
            pygame.draw.circle(surf, color, (f["x"], f["y"]), r)
            pygame.draw.line(surf, color, (f["x"] - 2 * r, f["y"]), (f["x"] + 2 * r, f["y"]), 2)
            pygame.draw.line(surf, color, (f["x"], f["y"] - 2 * r), (f["x"], f["y"] + 2 * r), 2)
        draw_bolt(surf, 120, 150, 190, False, self.t)
        draw_bolt(surf, 1160, 150, 190, True, self.t)
        draw_title(surf, self.title, 640, 150 + 4 * math.sin(self.t * 2), self.t)
        main, surf = surf, pygame.Surface((LOGICAL_W, LOGICAL_H), pygame.SRCALPHA)       # the panel is drawn on its own layer, then shifted right
        if self.screen == "scores":
            self.draw_scores(surf)
            main.blit(surf, (self.DX, 0))
            return self.draw_side(main)
        if self.screen == "derby_pick":
            draw_derby_pick(self, surf)
            main.blit(surf, (self.DX, 0))
            return self.draw_side(main)

        panel = pygame.Surface((840, 424), pygame.SRCALPHA)
        pygame.draw.rect(panel, (10, 14, 34, 205), panel.get_rect(), border_radius=18)
        pygame.draw.rect(panel, (255, 255, 255, 60), panel.get_rect(), 2, border_radius=18)
        surf.blit(panel, (220, 272))

        # team name
        draw_text(surf, "TEAM NAME", 540, 318, 16, GOLD)
        pygame.draw.rect(surf, (22, 28, 60), self.name_rect, border_radius=8)
        pygame.draw.rect(surf, GOLD, self.name_rect, 2, border_radius=8)
        if self.name:
            draw_text(surf, self.name, 540, 362, 26)
        else:
            draw_text(surf, "type a name", 540, 360, 20, (140, 150, 180), outline=False)
        if int(self.t * 2) % 2 == 0:
            width = get_font(26).size(self.name)[0] if self.name else 0
            pygame.draw.rect(surf, GOLD, (540 + width / 2 + 4, 337, 3, 30))

        # home color
        draw_text(surf, f"HOME COLOR: {TEAM_COLORS[self.color_index][0].upper()}", 540, 412, 16, GOLD)
        for i, ((cx, cy), (_, color)) in enumerate(zip(self.swatches, TEAM_COLORS)):
            selected = i == self.color_index
            hover = math.hypot(self.mouse[0] - cx, self.mouse[1] - cy) <= 26
            r = 22 if selected or hover else 20
            pygame.draw.circle(surf, BLACK, (cx, cy + 3), r + 2)
            pygame.draw.circle(surf, color, (cx, cy), r)
            if selected:
                pygame.draw.circle(surf, WHITE, (cx, cy), r + 5, 3)
            else:
                pygame.draw.circle(surf, (120, 125, 145), (cx, cy), r + 1, 2)

        # difficulty
        draw_text(surf, "DIFFICULTY", 540, 500, 16, GOLD)
        for name, rect in self.diff_rects.items():
            selected, hover = name == self.difficulty, rect.collidepoint(self.mouse)
            pygame.draw.rect(surf, TEAL if selected else (60, 70, 110) if hover else (34, 42, 80), rect, border_radius=10)
            pygame.draw.rect(surf, WHITE if selected else (110, 120, 160), rect, 2, border_radius=10)
            draw_text(surf, name.upper(), rect.centerx, rect.centery + 8, 20)
        for i, line in enumerate(DIFFICULTIES[self.difficulty]["blurb"]):
            draw_text(surf, line, 540, 585 + i * 20, 14, (220, 225, 240))

        # play button
        hover = self.start_rect.collidepoint(self.mouse)
        rect = self.start_rect.inflate(int(6 * math.sin(self.t * 5)) + 6, int(3 * math.sin(self.t * 5)) + 3)
        pygame.draw.rect(surf, (255, 220, 110) if hover else GOLD, rect, border_radius=14)
        pygame.draw.rect(surf, WHITE, rect, 3, border_radius=14)
        draw_text(surf, "PLAY BALL!", rect.centerx, rect.centery + 11, 30, (60, 35, 0), outline=False)

        # weather (click to cycle: Random, Sunny, Night, Rain, Windy)
        hover = self.weather_rect.collidepoint(self.mouse)
        draw_text(surf, "WEATHER", self.weather_rect.centerx, self.weather_rect.y - 6, 14, GOLD)
        pygame.draw.rect(surf, (60, 70, 110) if hover else (34, 42, 80), self.weather_rect, border_radius=8)
        pygame.draw.rect(surf, WHITE if self.weather_choice != "Random" else (110, 120, 160), self.weather_rect, 2, border_radius=8)
        draw_text(surf, WEATHER_NAMES[self.weather_choice], self.weather_rect.centerx, self.weather_rect.centery + 7, 17)

        # team preview + game length
        self.draw_logo_tools(surf)
        draw_text(surf, "INNINGS", 930, 596, 16, GOLD)
        for n, rect in self.inning_rects.items():
            selected, hover = n == self.innings, rect.collidepoint(self.mouse)
            pygame.draw.rect(surf, TEAL if selected else (60, 70, 110) if hover else (34, 42, 80), rect, border_radius=8)
            pygame.draw.rect(surf, WHITE if selected else (110, 120, 160), rect, 2, border_radius=8)
            draw_text(surf, str(n), rect.centerx, rect.centery + 8, 20)

        draw_text(surf, "Type to name your team  |  LEFT/RIGHT: color  |  UP/DOWN: difficulty  |  TAB: innings  |  SHIFT+TAB: weather  |  ENTER: play  |  F11: fullscreen",
                  640 - self.DX, 714, 12, (190, 195, 215))
        main.blit(surf, (self.DX, 0))
        self.draw_side(main)

    def draw_side(self, surf):
        """The option buttons on the left: EXHIBITION, HR DERBY, HIGH-SCORE, QUIT."""
        current = {"home": 0, "scores": 2, "derby_pick": 1}[self.screen]
        for i, (rect, label) in enumerate(zip(self.side_rects, self.SIDE_LABELS)):
            selected, hover = i == current, rect.collidepoint(self.raw_mouse)
            body = TEAL if selected else (60, 70, 110) if hover else (24, 30, 64)
            if i == 3 and hover:
                body = (150, 50, 50)
            r = rect.inflate(10, 4) if hover and not selected else rect
            pygame.draw.rect(surf, (10, 14, 34), r.move(0, 4), border_radius=14)
            pygame.draw.rect(surf, body, r, border_radius=14)
            pygame.draw.rect(surf, WHITE if selected else (110, 120, 160), r, 3 if selected else 2, border_radius=14)
            draw_text(surf, label, r.centerx, r.centery + 8, 26)
        if self.toast_t > 0:
            draw_text(surf, self.toast, 165, self.side_rects[1].bottom + 22, 14, GOLD)

    def draw_scores(self, surf):
        """The high-score board (drawn in the panel's space)."""
        panel = pygame.Surface((840, 424), pygame.SRCALPHA)
        pygame.draw.rect(panel, (10, 14, 34, 215), panel.get_rect(), border_radius=18)
        pygame.draw.rect(panel, (255, 255, 255, 60), panel.get_rect(), 2, border_radius=18)
        surf.blit(panel, (220, 272))
        board = load_scores()["scores"][self.score_diff]
        draw_text(surf, "HIGH SCORES", 440, 316, 30, GOLD)
        draw_text(surf, "DIFFICULTY", 770, 320, 13, (200, 205, 225), outline=False, align="right")
        for n, (key, title, unit, _) in enumerate(RECORDS):
            x, y = 240 + (n % 2) * 410, 336 + (n // 2) * 62
            pygame.draw.rect(surf, (22, 28, 60), (x, y, 392, 54), border_radius=10)
            pygame.draw.rect(surf, (110, 120, 160), (x, y, 392, 54), 2, border_radius=10)
            draw_text(surf, title, x + 12, y + 17, 12, (200, 205, 225), outline=False, align="left")
            rec = board["records"].get(key)
            if rec:
                shown = unit[:-1] if rec["value"] == 1 and unit.endswith("s") else unit
                draw_text(surf, f"{rec['value']} {shown}", x + 12, y + 44, 22, GOLD, align="left")
                draw_text(surf, rec["detail"], x + 380, y + 44, 11, (190, 195, 215), outline=False, align="right")
            else:
                draw_text(surf, "--", x + 12, y + 44, 22, (120, 128, 150), align="left")
        t = board["totals"]
        line = (f"GAMES {t.get('games', 0)}    WINS {t.get('wins', 0)}    LOSSES {t.get('losses', 0)}    TIES {t.get('ties', 0)}"
                f"    RUNS {t.get('runs', 0)}    HITS {t.get('hits', 0)}    HOME RUNS {t.get('hr', 0)}")
        draw_text(surf, line, 640, 624, 14, WHITE)
        hover = self.clear_scores_rect.collidepoint(self.mouse)
        pygame.draw.rect(surf, (150, 50, 50) if self.clear_armed > 0 else (60, 70, 110) if hover else (34, 42, 80), self.clear_scores_rect, border_radius=8)
        pygame.draw.rect(surf, (110, 120, 160), self.clear_scores_rect, 2, border_radius=8)
        draw_text(surf, "CLICK AGAIN TO CLEAR" if self.clear_armed > 0 else f"CLEAR {self.score_diff.upper()} RECORDS", self.clear_scores_rect.centerx,
                  self.clear_scores_rect.centery + 5, 11)
        box = self.score_box
        pygame.draw.rect(surf, TEAL, box, border_radius=10)
        pygame.draw.rect(surf, WHITE, box, 2, border_radius=10)
        draw_text(surf, self.score_diff.upper(), box.centerx - 10, box.centery + 8, 20)
        arrow = [(box.right - 30, box.centery - 5), (box.right - 14, box.centery - 5), (box.right - 22, box.centery + 6)]
        pygame.draw.polygon(surf, WHITE, [(x, y) if not self.score_open else (x, 2 * box.centery - y) for x, y in arrow])
        if self.score_open:                                  # the list, drawn last so it sits on top of the cards
            for name, rect in self.score_items.items():
                selected, hover = name == self.score_diff, rect.collidepoint(self.mouse)
                pygame.draw.rect(surf, (20, 140, 150) if selected else (70, 82, 128) if hover else (26, 34, 70), rect, border_radius=8)
                pygame.draw.rect(surf, WHITE if selected else (130, 140, 180), rect, 2, border_radius=8)
                draw_text(surf, name.upper(), rect.centerx, rect.centery + 8, 20)
        draw_text(surf, "Press ESC or click EXHIBITION to go back", 640 - self.DX, 714, 12, (190, 195, 215))


# =============================================================================
# HIGH SCORES  -  records kept between games (saved next to the game file)
# =============================================================================

SCORES_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "flash_baseball_scores.json")
# (key, title, unit, better) - "high" = bigger is better, "low" = smaller is better
RECORDS = [("most_runs", "MOST RUNS IN A GAME", "runs", "high"),
           ("biggest_diff", "BIGGEST WIN MARGIN", "runs", "high"),
           ("longest_hr", "LONGEST HOME RUN", "ft", "high"),
           ("most_hr", "MOST HOME RUNS IN A GAME", "HR", "high"),
           ("most_hits", "MOST HITS IN A GAME", "hits", "high"),
           ("most_perfect", "MOST PERFECT SWINGS IN A GAME", "swings", "high"),
           ("best_streak", "LONGEST HOT STREAK", "swings", "high"),
           ("fewest_allowed", "FEWEST RUNS ALLOWED IN A WIN", "runs", "low")]


def load_scores():
    """{"scores": {"Easy": {"records": {...}, "totals": {...}}, "Medium": ..., "Hard": ...}} - every difficulty keeps its own board."""
    data = {}
    try:
        with open(SCORES_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError):
        pass
    if not isinstance(data, dict):
        data = {}
    scores = data.get("scores") if isinstance(data.get("scores"), dict) else {}
    if "records" in data and not scores:                     # an older file (one board for everything): sort its records by difficulty
        for key, rec in data["records"].items():
            parts = [p.strip() for p in str(rec.get("detail", "")).split("|")]
            diff = parts[1] if len(parts) > 1 and parts[1] in DIFFICULTIES else "Medium"
            scores.setdefault(diff, {"records": {}, "totals": {}})["records"][key] = rec
        if data.get("totals"):
            scores.setdefault("Medium", {"records": {}, "totals": {}})["totals"] = data["totals"]
    for diff in DIFFICULTIES:
        board = scores.setdefault(diff, {})
        board.setdefault("records", {})
        board.setdefault("totals", {})
    return {"scores": scores}


def save_scores(data):
    try:
        with open(SCORES_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
    except OSError:
        pass


def record_game(game):
    """Called once when a game ends: update the records + lifetime totals for the difficulty it was played on."""
    data = load_scores()
    board = data["scores"][game.difficulty]
    st, runs, cpu = game.stats, game.runs, game.cpu_runs
    detail = f"{game.team_name[:12]} {runs}-{cpu}  |  {game.difficulty}  |  {game.innings} inn"
    values = {"most_runs": runs, "longest_hr": st["long_hr"], "most_hr": st["hr"], "most_hits": st["hits"],
              "most_perfect": st["perfect"], "best_streak": st["best_streak"]}
    if runs > cpu:
        values["biggest_diff"] = runs - cpu
        values["fewest_allowed"] = cpu
    for key, _, _, better in RECORDS:
        if key not in values or (key == "longest_hr" and not values[key]):
            continue
        old = board["records"].get(key)
        v = values[key]
        if old is None or (v > old["value"] if better == "high" else v < old["value"]):
            board["records"][key] = {"value": v, "detail": detail}
    t = board["totals"]
    for key, add in (("games", 1), ("wins", runs > cpu), ("losses", runs < cpu), ("ties", runs == cpu),
                     ("runs", runs), ("hr", st["hr"]), ("hits", st["hits"])):
        t[key] = t.get(key, 0) + int(add)
    save_scores(data)

# =============================================================================
# TEAM-NAME FILTER  -  blocks cuss words and names like ADMIN (paste-in add-on)
# =============================================================================
import re

RESERVED_NAMES = {"ADMIN", "ADMINISTRATOR", "ADMINS", "MOD", "MODS", "MODERATOR", "ROOT", "SYSTEM", "SYSADMIN",
                  "OWNER", "DEV", "DEVS", "DEVELOPER", "STAFF", "OFFICIAL", "SUPPORT", "CPU", "NULL", "NONE",
                  "UNDEFINED", "ITCH", "ITCHIO", "SERVER", "CONSOLE"}
# blocked anywhere in the name, even squashed together ("XFUCKX", "F.U.C.K", "FUUUCK")
BLOCKED_PARTS = ("FUCK", "SHIT", "BITCH", "CUNT", "PUSSY", "WHORE", "SLUT", "FAGG", "NIGG", "RETARD", "PENIS",
                 "VAGINA", "PORN", "NAZI", "HITLER", "TWAT", "WANK", "BASTARD", "ASSHOLE", "JIZZ", "DILDO", "BOOB")
# blocked only as a separate word, so BASS, GRAPE, GAMECOCKS, HELLCATS are still fine
BLOCKED_WORDS = {"ASS", "ASSES", "CUM", "SEX", "SEXY", "COCK", "COCKS", "DICK", "DICKS", "RAPE", "TIT", "TITS",
                 "HO", "HOE", "HOES", "DAMN", "HELL", "KKK", "FAG", "WTF", "STFU", "GTFO", "MILF"}
LEET = str.maketrans("0134578", "OIEASTB")          # 5H1T -> SHIT, 4DM1N -> ADMIN


def name_problem(name):
    """'' if the team name is fine, otherwise a short message saying why it isn't."""
    text = str(name).upper().translate(LEET)
    words = re.findall(r"[A-Z]+", text)
    squashed = "".join(words)
    deduped = re.sub(r"(.)\1+", r"\1", squashed)    # FUUUCK -> FUCK
    if squashed in RESERVED_NAMES or deduped in RESERVED_NAMES:
        return "That name is reserved - pick another!"
    if any(p in squashed or p in deduped for p in BLOCKED_PARTS) or any(w in BLOCKED_WORDS for w in words):
        return "Keep it clean - pick another name!"
    return ""


_menu_init, _menu_event, _menu_update, _menu_draw = Menu.__init__, Menu.handle_event, Menu.update, Menu.draw


def _filtered_init(self):
    _menu_init(self)
    self.name_error, self.name_error_t = "", 0.0
    if name_problem(self.name):                     # a bad name saved from an earlier version doesn't come back
        self.name = DEFAULT_TEAM_NAME


def _filtered_event(self, event, to_canvas):
    start = _menu_event(self, event, to_canvas)
    if start:
        problem = name_problem(self.team_name)
        if problem:                                 # PLAY BALL / ENTER only works with an allowed name
            self.name_error, self.name_error_t = problem, 2.5
            return False
    return start


def _filtered_update(self, dt):
    _menu_update(self, dt)
    self.name_error_t = max(0.0, self.name_error_t - dt)


def _filtered_draw(self, surf):
    _menu_draw(self, surf)
    if self.screen == "home" and self.name_error_t > 0:
        draw_text(surf, self.name_error, 540 + self.DX, 392, 12, RED)    # red message just under the name box


Menu.__init__, Menu.handle_event, Menu.update, Menu.draw = _filtered_init, _filtered_event, _filtered_update, _filtered_draw


# =============================================================================
# SAVING PROGRESS  +  LOCKED ANIMATIONS  +  HOME RUN DERBY   (paste-in add-on)
# =============================================================================
import base64

# --- 1. SAVING ------------------------------------------------------------------
# In the browser (itch.io / pygbag) files do NOT survive closing the tab, but localStorage does. pygbag exposes it as
# platform.window.localStorage. On your computer that doesn't exist, so the same functions fall back to plain files.
STORAGE_PREFIX = "flash_baseball."
_HERE = os.path.dirname(os.path.abspath(__file__))
STORAGE_FILES = {"settings": SETTINGS_FILE, "scores": SCORES_FILE,
                 "unlocks": os.path.join(_HERE, "flash_baseball_unlocks.json"),
                 "derby": os.path.join(_HERE, "flash_baseball_derby.json"),
                 "logo": os.path.join(_HERE, "flash_baseball_logo.b64")}


def _browser_storage():
    """The browser's localStorage, or None when not running in a browser."""
    try:
        import platform
        return platform.window.localStorage
    except Exception:
        return None


def storage_get(name):
    """The saved text for `name`, or None."""
    box = _browser_storage()
    if box is not None:
        try:
            value = box.getItem(STORAGE_PREFIX + name)
            return None if value is None else str(value)
        except Exception:
            return None
    try:
        with open(STORAGE_FILES[name], "r", encoding="utf-8") as f:
            return f.read()
    except OSError:
        return None


def storage_set(name, text):
    box = _browser_storage()
    if box is not None:
        try:
            box.setItem(STORAGE_PREFIX + name, text)
        except Exception:
            pass                                             # storage blocked / full: the game still works, it just won't remember
        return
    try:
        with open(STORAGE_FILES[name], "w", encoding="utf-8") as f:
            f.write(text)
    except OSError:
        pass


def read_json(name, default):
    text = storage_get(name)
    if not text:
        return default
    try:
        return json.loads(text)
    except ValueError:
        return default


def write_json(name, data):
    storage_set(name, json.dumps(data))


def load_scores():
    """{"scores": {"Easy": {"records": {...}, "totals": {...}}, ...}} - every difficulty keeps its own board."""
    data = read_json("scores", {})
    if not isinstance(data, dict):
        data = {}
    scores = data.get("scores") if isinstance(data.get("scores"), dict) else {}
    if "records" in data and not scores:                     # an older file (one board for everything): sort its records by difficulty
        for key, rec in data["records"].items():
            parts = [p.strip() for p in str(rec.get("detail", "")).split("|")]
            diff = parts[1] if len(parts) > 1 and parts[1] in DIFFICULTIES else "Medium"
            scores.setdefault(diff, {"records": {}, "totals": {}})["records"][key] = rec
        if data.get("totals"):
            scores.setdefault("Medium", {"records": {}, "totals": {}})["totals"] = data["totals"]
    for diff in DIFFICULTIES:
        board = scores.setdefault(diff, {})
        board.setdefault("records", {})
        board.setdefault("totals", {})
    return {"scores": scores}


def save_scores(data):
    write_json("scores", data)


def save_logo(surface):
    """Your drawn logo, stored as text (48x48 RGBA bytes -> base64, about 12 KB)."""
    try:
        to_bytes = getattr(pygame.image, "tobytes", None) or pygame.image.tostring
        storage_set("logo", base64.b64encode(to_bytes(surface, "RGBA")).decode("ascii"))
    except Exception:
        pass


def load_logo():
    text = storage_get("logo")
    if not text:
        return None
    try:
        raw = base64.b64decode(text)
        if len(raw) != LOGO_PX * LOGO_PX * 4:
            return None
        from_bytes = getattr(pygame.image, "frombytes", None) or pygame.image.fromstring
        return from_bytes(raw, (LOGO_PX, LOGO_PX), "RGBA").convert_alpha()
    except Exception:
        return None


def _menu_load_settings(self):
    """Bring back the team name, color, difficulty and innings from last time (anything missing or invalid is ignored)."""
    data = read_json("settings", None)
    if not isinstance(data, dict):
        return
    name = data.get("team_name")
    if isinstance(name, str) and name.strip():
        self.name = name[:MAX_NAME_LENGTH]
    labels = [label for label, _ in TEAM_COLORS]
    if data.get("team_color") in labels:
        self.color_index = labels.index(data["team_color"])
    if data.get("difficulty") in DIFFICULTIES:
        self.difficulty = data["difficulty"]
    if data.get("innings") in INNING_OPTIONS:
        self.innings = data["innings"]
    if data.get("weather") in WEATHER_OPTIONS:
        self.weather_choice = data["weather"]


def _menu_save_settings(self):
    write_json("settings", {"team_name": self.name, "team_color": TEAM_COLORS[self.color_index][0],
                            "difficulty": self.difficulty, "innings": self.innings, "bat_choice": self.bat_choice,
                            "weather": self.weather_choice})


def _menu_logo_for_game(self):
    """The finished logo for the game (and saves your drawing so it is here next time)."""
    if self.logo_drawn:
        save_logo(self.logo)
        return compose_logo(self.logo, self.team_color)
    storage_set("logo", "")                                  # you cleared it: forget the old one
    return build_default_logo(self.team_name, self.team_color)


_menu_init_before_saving = Menu.__init__


def _menu_init_with_saved_logo(self):
    _menu_init_before_saving(self)
    logo = load_logo()
    if logo is not None:
        self.logo, self.logo_drawn = logo, True


Menu.load_settings, Menu.save_settings, Menu.logo_for_game = _menu_load_settings, _menu_save_settings, _menu_logo_for_game
Menu.__init__ = _menu_init_with_saved_logo


# --- 2. LOCKED ANIMATIONS ----------------------------------------------------------
UNLOCK_ALL_FOR_TESTING = False                               # True = nothing is locked (handy while you are testing)
ANIM_NAMES = [a[0] for a in ANIMATIONS]
UNLOCK_HINTS = {
    "Slugger Cutscene": "Hit a PERFECT PERFECT home run",
    "Diving Stop": "Hit a ground ball that gets a diving stop",
    "Leaping Catch": "Hit a fly ball that a fielder leaps to catch",
    "Broken Bat": "Make weak contact and snap your bat",
    "Fan Catch": "Hit a home run that a fan catches",
    "Scoreboard Hit": "Hit a home run off the scoreboard",
    "Robbed at the Wall": "Have a short home run stolen at the wall",
    "Bat Flip": "Hit a monster home run and flip the bat",
    "On Fire": "Get " + str(ON_FIRE_STREAK) + " good swings in a row",
    "Close Play: Safe": "Beat a close tag at a base",
    "Close Play: Out": "Get tagged out on a close play",
}
UNLOCKED = set()
UNLOCK_TOAST = {"name": "", "t": 0.0}


def load_unlocks():
    saved = read_json("unlocks", [])
    UNLOCKED.clear()
    if isinstance(saved, list):
        UNLOCKED.update(n for n in saved if n in ANIM_NAMES)


def is_unlocked(name):
    return UNLOCK_ALL_FOR_TESTING or name in UNLOCKED


def unlock_all():
    for n in ANIM_NAMES:
        UNLOCKED.add(n)
    write_json("unlocks", sorted(UNLOCKED))
    UNLOCK_TOAST["name"], UNLOCK_TOAST["t"] = "ALL ANIMATIONS", 3.6


def unlock(name):
    """Unlock an animation (only does anything the first time) and show the banner."""
    if name in UNLOCKED or name not in ANIM_NAMES:
        return
    UNLOCKED.add(name)
    write_json("unlocks", sorted(UNLOCKED))
    UNLOCK_TOAST["name"], UNLOCK_TOAST["t"] = name, 3.6


def draw_lock(surf, cx, cy, s, color=(150, 158, 185)):
    """A little padlock."""
    width = max(2, int(4 * s))
    pygame.draw.arc(surf, color, (int(cx - 10 * s), int(cy - 26 * s), int(20 * s), int(26 * s)), 0, math.pi, width)
    pygame.draw.rect(surf, color, (int(cx - 14 * s), int(cy - 8 * s), int(28 * s), int(22 * s)), border_radius=max(1, int(4 * s)))
    pygame.draw.circle(surf, (24, 28, 52), (int(cx), int(cy + 1 * s)), max(2, int(3.5 * s)))
    pygame.draw.rect(surf, (24, 28, 52), (int(cx - s), int(cy + 1 * s), max(2, int(2 * s)), int(7 * s)))


def draw_unlock_toast(surf):
    t = UNLOCK_TOAST["t"]
    slide = min(1.0, (3.6 - t) / 0.35, t / 0.35)                # slides up, waits, slides away
    y = 740 - 112 * clamp(slide, 0, 1)
    pygame.draw.rect(surf, (20, 26, 58), (390, y, 500, 76), border_radius=14)
    pygame.draw.rect(surf, GOLD, (390, y, 500, 76), 3, border_radius=14)
    draw_lock(surf, 428, y + 40, 0.9, GOLD)
    draw_text(surf, "ANIMATION UNLOCKED!", 460, y + 30, 18, GOLD, align="left")
    draw_text(surf, UNLOCK_TOAST["name"], 460, y + 60, 22, WHITE, align="left")


def _track_make_contact(original):
    def make_contact(self, quality, raw_error):
        original(self, quality, raw_error)
        if self.is_derby:
            return
        if self.state == "HR_CUTSCENE":
            unlock("Slugger Cutscene")
        if self.hit and self.hit.broken_bat:
            unlock("Broken Bat")
    return make_contact


def _track_update_rare(original):
    def update_rare(self, dt, allow_trigger=True):
        original(self, dt, allow_trigger)
        if not self.is_derby and self.fp:
            if self.fp.dive:
                unlock("Diving Stop")
            if self.fp.leap:
                unlock("Leaping Catch")
    return update_rare


def _track_home_run(original):
    def home_run(self):
        if not self.is_derby and self.hit:
            if self.hit.robbed:
                unlock("Robbed at the Wall")
            else:
                if self.fan:
                    unlock("Fan Catch")
                if self.board_hit:
                    unlock("Scoreboard Hit")
                if self.hit.flip:
                    unlock("Bat Flip")
        original(self)
    return home_run


def _track_swing(original):
    def swing(self):
        original(self)
        if not self.is_derby and self.streak >= ON_FIRE_STREAK:
            unlock("On Fire")
    return swing


def _track_close_result(original):
    def close_result(self, base, out):
        original(self, base, out)
        c = self.fp.close if self.fp else None
        if c and c["result"] and not self.is_derby:
            unlock("Close Play: Out" if c["result"] == "out" else "Close Play: Safe")
    return close_result


def _toast_update(original):
    def update(self, dt):
        original(self, dt)
        if not self.paused:
            UNLOCK_TOAST["t"] = max(0.0, UNLOCK_TOAST["t"] - dt)
    return update


def _toast_draw(original):
    def draw(self, canvas):
        original(self, canvas)
        if UNLOCK_TOAST["t"] > 0 and not self.paused:
            draw_unlock_toast(canvas)
    return draw


def _gallery_draw(self, surf):
    """The Animations gallery, with a lock on every animation you haven't triggered in an exhibition game yet."""
    surf.fill((12, 16, 36))
    draw_text(surf, "ANIMATIONS", 640, 88, 46, GOLD)
    got = sum(1 for a in ANIMATIONS if is_unlocked(a[0]))
    draw_text(surf, f"UNLOCKED {got} / {len(ANIMATIONS)}   -   find them in an exhibition game!", 640, 118, 15, (200, 205, 225), outline=False)
    first = self.gallery_page() * ANIM_PAGE
    for i, (rect, (name, _, _)) in enumerate(zip(self.gallery_rects(), ANIMATIONS[first:]), start=first):
        selected, locked = i == self.anim_index, not is_unlocked(name)
        pygame.draw.rect(surf, (TEAL if selected else (34, 42, 80)) if not locked else ((70, 78, 110) if selected else (26, 30, 56)), rect, border_radius=10)
        pygame.draw.rect(surf, WHITE if selected else (110, 120, 160), rect, 2, border_radius=10)
        size = 20 if rect.height >= 56 else 17
        draw_text(surf, f"{i + 1}. {'???' if locked else name}", rect.x + 18, rect.centery + size * 0.4, size,
                  (160, 166, 190) if locked else WHITE, align="left")
        if locked:
            draw_lock(surf, rect.right - 34, rect.centery + 4, 0.8)
    name, info, duration = ANIMATIONS[self.anim_index]
    cx = self.PREVIEW_RECT.centerx
    if is_unlocked(name):
        t = min(self.anim_clock % (duration + 0.8), duration)             # plays, pauses a moment, loops
        scene = self.preview_scene
        (self.scene_slugger, self.scene_dive, self.scene_leap, self.scene_broken_bat,
         self.scene_fan, self.scene_board, self.scene_robbed, self.scene_flip, self.scene_fire,
         lambda sc, tt: self.scene_close(sc, tt, "safe"), lambda sc, tt: self.scene_close(sc, tt, "out"))[self.anim_index](scene, t)
        surf.blit(pygame.transform.smoothscale(scene, self.PREVIEW_RECT.size), self.PREVIEW_RECT.topleft)
        title, line = name, info
    else:
        pygame.draw.rect(surf, (16, 20, 44), self.PREVIEW_RECT)
        draw_lock(surf, cx, self.PREVIEW_RECT.centery - 10, 3.6)
        draw_text(surf, "LOCKED", cx, self.PREVIEW_RECT.centery + 90, 40, (170, 176, 200))
        title, line = "???", "To unlock: " + UNLOCK_HINTS.get(name, "play an exhibition game")
    pygame.draw.rect(surf, WHITE, self.PREVIEW_RECT.inflate(8, 8), 3)
    draw_text(surf, title, cx, 590, 26, GOLD)
    draw_text(surf, line, cx, 620, 16)
    self.draw_pause_button(surf, self.BACK_RECT, "BACK", False)
    self.draw_pause_button(surf, self.PREV_RECT, "<", False)
    self.draw_pause_button(surf, self.NEXT_RECT, ">", False)
    draw_text(surf, f"PAGE {self.gallery_page() + 1}/{self.gallery_pages()}", 365, 636, 20, WHITE)
    draw_text(surf, "UP/DOWN: choose   LEFT/RIGHT: page   ENTER or click window: replay   BACKSPACE: back   P: resume", cx, 690, 13, (200, 205, 225))


Game.is_derby = False
Game.make_contact = _track_make_contact(Game.make_contact)
Game.update_rare = _track_update_rare(Game.update_rare)
Game.home_run = _track_home_run(Game.home_run)
Game.swing = _track_swing(Game.swing)
Game.close_result = _track_close_result(Game.close_result)
Game.update = _toast_update(Game.update)
Game.draw = _toast_draw(Game.draw)
Game.draw_gallery = _gallery_draw


# --- 3. HOME RUN DERBY ------------------------------------------------------------
DERBY_OUTS = 10                                              # the derby ends after this many outs
# chance a swing of each quality leaves the yard (a PERFECT PERFECT swing is always a homer). Power hitters / heavy bats add to it.
DERBY_HR_CHANCE = {"perfect_perfect": 1.0, "perfect": 0.82, "good": 0.40, "weak": 0.07}
DERBY_DISTANCE = {"perfect_perfect": (430, 560), "perfect": (380, 470), "good": (350, 430), "weak": (350, 385)}   # feet
DERBY_TIME = 75.0                                            # seconds on the clock (like the MLB The Show derby: it is timed, not outs)
DERBY_BONUS_TIME = 15.0                                      # two homers over DERBY_LONG_FT earn this much extra time
DERBY_LONG_FT = 450
DERBY_REPLAY_FT = 450                                        # a homer this long can get a drone replay...
DERBY_REPLAY_CHANCE = 1 / 3                                  # ...about one time in three
REPLAY_IMPACT, REPLAY_FLIGHT, REPLAY_HOLD = 1.7, 4.6, 0.9    # seconds: the bat hits the ball (slow motion), the drone follows it, the result holds
DERBY_PITCH_SLOWDOWN = 1.12                                  # batting-practice pitches are a bit slower than game pitches
DERBY_MESSAGE_TIME = 1.2                                     # results pop up and move on by themselves (no NEXT PITCH button)
DERBY_BATTER = 3                                             # who bats: an index into LINEUP (3 = T. Okafor, the slugger)


DERBY_FIRST = ["J.", "M.", "D.", "T.", "R.", "K.", "L.", "P.", "S.", "A.", "C.", "B.", "E.", "N.", "G.", "H."]
DERBY_LAST = ["Alvarez", "Chen", "Brooks", "Okafor", "Santos", "Nakamura", "Murphy", "Dubois", "Kowalski", "Ramirez", "Johnson",
              "Tanaka", "Fischer", "Oyelaran", "Bennett", "Castillo", "Moreau", "Larsen", "Singh", "Delgado", "Park", "Walker"]
DERBY_RANKS = [(0, "BATBOY", (150, 150, 160)), (3, "ROOKIE", (205, 130, 70)), (6, "ALL-STAR", (200, 205, 225)),
               (9, "SLUGGER", (255, 205, 60)), (12, "LEGEND", (120, 230, 255))]
MONEY_VALUE = 2                                              # the money ball is worth this many home runs
DERBY_CARD_RECTS = [pygame.Rect(245 + i * 270, 340, 250, 300) for i in range(3)]      # (in the menu panel's space)


def make_derby_hitters():
    """Three random hitters to choose from: a contact hitter (easy to time), a balanced one and a slugger (hits it farthest)."""
    tiers = [("CONTACT", (0.86, 0.97), (1.10, 1.18), (1.00, 1.18)),
             ("BALANCED", (1.03, 1.12), (1.00, 1.06), (0.90, 1.08)),
             ("SLUGGER", (1.20, 1.34), (0.88, 0.95), (0.80, 0.95))]
    random.shuffle(tiers)
    firsts, lasts = random.sample(DERBY_FIRST, 3), random.sample(DERBY_LAST, 3)
    nums = random.sample(range(1, 100), 3)
    skins = random.sample(SKIN_TONES, 3) if len(SKIN_TONES) >= 3 else [random.choice(SKIN_TONES) for _ in range(3)]
    out = []
    for i, (tier, pw, ct, sp) in enumerate(tiers):
        out.append(dict(name=f"{firsts[i]} {lasts[i]}", num=nums[i], power=round(random.uniform(*pw), 2), contact=round(random.uniform(*ct), 2),
                        speed=round(random.uniform(*sp), 2), skin=skins[i], bat=random.randrange(len(BAT_STYLES)), tier=tier,
                        ab=0, h=0, hr=0))
    return out


def draw_derby_pick(menu, surf):
    """The hitter select screen (drawn in the panel's space): three random hitters with different power."""
    panel = pygame.Surface((840, 424), pygame.SRCALPHA)
    pygame.draw.rect(panel, (10, 14, 34, 220), panel.get_rect(), border_radius=18)
    pygame.draw.rect(panel, (255, 255, 255, 60), panel.get_rect(), 2, border_radius=18)
    surf.blit(panel, (220, 272))
    draw_text(surf, "HOME RUN DERBY", 640, 308, 26, GOLD)
    draw_text(surf, "Pick your hitter  -  10 outs, then one MONEY BALL worth 2 HR", 640, 330, 13, (200, 205, 225), outline=False)
    tier_color = {"CONTACT": (110, 198, 255), "BALANCED": (200, 205, 225), "SLUGGER": (255, 150, 60)}
    for n, (rect, h) in enumerate(zip(DERBY_CARD_RECTS, menu.derby_choices)):
        hover = rect.collidepoint(menu.mouse)
        r = rect.inflate(8, 8) if hover else rect
        pygame.draw.rect(surf, (36, 46, 96) if hover else (22, 28, 60), r, border_radius=14)
        pygame.draw.rect(surf, GOLD if hover else (110, 120, 160), r, 3 if hover else 2, border_radius=14)
        cx = rect.centerx
        draw_text(surf, h["tier"], cx, rect.y + 24, 16, tier_color[h["tier"]])
        pygame.draw.ellipse(surf, (28, 60, 36), (cx - 46, rect.y + 192, 92, 18))
        draw_person(surf, cx, rect.y + 206, 3.4 + (0.15 if hover else 0), (240, 240, 240), menu.team_color, skin=h["skin"], shadow=False)
        bat = BAT_STYLES[h["bat"]]
        pygame.draw.line(surf, bat["body"], (cx + 34, rect.y + 168), (cx + 62, rect.y + 96), 6)         # his bat, leaning on his shoulder
        pygame.draw.line(surf, bat["handle"] or bat["body"], (cx + 34, rect.y + 168), (cx + 40, rect.y + 152), 6)
        draw_text(surf, h["name"].upper(), cx, rect.y + 232, 18)
        draw_text(surf, f"#{h['num']}", cx, rect.y + 250, 12, (200, 205, 225), outline=False)
        for k, (label, value) in enumerate((("POWER", h["power"] * bat["power"]), ("TIMING", h["contact"] * bat["window"]))):
            py = rect.y + 266 + k * 16
            draw_text(surf, label, rect.x + 22, py + 8, 10, (200, 205, 225), outline=False, align="left")
            for i in range(5):
                pygame.draw.rect(surf, GOLD if i < pips(value) else (70, 76, 98), (rect.x + 92 + i * 26, py, 22, 9), border_radius=2)
        draw_text(surf, str(n + 1), rect.x + 14, rect.y + 20, 14, (150, 156, 180), outline=False)
    draw_text(surf, "Click a hitter (or press 1, 2, 3)   |   ESC: back", 640, 668, 13, (190, 195, 215))


def derby_rank(hr):
    name, color = DERBY_RANKS[0][1], DERBY_RANKS[0][2]
    for need, n, c in DERBY_RANKS:
        if hr >= need:
            name, color = n, c
    return name, color


def load_derby_record():
    rec = dict(best_hr=0, longest=0, best_streak=0, games=0, total_hr=0, money_hits=0)
    saved = read_json("derby", {})
    if isinstance(saved, dict):
        rec.update({k: v for k, v in saved.items() if k in rec and isinstance(v, int)})
    return rec


def fmt_time(t):
    t = max(0, int(math.ceil(t)))
    return f"{t // 60}:{t % 60:02d}"


def replay_landing(sideways, feet):
    """Where a replay home run comes down: the 300s to low 400s land in the front rows of the seats, the 400s to low 500s fly farther up
    into the stands, and anything over 500 ft clears the stadium altogether."""
    a_l, a_r = math.atan2(U_LEFT[0], -U_LEFT[1]), math.atan2(U_RIGHT[0], -U_RIGHT[1])
    a = a_l + clamp((sideways + 300) / 600, 0.04, 0.96) * (a_r - a_l)
    if feet <= 420:
        frac = 0.86 + clamp(feet - 350, 0, 70) / 70 * 0.06
    elif feet <= 500:
        frac = 1.0 + (feet - 420) / 80 * 0.38
    else:
        frac = 1.62 + clamp(feet - 500, 0, 80) / 80 * 0.45
    d = SPRAY_MAX_PX * frac
    return HOME[0] + math.sin(a) * d, HOME[1] - math.cos(a) * d


def draw_aerial_field(surf, cam, scale, t):
    """A drone's-eye view of the park (used by the replay): field coordinates are mapped so `cam` is at the middle of the screen."""
    W, H = surf.get_size()
    def pt(px, py):
        return (W / 2 + (px - cam[0]) * scale, H / 2 + (py - cam[1]) * scale)
    a_l, a_r = math.atan2(U_LEFT[0], -U_LEFT[1]), math.atan2(U_RIGHT[0], -U_RIGHT[1])
    def arc(frac, n=36):
        return [pt(HOME[0] + math.sin(a_l + (a_r - a_l) * i / n) * SPRAY_MAX_PX * frac, HOME[1] - math.cos(a_l + (a_r - a_l) * i / n) * SPRAY_MAX_PX * frac)
                for i in range(n + 1)]
    surf.fill((12, 18, 30))
    pygame.draw.polygon(surf, (50, 54, 72), [pt(*HOME)] + arc(1.45))                                      # the stands
    rnd = random.Random(11)
    for _ in range(500):                                                                                   # fans
        a = rnd.uniform(a_l, a_r)
        r = rnd.uniform(0.88, 1.42) * SPRAY_MAX_PX
        x, y = pt(HOME[0] + math.sin(a) * r, HOME[1] - math.cos(a) * r)
        surf.fill(rnd.choice(((200, 70, 70), (230, 200, 80), (90, 130, 220), (230, 230, 240), (120, 120, 140))), (x, y, 4, 4))
    pygame.draw.polygon(surf, (30, 82, 52), [pt(*HOME)] + arc(SPRAY_FENCE + 0.04))                        # the wall
    pygame.draw.polygon(surf, (176, 124, 76), [pt(*HOME)] + arc(SPRAY_FENCE))                             # warning track
    for i, frac in enumerate((0.80, 0.72, 0.64, 0.56, 0.48, 0.40, 0.32)):                                  # mown stripes
        pygame.draw.polygon(surf, (52, 138, 60) if i % 2 == 0 else (44, 120, 52), [pt(*HOME)] + arc(frac))
    square = [pt(*BASES[k]) for k in range(4)]
    pygame.draw.polygon(surf, (176, 124, 76), square)
    mid = (sum(b[0] for b in BASES[:4]) / 4, sum(b[1] for b in BASES[:4]) / 4)
    pygame.draw.polygon(surf, (50, 130, 58), [pt(mid[0] + (b[0] - mid[0]) * 0.62, mid[1] + (b[1] - mid[1]) * 0.62) for b in BASES[:4]])
    for ang in (a_l, a_r):
        pygame.draw.line(surf, WHITE, pt(*HOME), pt(HOME[0] + math.sin(ang) * SPRAY_MAX_PX * 1.5, HOME[1] - math.cos(ang) * SPRAY_MAX_PX * 1.5), 2)
    for b in BASES[1:4]:
        x, y = pt(*b)
        pygame.draw.rect(surf, WHITE, (x - 5 * scale, y - 5 * scale, 10 * scale, 10 * scale))
    mx, my = pt(*MOUND)
    pygame.draw.circle(surf, (190, 140, 90), (mx, my), max(3, int(8 * scale)))
    hx, hy = pt(*HOME)
    pygame.draw.polygon(surf, WHITE, [(hx - 5 * scale, hy), (hx + 5 * scale, hy), (hx + 5 * scale, hy + 5 * scale), (hx, hy + 10 * scale), (hx - 5 * scale, hy + 5 * scale)])


def draw_hr_replay(surf, t, rep, skin, team_color):
    """The drone replay of a monster home run. First the bat meets the ball in slow motion, then a drone follows the ball and the
    glowing trail it leaves. rep = dict(dist, sideways, mph, angle)."""
    W, H = surf.get_size()
    if t < REPLAY_IMPACT:                                                        # ---- the impact ----
        scene = pygame.Surface((W, H))
        scene.fill((8, 11, 24))
        rnd = random.Random(5)
        for _ in range(60):                                                      # out-of-focus stadium lights
            c = rnd.choice(((255, 240, 180), (255, 200, 120), (180, 210, 255)))
            glow = pygame.Surface((60, 60), pygame.SRCALPHA)
            pygame.draw.circle(glow, c + (40,), (30, 30), rnd.randint(8, 28))
            scene.blit(glow, (rnd.randrange(W), rnd.randrange(0, 420)))
        pygame.draw.rect(scene, (44, 110, 50), (0, 600, W, 120))
        pygame.draw.rect(scene, (176, 124, 76), (0, 640, W, 80))
        tc = 1.0
        u = clamp(t / tc, 0, 1)
        theta = math.radians(lerp(158, 48, u ** 0.85))
        P, L = (470.0, 650.0), 340.0
        tip = (P[0] + L * math.cos(theta), P[1] - L * math.sin(theta))
        C = (P[0] + L * math.cos(math.radians(48)), P[1] - L * math.sin(math.radians(48)))
        draw_real_bat(scene, P, tip, 30)
        pygame.draw.circle(scene, (235, 235, 235), P, 20)                         # his hands
        pygame.draw.circle(scene, (90, 90, 90), P, 20, 3)
        if t < tc:                                                               # the ball comes in
            bx, by = C[0] - 760 * (1 - u) ** 1.7, C[1] + 60 * (1 - u) ** 1.7
            pygame.draw.circle(scene, WHITE, (bx, by), 22)
            pygame.draw.circle(scene, (204, 51, 51), (bx, by), 22, 3)
            draw_text(scene, "BAT MEETS BALL", 640, 150, 30, GOLD)
        else:                                                                    # ...and leaves
            s = t - tc
            ang = math.radians(rep["angle"] + 22)
            d = 1400 * s ** 0.8
            bx, by = C[0] + d * math.cos(ang), C[1] - d * math.sin(ang)
            for k in range(8):                                                   # streak
                f = k / 8
                pygame.draw.circle(scene, (255, 255, int(200 + 55 * (1 - f))), (C[0] + d * f * math.cos(ang), C[1] - d * f * math.sin(ang)), int(4 + 18 * f))
            pygame.draw.circle(scene, WHITE, (bx, by), 22)
            pygame.draw.circle(scene, (204, 51, 51), (bx, by), 22, 3)
            if s < 0.35:                                                         # the flash and the shockwave
                for k in range(14):
                    a = k * 0.449
                    r0, r1 = 24 + s * 120, 80 + s * 520
                    pygame.draw.line(scene, (255, 245, 180), (C[0] + math.cos(a) * r0, C[1] + math.sin(a) * r0), (C[0] + math.cos(a) * r1, C[1] + math.sin(a) * r1), 6)
                pygame.draw.circle(scene, (255, 255, 255), C, int(30 + s * 600), 4)
            draw_text(scene, f"EXIT VELOCITY  {rep['mph']} MPH", 980, 230, 26, WHITE)
            draw_text(scene, f"LAUNCH ANGLE  {rep['angle']} DEG", 980, 266, 22, (200, 205, 225))
        off = (random.randint(-7, 7), random.randint(-7, 7)) if 1.0 <= t < 1.3 else (0, 0)
        surf.fill((0, 0, 0))
        surf.blit(scene, off)
    else:                                                                        # ---- the drone follows the ball ----
        s = t - REPLAY_IMPACT
        u = clamp(s / REPLAY_FLIGHT, 0, 1)
        ud = 1 - (1 - u) ** 1.35                                                 # the ball slows a little as it goes
        L_ = replay_landing(rep["sideways"], rep["dist"])
        out_of_park = rep["dist"] > 500
        kb = 1.25
        zoom = lerp(1.5, 0.72, smooth(u))
        scale = kb * zoom
        gx0, gy0 = HOME[0] + (L_[0] - HOME[0]) * ud, HOME[1] + (L_[1] - HOME[1]) * ud       # the drone hangs over the ball's ground point
        cam = (gx0, gy0 - 70 / scale)
        draw_aerial_field(surf, cam, scale, t)
        peak = lerp(150, 340, clamp((rep["dist"] - 380) / 200, 0, 1))
        def ground(uu):
            g = 1 - (1 - uu) ** 1.35
            return HOME[0] + (L_[0] - HOME[0]) * g, HOME[1] + (L_[1] - HOME[1]) * g
        def screen(uu):
            gx, gy = ground(uu)
            h = peak * math.sin(math.pi * uu) ** 0.85
            return (W / 2 + (gx - cam[0]) * scale, H / 2 + (gy - cam[1]) * scale - h * scale * 0.9), (W / 2 + (gx - cam[0]) * scale, H / 2 + (gy - cam[1]) * scale), h
        n = max(2, int(u * 70))
        glow = pygame.Surface((W, H), pygame.SRCALPHA)
        pts = [screen(u * i / n)[0] for i in range(n + 1)]
        for i in range(len(pts) - 1):                                           # the glowing trail
            f = i / max(1, len(pts) - 1)
            pygame.draw.line(glow, (90, 210, 255, int(60 + 120 * f)), pts[i], pts[i + 1], int(16 * f + 6))
            pygame.draw.line(glow, (255, 255, 255, int(120 + 135 * f)), pts[i], pts[i + 1], int(6 * f + 2))
        surf.blit(glow, (0, 0))
        bp, gp, h = screen(u)
        pygame.draw.ellipse(surf, (20, 60, 30), (gp[0] - 10, gp[1] - 4, 20, 8))                                # its shadow on the grass
        pygame.draw.line(surf, (255, 255, 255), bp, gp, 1)
        pygame.draw.circle(surf, WHITE, bp, int(6 + 6 * h / peak))
        pygame.draw.circle(surf, (204, 51, 51), bp, int(6 + 6 * h / peak), 2)
        if u >= 0.5:                                                             # the top of its arc
            ap = screen(0.5)[0]
            pygame.draw.circle(surf, GOLD, ap, 6, 2)
            draw_text(surf, "APEX", ap[0], ap[1] - 14, 12, GOLD)
        if u >= 1:                                                               # it lands in the seats (or is long gone)
            r = (s - REPLAY_FLIGHT) * 160
            pygame.draw.circle(surf, WHITE, gp, int(8 + r), 3)
            if out_of_park:
                draw_text(surf, "OUT OF THE PARK!", 640, 150, 46 + int(4 * math.sin(s * 9)), GOLD)
        shown = int(round(rep["dist"] * min(1.0, ud)))
        draw_text(surf, "DISTANCE", 640, 556, 16, (200, 205, 225))
        draw_text(surf, f"{shown} FT", 640, 616, 56 + (int(6 * math.sin(s * 10)) if u >= 1 else 0), GOLD if u >= 1 else WHITE)
        draw_text(surf, "DRONE CAM", 112, 108, 18, WHITE)
    shade = pygame.Surface((W, H), pygame.SRCALPHA)                              # the cinema bars, the REPLAY tag and a soft vignette
    pygame.draw.rect(shade, (0, 0, 0, 255), (0, 0, W, 64))
    pygame.draw.rect(shade, (0, 0, 0, 255), (0, H - 64, W, 64))
    for k in range(8):
        pygame.draw.rect(shade, (0, 0, 0, 18), (k * 6, 64 + k * 6, W - k * 12, H - 128 - k * 12), 6)
    surf.blit(shade, (0, 0))
    if int(t * 2) % 2 == 0:
        pygame.draw.circle(surf, RED, (60, 36), 8)
    draw_text(surf, "REPLAY", 150, 44, 22, WHITE, align="left") if False else draw_text(surf, "REPLAY", 70, 44, 22, WHITE, align="left")
    draw_text(surf, f"{rep['dist']} FT HOME RUN", W - 30, 44, 20, GOLD, align="right")


def draw_derby_board(surf, game):
    """The scoreboard during the derby: home runs, a little row of ten out-lights (or the MONEY BALL banner), and the streak."""
    money = getattr(game, "money_ball", False)
    pulse = 0.5 + 0.5 * math.sin(game.clock * 8)
    pygame.draw.rect(surf, (31, 35, 39), (290, 22, 190, 92), border_radius=6)
    pygame.draw.rect(surf, (255, int(180 + 60 * pulse), 40) if money else (102, 102, 102), (290, 22, 190, 92), 3 if money else 2, border_radius=6)
    draw_text(surf, "HR DERBY", 385, 41, 12, GOLD, outline=False)
    draw_text(surf, str(game.derby_hr), 385, 84, 40, (232, 232, 232), outline=False)
    draw_text(surf, "HR", 440, 80, 13, (200, 205, 225), outline=False)
    if game.derby_streak > 1:
        draw_text(surf, f"x{game.derby_streak}", 330, 80, 16, GOLD, outline=False)
    if money:
        draw_text(surf, f"MONEY BALL  +{MONEY_VALUE}", 385, 104, 12 + int(pulse * 2), (255, 215, 70), outline=False)
        return
    low = game.time_left < 10
    draw_text(surf, fmt_time(game.time_left), 345, 104, 15 + (int(pulse * 2) if low else 0), RED if low else (232, 232, 232), outline=False)
    frac = clamp(game.time_left / DERBY_TIME, 0, 1)
    pygame.draw.rect(surf, (60, 66, 80), (372, 98, 98, 8), border_radius=3)
    pygame.draw.rect(surf, RED if low else (90, 210, 130), (372, 98, int(98 * frac), 8), border_radius=3)
    draw_text(surf, f"{DERBY_LONG_FT}FT", 452, 46, 8, (200, 205, 225), outline=False)
    for i in range(2):                                                    # two homers over 450 ft = bonus time
        pygame.draw.circle(surf, GOLD if i < game.long_count else (150, 156, 170), (443 + i * 12, 58), 4, 0 if i < game.long_count else 1)
    if game.bonus_flash > 0:
        draw_text(surf, f"+{int(DERBY_BONUS_TIME)} SEC!", 385, 128, 18, GREEN)


_scoreboard_for_games = draw_bat_scoreboard


def draw_bat_scoreboard(surf, game):
    if getattr(game, "is_derby", False):
        draw_derby_board(surf, game)
    else:
        _scoreboard_for_games(surf, game)


class Derby(Game):
    """Home Run Derby (timed, like MLB The Show): one hitter you pick, batting-practice pitches right down the middle, and a clock.
    Two homers over 450 ft earn bonus time. When the clock hits zero you get one gold MONEY BALL: a single swing worth two home runs.
    Monster homers (450+ ft) sometimes get a drone replay."""
    is_derby = True
    hitter = None

    def configure(self, team_name, team_color, difficulty, innings, logo=None, bat_choice=None, weather_choice=None):
        previous = getattr(self, "weather_choice", "Random")
        weather = weather_choice if weather_choice is not None else previous
        super().configure(team_name, team_color, difficulty, 1, logo, bat_choice, "Night" if weather == "Random" else weather)

    def reset(self):
        super().reset()
        self.derby_outs = self.derby_hr = self.derby_streak = self.derby_best_streak = self.derby_longest = 0
        self.derby_new_record = False
        self.derby_prev = load_derby_record()
        self.money_ball, self.money_result, self.derby_log = False, None, []     # derby_log: [(distance, was_money_ball)]
        self.time_left, self.time_up, self.timer_on = DERBY_TIME, False, False   # the clock starts with the first pitch
        self.long_count, self.bonus_flash, self.replay, self.replay_then = 0, 0.0, None, None
        if self.hitter:                                                  # the hitter you picked (with his own bat)
            self.lineup[DERBY_BATTER] = dict(self.hitter, ab=0, h=0, hr=0)
            if self.bat_choice:
                self.lineup[DERBY_BATTER]["bat"] = self.bat_choice - 1
        self.set_batter(DERBY_BATTER)
        self.show_message("HOME RUN DERBY", f"{self.lineup[DERBY_BATTER]['name']} is up!  {int(DERBY_TIME)} seconds - two {DERBY_LONG_FT} ft homers add {int(DERBY_BONUS_TIME)}   Best: {self.derby_prev['best_hr']} HR", 3.0)

    # ---- the pitcher throws batting practice ----
    def choose_pitch(self):
        return random.choices(["Fastball", "Curveball"], weights=[70, 30])[0]

    def choose_zone(self):
        return 0                                                         # always right down the middle

    def start_pitch(self):
        super().start_pitch()
        self.timer_on = not self.money_ball                              # the clock runs from the first pitch
        self.pitch.duration *= DERBY_PITCH_SLOWDOWN
        self.pitch.mph = round(self.pitch.mph / DERBY_PITCH_SLOWDOWN)

    def end_at_bat(self):
        self.balls = self.strikes = 0                                    # (the same batter keeps hitting - no new batter each swing)

    def update(self, dt):
        if not self.paused:
            self.bonus_flash = max(0.0, self.bonus_flash - dt)
            if self.timer_on and not self.money_ball and self.state in ("WAIT", "WIND_UP", "PITCH", "BALL_IN_FLIGHT", "MESSAGE"):
                self.time_left = max(0.0, self.time_left - dt)
                if self.time_left <= 0:
                    self.time_up = True
        super().update(dt)
        if self.paused:
            return
        if self.state == "HR_REPLAY" and self.state_time >= REPLAY_IMPACT + REPLAY_FLIGHT + REPLAY_HOLD:
            self.end_replay()
        elif self.time_up and not self.money_ball and self.state == "WAIT":      # time!  ...one more swing
            self.timer_on = False
            self.show_message("TIME!", f"MONEY BALL! One swing, worth {MONEY_VALUE} home runs", 2.8, then=self.begin_money_ball)

    def press_swing(self):
        if self.state == "HR_REPLAY" and not self.paused:
            if self.state_time > 0.8:
                self.end_replay()                                        # click / SPACE skips the replay
            return
        super().press_swing()

    def start_replay(self):
        self.set_state("HR_REPLAY")

    def end_replay(self):
        after, self.replay_then = self.replay_then, None
        if after:
            after()
        else:
            self.set_state("WAIT")

    def draw(self, canvas):
        if self.state == "HR_REPLAY":
            draw_hr_replay(canvas, self.state_time, self.replay, self.skin, self.team_color)
        else:
            super().draw(canvas)

    def draw_bat_view(self, surf):
        BALL_GOLD[0] = self.money_ball and self.state in ("WIND_UP", "PITCH")
        try:
            super().draw_bat_view(surf)
        finally:
            BALL_GOLD[0] = False
        if self.money_ball and self.state in ("WAIT", "WIND_UP", "PITCH"):       # a golden glow around the hitter
            glow = pygame.Surface((170, 190), pygame.SRCALPHA)
            pygame.draw.ellipse(glow, (255, 205, 60, 45 + int(25 * math.sin(self.clock * 8))), (0, 0, 170, 190))
            surf.blit(glow, (230, 230))
            for i in range(10):
                a = self.clock * 2 + i * 0.63
                pygame.draw.circle(surf, (255, 235, 140), (315 + math.cos(a) * 62, 330 + math.sin(a * 1.3) * 78), 2)

    # ---- what a swing does ----
    def make_contact(self, quality, raw_error):
        power = self.lineup[self.batter_i]["power"] * CURRENT_BAT["power"]
        chance = clamp(DERBY_HR_CHANCE[quality] * (1 + (power - 1) * 0.8), 0.0, 1.0)
        if quality != "perfect_perfect" and random.random() >= chance:
            small = "Just short of the wall" if quality in ("perfect", "good") else "Not enough on it"
            return self.derby_out(random.choice(("FLY OUT", "GROUND OUT", "POP UP", "LINE OUT")), small)
        x, y, _ = pitch_position(self.pitch, self.pitch.time / self.pitch.duration)
        sideways = clamp(raw_error * 1500 + random.uniform(-140, 140), -300, 300)
        info = HIT_INFO["HR"]
        self.hit = Hit("HR", quality, x, y, sideways, info["flight"], info["arc"])
        self.hit.distance = self.hr_distance = random.randint(*DERBY_DISTANCE[quality])
        self.board_hit = False
        self.fan = (x + sideways, hr_end_y(self.hr_distance)) if random.random() < FAN_CATCH_CHANCE * 1.5 else None
        self.hit.flip = self.fan is None and self.hr_distance >= FLIP_MIN_FT and random.random() < FLIP_CHANCE
        if quality == "perfect":
            self.shake, self.shake_mag = SHAKE_TIME, SHAKE_PERFECT
        elif quality == "perfect_perfect":
            self.shake, self.shake_mag = SHAKE_TIME, SHAKE_PERFECT_PERFECT
        self.set_state("HR_CUTSCENE" if quality == "perfect_perfect" and SLUGGER_CUTSCENE else "BALL_IN_FLIGHT")

    def finish_pitch_without_contact(self):
        result = self.pitch.result
        if result == "foul":
            self.show_message("FOUL BALL", "No out - keep swinging!" if not self.money_ball else "Still the MONEY BALL - swing again!", DERBY_MESSAGE_TIME)
        elif result == "miss":
            self.derby_out("SWING & MISS", "")
        else:
            self.derby_out("TOOK A STRIKE", "Swing at it!")

    def derby_out(self, big, small=""):
        if self.money_ball:                                              # the money ball is one swing: no HR, and it is over
            self.money_result = "miss"
            return self.show_message(big, "No luck on the MONEY BALL", 1.8, then=self.derby_finish)
        self.derby_streak = 0                                            # (no outs any more: a miss just breaks your streak)
        self.show_message(big, small or "Keep swinging!", DERBY_MESSAGE_TIME)

    def begin_money_ball(self):
        self.money_ball = True
        self.cheer(1.0)
        self.set_state("WAIT")

    def home_run(self):
        worth = MONEY_VALUE if self.money_ball else 1
        longest_yet = self.derby_hr > 0 and self.hr_distance > self.derby_longest
        self.derby_hr += worth
        self.derby_streak += 1
        self.derby_best_streak = max(self.derby_best_streak, self.derby_streak)
        self.derby_longest = max(self.derby_longest, self.hr_distance)
        self.derby_log.append((self.hr_distance, self.money_ball))
        bonus = False
        if not self.money_ball and self.hr_distance >= DERBY_LONG_FT:    # two homers over 450 ft = extra time
            self.long_count += 1
            if self.long_count >= 2:
                self.long_count, bonus = 0, True
                self.time_left += DERBY_BONUS_TIME
                self.bonus_flash = 2.5
                if self.time_left > 0:
                    self.time_up = False
        self.stats["hr"] += worth
        self.credit(hit=True, hr=True)
        self.cheer(1.0)
        tag = {3: "HEATING UP!", 5: "ON FIRE!", 7: "UNSTOPPABLE!"}.get(self.derby_streak, "")
        small = f"{self.derby_hr} HR" + (f"   |   {self.derby_streak} in a row!" if self.derby_streak > 1 else "")
        if longest_yet:
            small += "   LONGEST YET!"
        if tag:
            small += f"   {tag}"
        if bonus:
            small += f"   +{int(DERBY_BONUS_TIME)} SECONDS!"
        if self.fan:
            small += "   A fan makes the catch!"
        replay = self.hr_distance >= DERBY_REPLAY_FT and random.random() < DERBY_REPLAY_CHANCE
        if replay:                                                       # a drone replay of the monster shot (about one in three)
            self.replay = dict(dist=self.hr_distance, sideways=self.hit.sideways, mph=random.randint(108, 119), angle=random.randint(24, 35))
        self.celebrating, self.fireworks_launched = True, 0
        self.add_fireworks(385, 70)
        if self.derby_streak >= 3:
            self.add_fireworks(250, 90)
            self.add_fireworks(520, 90)
        if self.money_ball:
            self.money_result = "hit"
            for fx in (180, 300, 470, 590):
                self.add_fireworks(fx, 100)
            if replay:
                self.replay_then = self.derby_finish
            return self.show_message(f"MONEY BALL!  +{MONEY_VALUE}  {self.hr_distance} FT", small, 2.4, then=self.start_replay if replay else self.derby_finish)
        self.show_message(f"HOME RUN!  {self.hr_distance} FT", small, DERBY_MESSAGE_TIME + 0.5, then=self.start_replay if replay else None)

    def derby_finish(self):
        rec = load_derby_record()
        self.derby_new_record = self.derby_hr > rec["best_hr"]
        rec.update(best_hr=max(rec["best_hr"], self.derby_hr), longest=max(rec["longest"], self.derby_longest),
                   best_streak=max(rec["best_streak"], self.derby_best_streak), games=rec["games"] + 1,
                   total_hr=rec["total_hr"] + self.derby_hr, money_hits=rec["money_hits"] + (self.money_result == "hit"))
        write_json("derby", rec)
        self.set_state("GAME_OVER")

    def draw_game_over(self, surf):
        shade = pygame.Surface((LOGICAL_W, LOGICAL_H), pygame.SRCALPHA)
        shade.fill((0, 0, 0, 238))
        surf.blit(shade, (0, 0))
        draw_text(surf, "HOME RUN DERBY", 640, 92, 50, GOLD)
        draw_text(surf, f"{self.lineup[DERBY_BATTER]['name']}  |  {self.team_name}", 640, 134, 22)
        rank, color = derby_rank(self.derby_hr)
        mx = 640 - get_font(32).size(rank)[0] / 2 - 30
        pygame.draw.polygon(surf, color, [(mx - 8, 168), (mx + 8, 168), (mx + 4, 190), (mx - 4, 190)])          # a medal on its ribbon
        pygame.draw.circle(surf, color, (mx, 198), 13)
        pygame.draw.circle(surf, WHITE, (mx, 198), 13, 2)
        pygame.draw.circle(surf, (255, 255, 255), (mx - 4, 194), 3)
        draw_text(surf, rank, 640, 196, 32, color)
        draw_text(surf, str(self.derby_hr), 640, 372, 170, WHITE)
        draw_text(surf, "HOME RUN" if self.derby_hr == 1 else "HOME RUNS", 640, 414, 30, GOLD)
        if self.derby_new_record:
            draw_text(surf, "NEW RECORD!", 640, 462, 36 + int(4 * math.sin(self.clock * 8)), GREEN)
        else:
            draw_text(surf, f"Record: {self.derby_prev['best_hr']} HR", 640, 462, 22, (200, 205, 225))
        money = {"hit": ("MONEY BALL: +%d HR!" % MONEY_VALUE, GOLD), "miss": ("MONEY BALL: missed", (200, 205, 225))}.get(self.money_result, ("", WHITE))
        draw_text(surf, money[0], 640, 500, 22, money[1])
        draw_text(surf, f"Longest: {self.derby_longest} ft", 400, 540, 22)
        draw_text(surf, f"Best streak: {self.derby_best_streak}", 880, 540, 22)
        draw_text(surf, f"Swings: {self.pitch_count}", 640, 540, 20, (200, 205, 225))
        if self.derby_log:                                               # a bar for every home run: taller = farther
            draw_text(surf, "HOME RUN LOG", 640, 580, 12, (200, 205, 225), outline=False)
            n = len(self.derby_log)
            bw = min(30, 640 // max(n, 1) - 4)
            x0 = 640 - n * (bw + 4) / 2
            for i, (dist, is_money) in enumerate(self.derby_log):
                h = int(lerp(8, 44, clamp((dist - 350) / 210, 0, 1)))
                bx = x0 + i * (bw + 4)
                pygame.draw.rect(surf, GOLD if is_money else GREEN, (bx, 640 - h, bw, h), border_radius=3)
                draw_text(surf, str(dist), bx + bw / 2, 654, 8, WHITE, outline=False)
        draw_text(surf, "Click or press SPACE for the title screen", 640, 690, 16)


# --- the HR DERBY button on the title screen ---------------------------------------
_menu_side_click = Menu.side_click


def _side_click_with_derby(self, i):
    if i == 1:
        self.derby_choices = make_derby_hitters()              # three new hitters every time
        self.screen = "derby_pick"
    else:
        _menu_side_click(self, i)


Menu.side_click = _side_click_with_derby


# =============================================================================
# 6. MAIN LOOP
# =============================================================================

def make_window(fullscreen=False):
    # On the web the browser controls the page size, so just match the canvas.
    return pygame.display.set_mode((LOGICAL_W, LOGICAL_H))


async def main():
    pygame.init()
    pygame.display.set_caption("Flash Baseball")
    window = make_window()
    canvas = pygame.Surface((LOGICAL_W, LOGICAL_H))
    clock = pygame.time.Clock()

    def loading():
        window.fill((14, 17, 22))
        draw_text(window, "LOADING...", LOGICAL_W // 2, LOGICAL_H // 2, 32, GOLD)
        pygame.display.flip()

    loading()                                                # show something right away so the page isn't blank
    await asyncio.sleep(0)
    load_unlocks()                                           # which animations you have already unlocked (saved in the browser)
    exhibition = Game()
    await asyncio.sleep(0)
    menu = Menu()
    await asyncio.sleep(0)
    derby = None                                             # built the first time you open the derby (saves loading time)
    game = exhibition
    mode = "menu"                                            # "menu" (start screen) or "game"

    def to_canvas(pos):
        """Convert a mouse position in the window to canvas coordinates."""
        w, h = window.get_size()
        scale = min(w / LOGICAL_W, h / LOGICAL_H)
        return (pos[0] - (w - LOGICAL_W * scale) / 2) / scale, (pos[1] - (h - LOGICAL_H * scale) / 2) / scale

    while True:
        dt = min(0.05, clock.tick(FPS) / 1000)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return                                       # (a browser tab can't really quit)
            if event.type == pygame.KEYDOWN and event.key in (pygame.K_ESCAPE, pygame.K_F11):
                continue                                     # no quitting or fullscreen toggling on the web
            if mode == "menu":
                if menu.handle_event(event, to_canvas):      # PLAY BALL: an exhibition game
                    menu.save_settings()
                    game = exhibition
                    game.configure(menu.team_name, menu.team_color, menu.difficulty, menu.innings,
                                   menu.logo_for_game(), menu.bat_choice, menu.weather_choice)
                    mode = "game"
                elif getattr(menu, "want_derby", False):     # HR DERBY
                    menu.want_derby = False
                    problem = name_problem(menu.team_name)
                    if problem:
                        menu.screen, menu.name_error, menu.name_error_t = "home", problem, 2.5
                    else:
                        menu.save_settings()
                        if derby is None:
                            loading()
                            await asyncio.sleep(0)
                            derby = Derby()
                        game = derby
                        game.hitter = getattr(menu, "derby_hitter", None)
                        game.configure(menu.team_name, menu.team_color, menu.difficulty, 1,
                                       menu.logo_for_game(), menu.bat_choice, menu.weather_choice)
                        mode = "game"
            elif event.type == pygame.MOUSEMOTION:
                game.mouse = to_canvas(event.pos)
                if game.paused:
                    game.pause_hover(game.mouse)
            elif event.type == pygame.MOUSEBUTTONDOWN:
                game.press_click(to_canvas(event.pos))
            elif event.type == pygame.KEYDOWN:
                if game.paused:
                    game.pause_key(event.key)                # P, arrows, ENTER, BACKSPACE all go to the pause menu
                elif event.key == pygame.K_p:
                    game.toggle_pause()
                elif event.key in (pygame.K_SPACE, pygame.K_RETURN):
                    game.press_swing()
                elif event.key == pygame.K_r:
                    game.press_run_key()
                elif event.key == pygame.K_s:
                    game.press_slide_key()
        if mode == "menu":
            menu.update(dt)
            menu.draw(canvas)
        else:
            game.update(dt)
            game.draw(canvas)
            if game.quit_to_menu:
                mode = "menu"
        w, h = window.get_size()
        if (w, h) == (LOGICAL_W, LOGICAL_H):
            window.blit(canvas, (0, 0))                      # same size: no scaling needed (much faster in the browser)
        else:
            scale = min(w / LOGICAL_W, h / LOGICAL_H)
            size = (int(LOGICAL_W * scale), int(LOGICAL_H * scale))
            window.fill(BLACK)
            window.blit(pygame.transform.scale(canvas, size), ((w - size[0]) // 2, (h - size[1]) // 2))
        pygame.display.flip()
        await asyncio.sleep(0)                               # hand control back to the browser every frame


if __name__ == "__main__":
    asyncio.run(main())